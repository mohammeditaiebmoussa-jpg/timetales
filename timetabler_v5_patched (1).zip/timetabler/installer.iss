; سكربت Inno Setup (https://jrsoftware.org/isinfo.php) — شغّل build_exe.bat أولاً
[Setup]
AppName=مولّد الجداول الزمنية
AppVersion=1.0
DefaultDirName={autopf}\Timetabler
DefaultGroupName=مولّد الجداول
OutputBaseFilename=Timetabler_Setup
OutputDir=installer_out
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64compatible

[Files]
Source: "dist\Timetabler\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{group}\مولّد الجداول"; Filename: "{app}\Timetabler.exe"
Name: "{autodesktop}\مولّد الجداول"; Filename: "{app}\Timetabler.exe"

[Run]
Filename: "{app}\Timetabler.exe"; Description: "تشغيل البرنامج"; Flags: postinstall nowait skipifsilent
