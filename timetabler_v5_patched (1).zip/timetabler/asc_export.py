"""تصدير الجدول إلى صيغة aSc Timetables (XML) — مدمج مع المولّد.

هو نفس منطق برنامج «FET to aSc 1.2.0» (ids بالشكل *n، الأقسام = مجموعات FET،
الأفواج = المجموعات الفرعية، groupids = قسم*10 + رقم الفوج، periodspercard = مدة الحصة)
لكن بلا خطوة ربط الأيام يدوياً: الأيام والفترات تأتي من المشروع مباشرة.
"""
from __future__ import annotations

from xml.sax.saxutils import escape

_DAY_SHORTS = [("أحد", "DIM"), ("اثنين", "LUN"), ("إثنين", "LUN"), ("ثلاثاء", "MAR"),
               ("أربعاء", "MER"), ("اربعاء", "MER"), ("خميس", "JEU"), ("جمعة", "VEN"), ("سبت", "SAM")]
_DEFAULT_ORDER = ["DIM", "LUN", "MAR", "MER", "JEU", "VEN", "SAM"]


def _q(v) -> str:
    return escape(str(v), {'"': "&quot;"})


def day_short(name: str, index: int) -> str:
    for key, short in _DAY_SHORTS:
        if key in name:
            return short
    return _DEFAULT_ORDER[index % 7]


def _hm(minutes: int) -> str:
    return f"{minutes // 60}:{minutes % 60:02d}"


def class_structure(project):
    """(classes, divisions, resolve) — resolve(name) -> [(class, division)]."""
    classes, divisions, where = [], {}, {}
    for y in project.years:
        for g in y.groups:
            classes.append(g.name)
            divisions[g.name] = list(g.subgroups)
            where[g.name] = [(g.name, 0)]
            for i, s in enumerate(g.subgroups):
                where.setdefault(s, [(g.name, i + 1)])
        where.setdefault(y.name, [(g.name, 0) for g in y.groups] or None)
    extra = []

    def resolve(name):
        r = where.get(name)
        if r:
            return r
        if name not in classes and name not in extra:
            extra.append(name)
            divisions.setdefault(name, [])
        return [(name, 0)]
    for a in project.acts.values():
        for s in a.students:
            resolve(s)
    classes += extra
    return classes, divisions, resolve


def build_asc_xml(project) -> str:
    pr = project
    classes, divisions, resolve = class_structure(pr)
    teachers = list(dict.fromkeys(pr.teachers + [t for a in pr.acts.values() for t in a.teachers]))
    subjects = list(dict.fromkeys(pr.subjects + [a.subject for a in pr.acts.values() if a.subject]))
    used_rooms = [pr.room_assign.get(a.id) or a.room for a in pr.acts.values()]
    rooms = list(dict.fromkeys(pr.rooms + [r for r in used_rooms if r]))
    # حصص متزامنة: كل حصة تأخذ فوجاً مختلفاً من القسم كي لا يعدّها aSc تعارضاً
    par_rank, par_seen = {}, {}
    for a in sorted(pr.acts.values(), key=lambda x: x.id):
        if a.parallel and a.active:
            k = (a.parallel, max(1, a.duration))
            par_rank[a.id] = par_seen.get(k, 0)
            par_seen[k] = par_rank[a.id] + 1
    need = {}
    for a in pr.acts.values():
        if a.id in par_rank:
            for s in a.students:
                for c, dv in resolve(s):
                    if dv == 0:
                        need[c] = max(need.get(c, 0), par_rank[a.id] + 1)
    tid = {n: f"*{i + 1}" for i, n in enumerate(teachers)}
    sid = {n: f"*{i + 1}" for i, n in enumerate(subjects)}
    cnum = {n: i + 1 for i, n in enumerate(classes)}
    rid = {n: f"*{i + 1}" for i, n in enumerate(rooms)}

    o = ['<?xml version="1.0" encoding="UTF-8"?>',
         '<timetable ascttversion="2010.3.1" importtype="database" '
         'options="idprefix:XML,groupstype1,decimalseparatordot" defaultexport="1">']
    o.append('<days options="canadd" columns="day,name,short">')
    for i, n in enumerate(pr.days):
        short = pr.day_shorts[i] if i < len(pr.day_shorts) else day_short(n, i)
        o.append(f'<day day="{i}" short="{_q(short)}" name="{_q(n)}"/>')
    o.append("</days>")
    o.append('<periods options="canadd" columns="period,starttime,endtime">')
    base = pr.first_hour * 60
    step = pr.period_minutes
    for i in range(0, pr.n_periods + 1):
        st = base + (i - 1) * step
        o.append(f'<period period="{i}" starttime="{_hm(st)}" endtime="{_hm(st + step)}"/>')
    o.append("</periods>")
    o.append('<dayperiods options="canadd" columns="day,period,starttime,endtime"/>')

    o.append('<teachers options="canadd" columns="id,name,short,gender,color">')
    for n in teachers:
        o.append(f'<teacher id="{tid[n]}" short="{_q(n)}" name="{_q(n)}" color="" gender=""/>')
    o.append("</teachers>")
    o.append('<classes options="canadd" columns="id,name,short,classroomids,teacherid,grade">')
    for n in classes:
        o.append(f'<class id="*{cnum[n]}" short="{_q(n)}" name="{_q(n)}" grade="" classroomids="" teacherid=""/>')
    o.append("</classes>")
    o.append('<subjects options="canadd" columns="id,name,short">')
    for n in subjects:
        o.append(f'<subject id="{sid[n]}" short="{_q(n)}" name="{_q(n)}"/>')
    o.append("</subjects>")
    o.append('<classrooms options="canadd" columns="id,name,short">')
    for n in rooms:
        o.append(f'<classroom id="{rid[n]}" short="{_q(n)}" name="{_q(n)}"/>')
    o.append("</classrooms>")
    o.append('<students options="canadd" columns="id,classid,name"/>')

    o.append('<groups options="canadd" columns="id,classid,name,entireclass,divisiontag,studentcount">')
    for n in classes:
        c = cnum[n]
        o.append(f'<group id="*{c * 10}" name="القسم كامل" studentcount="" divisiontag="0" entireclass="1" classid="*{c}"/>')
        divs = list(divisions.get(n, [])) or ["فوج 1", "فوج 2"]
        while len(divs) < need.get(n, 0):
            divs.append(f"فوج {len(divs) + 1}")
        for k, sn in enumerate(divs):
            o.append(f'<group id="*{c * 10 + k + 1}" name="{_q(sn)}" studentcount="" divisiontag="1" '
                     f'entireclass="0" classid="*{c}"/>')
    o.append("</groups>")

    o.append('<lessons options="canadd" columns="id,subjectid,classids,groupids,studentids,teacherids,'
             'classroomids,periodspercard,periodsperweek,weeks">')
    lesson_count = 0
    for a in sorted(pr.acts.values(), key=lambda x: x.id):
        if not a.active or not a.students:
            continue
        parts = []
        for s in a.students:
            parts += resolve(s)
        parts = list(dict.fromkeys(parts))
        room = pr.room_assign.get(a.id) or a.room
        cids = ",".join(f"*{cnum[c]}" for c, _ in parts)
        rk = par_rank.get(a.id)
        gids = ",".join(f"*{cnum[c] * 10 + (rk + 1 if (rk is not None and dv == 0) else dv)}" for c, dv in parts)
        tids = ",".join(tid[t] for t in a.teachers)
        sub = sid.get(a.subject, "")
        o.append(f'<lesson id="*{a.id}" classroomids="{rid.get(room, "")}" weeks="1" studentids="" '
                 f'groupids="{gids}" teacherids="{tids}" periodsperweek="1.0" periodspercard="{a.duration}" '
                 f'subjectid="{sub}" classids="{cids}"/>')
        lesson_count += 1
    o.append("</lessons>")

    o.append('<cards options="canadd" columns="lessonid,day,period,classroomids">')
    for a in sorted(pr.acts.values(), key=lambda x: x.id):
        pos = pr.placements.get(a.id)
        if not (a.active and a.students and pos):
            continue
        d, p = pos
        room = pr.room_assign.get(a.id) or a.room
        o.append(f'<card day="{d}" period="{p + 1}" classroomids="{rid.get(room, "")}" lessonid="*{a.id}"/>')
    o.append("</cards>")
    o.append('<grades options="canadd" columns="id,name,short,grade">')
    for i in range(1, 21):
        o.append(f'<grade id="*{i}" short="{i}" name="{i}" grade="{i}"/>')
    o.append("</grades>")
    o.append("</timetable>")
    return "\n".join(o)


def export_asc(project, path: str) -> int:
    xml = build_asc_xml(project)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(xml)
    return sum(1 for a in project.acts.values() if a.active and a.students)
