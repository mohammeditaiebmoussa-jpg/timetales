"""مولّد الجداول الزمنية — واجهة Tkinter (تعمل على Windows 7 وما بعده مع Python 3.8+).

التشغيل:  py app_tk.py [ملف.fet]
"""
from __future__ import annotations

import json
import os
import pickle
import queue
import sys
import tempfile
import threading
import tkinter as tk
import webbrowser
from tkinter import filedialog, messagebox, simpledialog, ttk

import app_constraints
import asc_export
import exporters
import tt_constraints as tcm
import tt_edit
import tt_solver
from fet_model import subject_color
from tt_model import Group, Project, Year

FONT = ("Arial", 10)
BOLD = ("Arial", 10, "bold")
TITLE = ("Arial", 14, "bold")
TITLE2 = ("Arial", 12, "bold")
MONO = ("Consolas", 10)
OK_BG, NO_BG = "#C6EFCE", "#F4B6B6"
MIN_FONT, MAX_FONT, DEFAULT_FONT = 8, 24, 10
PAL = {"bg": "#F0F0F0", "fg": "black", "field": "white"}     # ألوان السمة الحالية
_size = [DEFAULT_FONT]


def font_size() -> int:
    return _size[0]


def init_fonts(root, size: int) -> None:
    """خطوط مسمّاة: تغيير حجمها يحدّث كل العناصر فوراً."""
    global FONT, BOLD, TITLE, TITLE2, MONO
    _size[0] = size
    try:
        import tkinter.font as tkfont

        def mk(**kw):
            return tkfont.Font(root=root, **kw)
        FONT = mk(family="Arial", size=size)
        BOLD = mk(family="Arial", size=size, weight="bold")
        TITLE = mk(family="Arial", size=size + 4, weight="bold")
        TITLE2 = mk(family="Arial", size=size + 2, weight="bold")
        MONO = mk(family="Consolas", size=size)
        for nm in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont", "TkCaptionFont", "TkTooltipFont"):
            try:
                tkfont.nametofont(nm).configure(size=size)
            except Exception:  # noqa: BLE001
                pass
    except Exception:  # noqa: BLE001
        FONT, BOLD = ("Arial", size), ("Arial", size, "bold")
        TITLE, TITLE2, MONO = ("Arial", size + 4, "bold"), ("Arial", size + 2, "bold"), ("Consolas", size)


def resize_fonts(size: int) -> int:
    global FONT, BOLD, TITLE, TITLE2, MONO
    size = max(MIN_FONT, min(MAX_FONT, int(size)))
    _size[0] = size
    for f, delta in ((FONT, 0), (BOLD, 0), (TITLE, 4), (TITLE2, 2), (MONO, 0)):
        if hasattr(f, "configure"):
            f.configure(size=size + delta)
    if isinstance(FONT, tuple):     # بلا tkinter.font: نعيد بناء الصيغ النصية
        FONT, BOLD = ("Arial", size), ("Arial", size, "bold")
        TITLE, TITLE2, MONO = ("Arial", size + 4, "bold"), ("Arial", size + 2, "bold"), ("Consolas", size)
    return size


# ------------------------------------------------------------- التفضيلات (سمة وحجم الخط)
def prefs_path() -> str:
    return os.environ.get("TIMETABLER_PREFS") or os.path.join(os.path.expanduser("~"), ".timetabler_prefs.json")


def load_prefs() -> dict:
    out = {"dark": False, "font": DEFAULT_FONT}
    try:
        with open(prefs_path(), encoding="utf-8") as fh:
            d = json.load(fh)
        out["dark"] = bool(d.get("dark", False))
        out["font"] = max(MIN_FONT, min(MAX_FONT, int(d.get("font", DEFAULT_FONT))))
    except (OSError, ValueError, TypeError):
        pass
    return out


def save_prefs(prefs: dict) -> None:
    try:
        with open(prefs_path(), "w", encoding="utf-8") as fh:
            json.dump(prefs, fh)
    except OSError:
        pass


# ------------------------------------------------------------- تراجع / إعادة
class History:
    """لقطات كاملة للمشروع (pickle): كل تعديل يمرّ عبر App.set_dirty يُسجَّل تلقائياً."""

    def __init__(self, limit: int = 100):
        self.limit = limit
        self.undo_s, self.redo_s, self.cur = [], [], None

    @staticmethod
    def dump(project) -> bytes:
        return pickle.dumps(project, protocol=pickle.HIGHEST_PROTOCOL)

    def reset(self, project) -> None:
        self.undo_s, self.redo_s = [], []
        self.cur = self.dump(project)

    def commit(self, project) -> bool:
        s = self.dump(project)
        if s == self.cur:
            return False
        if self.cur is not None:
            self.undo_s.append(self.cur)
            del self.undo_s[:-self.limit]
        self.cur = s
        self.redo_s = []
        return True

    @property
    def can_undo(self) -> bool:
        return bool(self.undo_s)

    @property
    def can_redo(self) -> bool:
        return bool(self.redo_s)

    def undo(self):
        if not self.undo_s:
            return None
        self.redo_s.append(self.cur)
        self.cur = self.undo_s.pop()
        return pickle.loads(self.cur)

    def redo(self):
        if not self.redo_s:
            return None
        self.undo_s.append(self.cur)
        self.cur = self.redo_s.pop()
        return pickle.loads(self.cur)


# ------------------------------------------------------------- السمة الداكنة
class Theme:
    DARK = {"bg": "#1E1F22", "fg": "#E8E8E8", "field": "#2B2D31", "sel": "#3A5F9E", "btn": "#383B41", "line": "#4A4D55"}

    def __init__(self, root):
        self.root, self.dark, self.native = root, False, None
        try:
            bg = root.cget("bg")
        except Exception:  # noqa: BLE001
            bg = None
        self.light = {"bg": bg or "#F0F0F0", "fg": "black", "field": "white", "sel": "#3399FF",
                      "btn": bg or "#F0F0F0", "line": "#999999"}
        try:
            self.native = ttk.Style(root).theme_use()
        except Exception:  # noqa: BLE001
            pass
        PAL.update(self.light)

    @property
    def pal(self) -> dict:
        return self.DARK if self.dark else self.light

    def _bgs(self):
        return {self.light["bg"], self.DARK["bg"], "SystemButtonFace", "#F0F0F0", "#d9d9d9"}

    def _fields(self):
        return {self.light["field"], self.DARK["field"], "white", "SystemWindow"}

    def apply(self, dark: bool) -> None:
        self.dark = bool(dark)
        PAL.update(self.pal)
        self._style()
        self.walk()

    def _style(self) -> None:
        pal = self.pal
        st = ttk.Style(self.root)
        if self.dark or self.native == "clam" or not self.native:
            if "clam" in st.theme_names():
                st.theme_use("clam")
            st.configure(".", background=pal["bg"], foreground=pal["fg"], fieldbackground=pal["field"],
                         troughcolor=pal["bg"], bordercolor=pal["line"], lightcolor=pal["bg"], darkcolor=pal["bg"],
                         insertcolor=pal["fg"], selectbackground=pal["sel"], selectforeground="white")
            st.configure("TButton", background=pal["btn"], foreground=pal["fg"], padding=(10, 4), font=FONT)
            st.map("TButton", background=[("active", pal["sel"])], foreground=[("active", "white")])
            st.configure("TEntry", fieldbackground=pal["field"], foreground=pal["fg"])
            st.configure("TSpinbox", fieldbackground=pal["field"], foreground=pal["fg"], arrowcolor=pal["fg"])
            st.configure("TCombobox", fieldbackground=pal["field"], background=pal["btn"], foreground=pal["fg"],
                         arrowcolor=pal["fg"])
            st.map("TCombobox", fieldbackground=[("readonly", pal["field"])], foreground=[("readonly", pal["fg"])],
                   selectbackground=[("readonly", pal["field"])], selectforeground=[("readonly", pal["fg"])])
            st.configure("Treeview", background=pal["field"], fieldbackground=pal["field"], foreground=pal["fg"])
            st.map("Treeview", background=[("selected", pal["sel"])], foreground=[("selected", "white")])
            st.configure("Treeview.Heading", background=pal["btn"], foreground=pal["fg"])
            st.configure("TNotebook", background=pal["bg"])
            st.configure("TNotebook.Tab", background=pal["btn"], foreground=pal["fg"])
            st.map("TNotebook.Tab", background=[("selected", pal["sel"])], foreground=[("selected", "white")])
            st.configure("TCheckbutton", background=pal["bg"], foreground=pal["fg"])
            st.configure("TLabel", background=pal["bg"], foreground=pal["fg"])
            st.configure("TScrollbar", background=pal["btn"], troughcolor=pal["bg"], arrowcolor=pal["fg"])
            self.root.option_add("*TCombobox*Listbox.background", pal["field"])
            self.root.option_add("*TCombobox*Listbox.foreground", pal["fg"])
            self.root.option_add("*TCombobox*Listbox.selectBackground", pal["sel"])
        elif self.native in st.theme_names():
            st.theme_use(self.native)
        st.configure("Treeview", rowheight=row_height(), font=FONT)

    def walk(self, widget=None) -> None:
        self._walk(widget or self.root)

    def _walk(self, w) -> None:
        self._recolor(w)
        for c in w.winfo_children():
            self._walk(c)

    def _recolor(self, w) -> None:
        pal = self.pal
        try:
            cls = w.winfo_class()
            if cls in ("Frame", "Toplevel", "Tk", "Canvas"):
                if w.cget("bg") in self._bgs() | self._fields():
                    w.configure(bg=pal["bg"])
            elif cls in ("Label", "Checkbutton", "Radiobutton", "Labelframe"):
                cur = w.cget("bg")
                if cur in self._bgs() | self._fields():
                    w.configure(bg=pal["field"] if cur in self._fields() else pal["bg"], fg=pal["fg"])
            elif cls in ("Listbox", "Text", "Entry", "Spinbox"):
                w.configure(bg=pal["field"], fg=pal["fg"], insertbackground=pal["fg"],
                            selectbackground=pal["sel"], selectforeground="white")
        except tk.TclError:
            pass
        except (AttributeError, TypeError):
            pass


def row_height() -> int:
    return int(font_size() * 2.4) + 4




def ask_lines(parent, title: str, prompt: str) -> list:
    """نافذة صغيرة لإدخال عدة أسماء (سطر لكل اسم). تعيد قائمة (قد تكون فارغة)."""
    win = tk.Toplevel(parent)
    win.title(title)
    win.transient(parent)
    tk.Label(win, text=prompt, font=FONT, justify="right").pack(padx=8, pady=6, anchor="e")
    txt = tk.Text(win, width=40, height=14, font=FONT)
    txt.pack(padx=8, pady=4)
    out = []

    def ok():
        out.extend(x.strip() for x in txt.get("1.0", "end").splitlines() if x.strip())
        win.destroy()
    ttk.Button(win, text="موافق", command=ok).pack(pady=6)
    win.grab_set()
    parent.wait_window(win)
    return out


# ============================================================= الإعدادات
class SettingsTab(tk.Frame):
    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        f = tk.Frame(self)
        f.pack(fill="both", expand=True, padx=12, pady=10)
        self.inst = tk.StringVar()
        self.halves = tk.StringVar(value="2")
        self.first = tk.IntVar(value=8)
        self.minutes = tk.IntVar(value=60)
        r = 0
        for label, widget in [
            ("اسم المؤسسة", ttk.Entry(f, textvariable=self.inst, justify="right", width=40)),
            ("نمط اليوم", ttk.Combobox(f, textvariable=self.halves, values=["1", "2"], state="readonly", width=6)),
            ("بداية الحصة الأولى (ساعة) — لـ aSc", ttk.Spinbox(f, from_=5, to=14, textvariable=self.first, width=6)),
            ("مدة الحصة بالدقائق — لـ aSc", ttk.Spinbox(f, from_=20, to=120, textvariable=self.minutes, width=6)),
        ]:
            widget.grid(row=r, column=0, sticky="e", padx=4, pady=4)
            tk.Label(f, text=label, font=FONT).grid(row=r, column=1, sticky="e", padx=4)
            r += 1
        tk.Label(f, text="(النمط 2 = صباح ومساء: تُقسَم الحصص إلى نصفين متساويين ولا تمتد حصة عبر الفاصل)",
                 fg="#555", font=FONT).grid(row=r, column=0, columnspan=2, sticky="e")
        r += 1
        self.days = tk.Text(f, width=24, height=9, font=FONT)
        self.periods = tk.Text(f, width=24, height=12, font=FONT)
        self.days.grid(row=r, column=0, sticky="e", padx=4, pady=6)
        tk.Label(f, text="الأيام\n(سطر لكل يوم)", font=FONT).grid(row=r, column=1, sticky="ne")
        r += 1
        self.periods.grid(row=r, column=0, sticky="e", padx=4, pady=6)
        tk.Label(f, text="الحصص\n(سطر لكل حصة)", font=FONT).grid(row=r, column=1, sticky="ne")
        r += 1
        ttk.Button(f, text="تطبيق الإعدادات", command=self.apply).grid(row=r, column=0, pady=8, sticky="e")

    def refresh(self):
        p = self.app.project
        self.inst.set(p.institution)
        self.halves.set(str(p.halves))
        self.first.set(p.first_hour)
        self.minutes.set(p.period_minutes)
        self.days.delete("1.0", "end")
        self.days.insert("1.0", "\n".join(p.days))
        self.periods.delete("1.0", "end")
        self.periods.insert("1.0", "\n".join(p.periods))

    def apply(self):
        p = self.app.project
        days = [x.strip() for x in self.days.get("1.0", "end").splitlines() if x.strip()]
        periods = [x.strip() for x in self.periods.get("1.0", "end").splitlines() if x.strip()]
        halves = int(self.halves.get())
        if not days or not periods:
            messagebox.showerror("خطأ", "أدخل يوماً واحداً وحصة واحدة على الأقل.")
            return
        if halves == 2 and len(periods) % 2:
            messagebox.showerror("خطأ", "في نمط صباح/مساء يجب أن يكون عدد الحصص زوجياً.")
            return
        if len(set(days)) != len(days) or len(set(periods)) != len(periods):
            messagebox.showerror("خطأ", "أسماء الأيام والحصص يجب ألا تتكرر.")
            return
        changed = (days != p.days or periods != p.periods or halves != p.halves)
        if changed and p.placements and not messagebox.askyesno(
                "تأكيد", "تغيير الأيام/الحصص سيمسح الجدول المولَّد الحالي. المتابعة؟"):
            return
        p.institution = self.inst.get().strip() or p.institution
        p.first_hour, p.period_minutes = int(self.first.get()), int(self.minutes.get())
        if changed:
            p.days, p.periods, p.halves = days, periods, halves
            p.raw_days, p.raw_hours = [], []
            p.placements.clear()
            p.locked.clear()
            p.room_assign.clear()
            for k, slots in list(p.unavail.items()):
                p.unavail[k] = {(d, q) for d, q in slots if d < len(days) and q < len(periods)}
        self.app.set_dirty()
        self.app.reload_all()


# ============================================================= القوائم البسيطة
class NameList(tk.Frame):
    def __init__(self, master, app, kind: str, title: str):
        super().__init__(master)
        self.app, self.kind = app, kind
        tk.Label(self, text=title, font=BOLD).pack(anchor="e")
        self.entry = ttk.Entry(self, justify="right")
        self.entry.pack(fill="x", pady=2)
        self.entry.bind("<Return>", lambda _e: self.add())
        bar = tk.Frame(self)
        bar.pack(fill="x")
        for text, cmd in [("حذف", self.delete), ("تعديل الاسم", self.rename), ("إضافة قائمة", self.add_many), ("إضافة", self.add)]:
            ttk.Button(bar, text=text, command=cmd, width=10).pack(side="right", padx=1, pady=2)
        box = tk.Frame(self)
        box.pack(fill="both", expand=True)
        sb = ttk.Scrollbar(box)
        sb.pack(side="left", fill="y")
        self.lb = tk.Listbox(box, font=FONT, exportselection=False, yscrollcommand=sb.set)
        self.lb.pack(side="right", fill="both", expand=True)
        sb.config(command=self.lb.yview)

    def _items(self) -> list:
        return {"teacher": self.app.project.teachers, "subject": self.app.project.subjects,
                "room": self.app.project.rooms}[self.kind]

    def refresh(self):
        self.lb.delete(0, "end")
        for n in self._items():
            self.lb.insert("end", f"{n}   ({self.app.project.usage(self.kind, n)})")

    def _sel(self):
        s = self.lb.curselection()
        return self._items()[s[0]] if s else None

    def add(self):
        n = self.entry.get().strip()
        if n and n not in self._items():
            self._items().append(n)
            self.app.set_dirty()
        self.entry.delete(0, "end")
        self.app.reload_all()

    def add_many(self):
        for n in ask_lines(self.app, "إضافة قائمة", "اكتب كل اسم في سطر:"):
            if n not in self._items():
                self._items().append(n)
        self.app.set_dirty()
        self.app.reload_all()

    def rename(self):
        old = self._sel()
        if not old:
            return
        new = simpledialog.askstring("تعديل الاسم", "الاسم الجديد:", initialvalue=old, parent=self.app)
        if new and new.strip() and new.strip() not in self._items():
            self.app.project.rename(self.kind, old, new.strip())
            self.app.set_dirty()
            self.app.reload_all()

    def delete(self):
        n = self._sel()
        if not n:
            return
        if not self.app.project.delete_name(self.kind, n):
            messagebox.showwarning("لا يمكن الحذف", f"«{n}» مستعمل في حصص. احذف الحصص أولاً.")
            return
        self.app.set_dirty()
        self.app.reload_all()


class NamesTab(tk.Frame):
    def __init__(self, master, app):
        super().__init__(master)
        self.lists = [NameList(self, app, "teacher", "الأساتذة"), NameList(self, app, "subject", "المواد"),
                      NameList(self, app, "room", "القاعات")]
        for w in self.lists:
            w.pack(side="right", fill="both", expand=True, padx=8, pady=8)

    def refresh(self):
        for w in self.lists:
            w.refresh()


# ============================================================= الأقسام
class ClassesTab(tk.Frame):
    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        bar = tk.Frame(self)
        bar.pack(fill="x", padx=8, pady=6)
        for text, cmd in [("حذف", self.delete), ("تعديل الاسم", self.rename), ("إضافة فوج", self.add_sub),
                          ("إضافة قسم", self.add_group), ("إضافة مستوى", self.add_year)]:
            ttk.Button(bar, text=text, command=cmd).pack(side="right", padx=2)
        tk.Label(self, text="المستوى ← القسم ← الفوج. حصص القسم تحجز كل أفواجه؛ حصص الفوج تحجز الفوج وحده.",
                 fg="#555", font=FONT).pack(anchor="e", padx=8)
        self.tree = ttk.Treeview(self, show="tree")
        self.tree.pack(fill="both", expand=True, padx=8, pady=6)

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        for yi, y in enumerate(self.app.project.years):
            ynode = self.tree.insert("", "end", iid=f"y{yi}", text=y.name, open=True)
            for gi, g in enumerate(y.groups):
                gnode = self.tree.insert(ynode, "end", iid=f"g{yi}.{gi}", text=g.name, open=True)
                for si, s in enumerate(g.subgroups):
                    self.tree.insert(gnode, "end", iid=f"s{yi}.{gi}.{si}", text=s)

    def _sel(self):
        s = self.tree.selection()
        return s[0] if s else None

    def _ask(self, title):
        v = simpledialog.askstring(title, "الاسم:", parent=self.app)
        return v.strip() if v and v.strip() else None

    def add_year(self):
        n = self._ask("مستوى جديد")
        if n:
            self.app.project.years.append(Year(n))
            self._done()

    def add_group(self):
        iid = self._sel()
        if not iid or iid[0] != "y":
            messagebox.showinfo("اختر مستوى", "اختر مستوى أولاً لإضافة قسم تحته.")
            return
        names = ask_lines(self.app, "أقسام جديدة", "اكتب كل قسم في سطر:")
        y = self.app.project.years[int(iid[1:])]
        for n in names:
            y.groups.append(Group(n, []))
        if names:
            self._done()

    def add_sub(self):
        iid = self._sel()
        if not iid or iid[0] != "g":
            messagebox.showinfo("اختر قسماً", "اختر قسماً أولاً لإضافة فوج تحته.")
            return
        yi, gi = map(int, iid[1:].split("."))
        g = self.app.project.years[yi].groups[gi]
        names = ask_lines(self.app, "أفواج جديدة", f"أفواج القسم «{g.name}» (سطر لكل فوج):")
        for n in names:
            g.subgroups.append(n)
        if names:
            self._done()

    def rename(self):
        iid = self._sel()
        if not iid:
            return
        old = self.tree.item(iid, "text")
        new = self._ask("تعديل الاسم")
        if new:
            self.app.project.rename("students", old, new)
            self._done()

    def delete(self):
        iid = self._sel()
        if not iid:
            return
        pr = self.app.project
        name = self.tree.item(iid, "text")
        if pr.usage("students", name):
            messagebox.showwarning("لا يمكن الحذف", "هذا العنصر مستعمل في حصص. احذف حصصه أولاً.")
            return
        if iid[0] == "y":
            del pr.years[int(iid[1:])]
        elif iid[0] == "g":
            yi, gi = map(int, iid[1:].split("."))
            del pr.years[yi].groups[gi]
        else:
            yi, gi, si = map(int, iid[1:].split("."))
            del pr.years[yi].groups[gi].subgroups[si]
        self._done()

    def _done(self):
        self.app.set_dirty()
        self.app.reload_all()


# ============================================================= الحصص
class ActsTab(tk.Frame):
    COLS = [("id", "رقم", 50), ("par", "تزامن", 50), ("time", "الوقت", 150), ("room", "القاعة", 90), ("dur", "المدة", 45),
            ("students", "القسم", 140), ("subject", "المادة", 140), ("teachers", "الأستاذ", 160)]

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        form = tk.LabelFrame(self, text="حصة جديدة", font=BOLD)
        form.pack(fill="x", padx=8, pady=4)
        self.t_lb = tk.Listbox(form, selectmode="extended", height=5, width=22, font=FONT, exportselection=False)
        self.s_lb = tk.Listbox(form, selectmode="extended", height=5, width=22, font=FONT, exportselection=False)
        self.subj = ttk.Combobox(form, width=22, justify="right")
        self.pattern = tk.StringVar(value="1")
        self.room = ttk.Combobox(form, width=22, justify="right")
        self.par_with = tk.StringVar(value="")
        c = 0
        for label, w in [("الأساتذة", self.t_lb), ("الأقسام/الأفواج", self.s_lb)]:
            w.grid(row=0, column=c, padx=4, pady=2)
            tk.Label(form, text=label, font=FONT).grid(row=1, column=c)
            c += 1
        self.subj.grid(row=0, column=c, padx=4, sticky="s")
        tk.Label(form, text="المادة", font=FONT).grid(row=1, column=c)
        c += 1
        ttk.Entry(form, textvariable=self.pattern, width=10, justify="center").grid(row=0, column=c, sticky="s")
        tk.Label(form, text="التوزيع (مثال 2+1+1)", font=FONT).grid(row=1, column=c)
        c += 1
        self.room.grid(row=0, column=c, padx=4, sticky="s")
        tk.Label(form, text="قاعة (أو عدة قاعات بـ ،)", font=FONT).grid(row=1, column=c)
        c += 1
        ttk.Entry(form, textvariable=self.par_with, width=8, justify="center").grid(row=0, column=c, sticky="s")
        tk.Label(form, text="تزامن مع الحصة رقم\n(اختياري)", font=FONT).grid(row=1, column=c)
        c += 1
        ttk.Button(form, text="إضافة الحصص", command=self.add).grid(row=0, column=c, padx=8, sticky="s")

        bar = tk.Frame(self)
        bar.pack(fill="x", padx=8)
        for text, cmd in [("حذف المحدد", self.delete), ("تثبيت في وقت…", self.pin), ("فكّ التثبيت", self.unpin),
                          ("ربط كحصص متزامنة", self.link_parallel), ("فكّ التزامن", self.unlink_parallel),
                          ("استيراد Excel/CSV", self.import_file)]:
            ttk.Button(bar, text=text, command=cmd).pack(side="right", padx=2, pady=4)
        self.count = tk.Label(bar, text="", font=FONT)
        self.count.pack(side="left")
        box = tk.Frame(self)
        box.pack(fill="both", expand=True, padx=8, pady=4)
        self.tree = ttk.Treeview(box, columns=[c[0] for c in self.COLS], show="headings", selectmode="extended")
        for key, text, w in self.COLS:
            self.tree.heading(key, text=text)
            self.tree.column(key, width=w, anchor="e")
        sb = ttk.Scrollbar(box, command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        sb.pack(side="left", fill="y")
        self.tree.pack(side="right", fill="both", expand=True)

    def refresh(self):
        p = self.app.project
        self.t_lb.delete(0, "end")
        for n in p.teachers:
            self.t_lb.insert("end", n)
        self.s_lb.delete(0, "end")
        for n in p.all_group_names():
            self.s_lb.insert("end", n)
        self.subj.configure(values=p.subjects)
        self.room.configure(values=[""] + p.rooms)
        self.tree.delete(*self.tree.get_children())
        for a in sorted(p.acts.values(), key=lambda x: x.id):
            t = ""
            pos = p.placements.get(a.id)
            if pos:
                t = f"{p.days[pos[0]]} {p.periods[pos[1]]}" + (" 📌" if a.id in p.locked else "")
            room = p.room_assign.get(a.id) or a.room or "/".join(a.rooms)
            self.tree.insert("", "end", iid=str(a.id), values=(a.id, a.parallel or "", t, room, a.duration,
                                                                 " + ".join(a.students), a.subject,
                                                                 " + ".join(a.teachers)))
        self.count.config(text=f"{len(p.acts)} حصة — {sum(a.duration for a in p.acts.values())} ساعة")

    def add(self):
        p = self.app.project
        teachers = [self.t_lb.get(i) for i in self.t_lb.curselection()]
        studs = [self.s_lb.get(i) for i in self.s_lb.curselection()]
        subj = self.subj.get().strip()
        if not (teachers and studs and subj):
            messagebox.showinfo("ناقص", "اختر أستاذاً وقسماً واكتب/اختر المادة.")
            return
        try:
            import re
            pattern = [int(x) for x in re.split(r"[+،,\s]+", self.pattern.get().strip()) if x]
            assert pattern and all(x > 0 for x in pattern)
        except (ValueError, AssertionError):
            messagebox.showerror("توزيع غير صالح", "اكتب أرقاماً موجبة مفصولة بـ + مثل 2+1+1")
            return
        if subj not in p.subjects:
            p.subjects.append(subj)
        rooms = [x.strip() for x in self.room.get().replace("،", ",").split(",") if x.strip()]
        for r in rooms:
            if r not in p.rooms:
                p.rooms.append(r)
        anchor = self.par_with.get().strip()
        if anchor:
            try:
                anchor_id = int(anchor)
            except ValueError:
                messagebox.showerror("تزامن", "اكتب رقم الحصة (رقماً صحيحاً) أو اتركه فارغاً.")
                return
            if anchor_id not in p.acts:
                messagebox.showerror("تزامن", f"لا توجد حصة بالرقم {anchor_id}.")
                return
        ids = p.add_activities(teachers, subj, studs, pattern, rooms[0] if len(rooms) == 1 else "",
                               rooms if len(rooms) > 1 else None)
        if anchor:
            try:
                p.add_parallel_to(anchor_id, ids)
            except ValueError as exc:
                for i in ids:
                    p.delete_activity(i)
                messagebox.showerror("تعذّر التزامن", str(exc))
                return
            self.par_with.set("")
        self.app.set_dirty()
        self.app.reload_all()

    def link_parallel(self):
        ids = self._selected_ids()
        if len(ids) < 2:
            messagebox.showinfo("تزامن", "حدّد حصتين أو أكثر (واحدة لكل أستاذ) لتُدرَّس معاً في نفس الوقت.")
            return
        try:
            pid = self.app.project.link_parallel(ids)
        except ValueError as exc:
            messagebox.showerror("تعذّر الربط", str(exc))
            return
        self.app.set_dirty()
        self.app.reload_all()
        messagebox.showinfo("تزامن", f"رُبطت الحصص (رقم التزامن {pid}). أعد التوليد ليُوضَعوا في نفس الوقت.")

    def unlink_parallel(self):
        ids = self._selected_ids()
        if not ids:
            return
        self.app.project.unlink_parallel(ids)
        self.app.set_dirty()
        self.app.reload_all()

    def _selected_ids(self):
        return [int(i) for i in self.tree.selection()]

    def delete(self):
        ids = self._selected_ids()
        if not ids:
            return
        if not messagebox.askyesno("تأكيد", f"حذف {len(ids)} حصة؟"):
            return
        for i in ids:
            self.app.project.delete_activity(i)
        self.app.set_dirty()
        self.app.reload_all()

    def pin(self):
        ids = self._selected_ids()
        p = self.app.project
        if not ids:
            return
        win = tk.Toplevel(self.app)
        win.title("تثبيت وقت")
        day = ttk.Combobox(win, values=p.days, state="readonly")
        per = ttk.Combobox(win, values=p.periods, state="readonly")
        pos = p.placements.get(ids[0])
        day.current(pos[0] if pos else 0)
        per.current(pos[1] if pos else 0)
        for lbl, w in [("اليوم", day), ("الحصة", per)]:
            tk.Label(win, text=lbl, font=FONT).pack(anchor="e", padx=8)
            w.pack(padx=8, pady=2)

        def ok():
            for i in ids:
                p.placements[i] = (day.current(), per.current())
                p.locked.add(i)
            win.destroy()
            self.app.set_dirty()
            self.app.reload_all()
        ttk.Button(win, text="تثبيت", command=ok).pack(pady=8)

    def unpin(self):
        for i in self._selected_ids():
            self.app.project.locked.discard(i)
        self.app.set_dirty()
        self.app.reload_all()

    def import_file(self):
        path = filedialog.askopenfilename(title="ملف الحصص", filetypes=[("Excel/CSV", "*.xlsx *.csv"), ("All", "*.*")])
        if not path:
            return
        rows = []
        try:
            if path.lower().endswith(".csv"):
                import csv
                with open(path, encoding="utf-8-sig", newline="") as fh:
                    rows = list(csv.reader(fh))
            else:
                from openpyxl import load_workbook
                wb = load_workbook(path, read_only=True, data_only=True)
                rows = [list(r) for r in wb.active.iter_rows(values_only=True)]
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("تعذّر القراءة", str(exc))
            return
        if rows and rows[0] and str(rows[0][0]).strip() in ("أستاذ", "الأستاذ", "teacher", "Teacher"):
            rows = rows[1:]
        n = self.app.project.import_rows(rows)
        errs = getattr(self.app.project, "import_parallel_errors", [])
        extra = ("\n\nتنبيهات التزامن:\n" + "\n".join(errs[:8])) if errs else ""
        messagebox.showinfo("تم الاستيراد", f"أُضيفت {n} مجموعة حصص.\n"
                            "الأعمدة: أستاذ | مادة | قسم | توزيع | قاعة | تزامن (اختياري)" + extra)
        self.app.set_dirty()
        self.app.reload_all()


# ============================================================= القيود
class ConstraintsTab(tk.Frame):
    KINDS = [("teacher", "أستاذ"), ("students", "قسم/فوج"), ("room", "قاعة")]

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.cur = None
        left = tk.Frame(self)
        left.pack(side="right", fill="y", padx=8, pady=8)
        self.kind = ttk.Combobox(left, values=[k[1] for k in self.KINDS], state="readonly", width=18)
        self.kind.current(0)
        self.kind.pack()
        self.kind.bind("<<ComboboxSelected>>", lambda _e: self.fill_list())
        self.lb = tk.Listbox(left, width=24, height=22, font=FONT, exportselection=False)
        self.lb.pack(fill="y", expand=True, pady=4)
        self.lb.bind("<<ListboxSelect>>", lambda _e: self.select())

        right = tk.Frame(self)
        right.pack(side="left", fill="both", expand=True, padx=8, pady=8)
        self.title = tk.Label(right, text="اختر عنصراً", font=TITLE2)
        self.title.pack(anchor="e")
        tk.Label(right, text="انقر الخانة لتبديل (أخضر = متاح، أحمر = غير متاح). انقر اسم اليوم/الحصة لتبديل الصف/العمود.",
                 fg="#555", font=FONT).pack(anchor="e")
        self.grid_frame = tk.Frame(right)
        self.grid_frame.pack(pady=6, anchor="e")
        lim = tk.LabelFrame(right, text="حدود العنصر المحدد", font=BOLD)
        lim.pack(fill="x", pady=6)
        self.v_daily = tk.IntVar(value=0)
        self.v_days = tk.IntVar(value=0)
        ttk.Spinbox(lim, from_=0, to=14, textvariable=self.v_daily, width=5, command=self.save_limits).grid(row=0, column=0, padx=4, pady=3)
        tk.Label(lim, text="أقصى ساعات يومياً (0 = بلا حد)", font=FONT).grid(row=0, column=1, sticky="e")
        ttk.Spinbox(lim, from_=0, to=14, textvariable=self.v_days, width=5, command=self.save_limits).grid(row=1, column=0, padx=4, pady=3)
        tk.Label(lim, text="أقصى أيام عمل أسبوعياً — للأساتذة (0 = بلا حد)", font=FONT).grid(row=1, column=1, sticky="e")
        for w in lim.winfo_children():
            if isinstance(w, ttk.Spinbox):
                w.bind("<FocusOut>", lambda _e: self.save_limits())
                w.bind("<Return>", lambda _e: self.save_limits())

        g = tk.LabelFrame(right, text="إعدادات عامة", font=BOLD)
        g.pack(fill="x", pady=6)
        self.g_vars = {}
        rows = [("default_teacher_max_daily", "أقصى ساعات يومية لكل الأساتذة (0 = بلا حد)"),
                ("default_students_max_daily", "أقصى ساعات يومية لكل الأقسام (0 = بلا حد)"),
                ("w_gaps_teacher", "وزن تقليل فراغات الأساتذة"),
                ("w_gaps_students", "وزن تقليل فراغات الأقسام"),
                ("w_min_days", "وزن توزيع حصص المادة على أيام مختلفة")]
        for i, (attr, label) in enumerate(rows):
            v = tk.IntVar(value=0)
            self.g_vars[attr] = v
            sp = ttk.Spinbox(g, from_=0, to=99, textvariable=v, width=5, command=self.save_globals)
            sp.grid(row=i, column=0, padx=4, pady=2)
            sp.bind("<FocusOut>", lambda _e: self.save_globals())
            sp.bind("<Return>", lambda _e: self.save_globals())
            tk.Label(g, text=label, font=FONT).grid(row=i, column=1, sticky="e")

    # ---- قوائم
    @property
    def kind_key(self):
        return self.KINDS[self.kind.current()][0]

    def _names(self):
        p = self.app.project
        k = self.kind_key
        if k == "teacher":
            return list(p.teachers)
        if k == "room":
            return list(p.rooms)
        return p.all_group_names()

    def fill_list(self):
        self.lb.delete(0, "end")
        for n in self._names():
            bad = len(self.app.project.unavail.get((self.kind_key, n), ()))
            self.lb.insert("end", n + (f"   ✖{bad}" if bad else ""))
        self.cur = None
        self.title.config(text="اختر عنصراً")
        self.draw_grid()

    def refresh(self):
        for attr, v in self.g_vars.items():
            v.set(getattr(self.app.project, attr))
        keep = self.cur
        self.fill_list()
        if keep and keep in self._names():
            i = self._names().index(keep)
            self.lb.selection_set(i)
            self.select()

    def select(self):
        s = self.lb.curselection()
        if not s:
            return
        self.cur = self._names()[s[0]]
        self.title.config(text=f"التوفّر: {self.cur}")
        p, k = self.app.project, self.kind_key
        if k == "teacher":
            self.v_daily.set(p.teacher_max_daily.get(self.cur, 0))
            self.v_days.set(p.teacher_max_days.get(self.cur, 0))
        elif k == "students":
            self.v_daily.set(p.students_max_daily.get(self.cur, 0))
            self.v_days.set(0)
        else:
            self.v_daily.set(0)
            self.v_days.set(0)
        self.draw_grid()

    # ---- الشبكة
    def draw_grid(self):
        for w in self.grid_frame.winfo_children():
            w.destroy()
        if not self.cur:
            return
        p = self.app.project
        bad = p.unavail.get((self.kind_key, self.cur), set())
        nd, npd = p.n_days, p.n_periods
        for d, dn in enumerate(p.days):
            lb = tk.Label(self.grid_frame, text=dn, bg="#305496", fg="white", font=BOLD, relief="solid", bd=1, width=12)
            lb.grid(row=0, column=nd - 1 - d, sticky="nsew")
            lb.bind("<Button-1>", lambda _e, d=d: self.toggle_day(d))
        tk.Label(self.grid_frame, text="الحصة", bg="#305496", fg="white", font=BOLD, relief="solid", bd=1
                 ).grid(row=0, column=nd, sticky="nsew")
        for q, pn in enumerate(p.periods):
            lb = tk.Label(self.grid_frame, text=pn, bg="#D9E1F2", font=BOLD, relief="solid", bd=1)
            lb.grid(row=1 + q, column=nd, sticky="nsew")
            lb.bind("<Button-1>", lambda _e, q=q: self.toggle_period(q))
            for d in range(nd):
                cell = tk.Label(self.grid_frame, text="", bg=NO_BG if (d, q) in bad else OK_BG,
                                relief="solid", bd=1, height=1)
                cell.grid(row=1 + q, column=nd - 1 - d, sticky="nsew", ipady=3)
                cell.bind("<Button-1>", lambda _e, d=d, q=q: self.toggle(d, q))

    def _set(self):
        return self.app.project.unavail.setdefault((self.kind_key, self.cur), set())

    def _after(self):
        s = self.app.project.unavail.get((self.kind_key, self.cur))
        if s is not None and not s:
            del self.app.project.unavail[(self.kind_key, self.cur)]
        self.app.set_dirty()
        i = self.lb.curselection()
        self.fill_list_keep()

    def fill_list_keep(self):
        keep = self.cur
        self.fill_list()
        if keep in self._names():
            self.lb.selection_set(self._names().index(keep))
            self.select()

    def toggle(self, d, q):
        if not self.cur:
            return
        s = self._set()
        s.symmetric_difference_update({(d, q)})
        self._after()

    def toggle_day(self, d):
        if not self.cur:
            return
        cells = {(d, q) for q in range(self.app.project.n_periods)}
        s = self._set()
        if cells <= s:
            s -= cells
        else:
            s |= cells
        self._after()

    def toggle_period(self, q):
        if not self.cur:
            return
        cells = {(d, q) for d in range(self.app.project.n_days)}
        s = self._set()
        if cells <= s:
            s -= cells
        else:
            s |= cells
        self._after()

    def save_limits(self):
        if not self.cur:
            return
        p, k = self.app.project, self.kind_key
        try:
            daily, days = int(self.v_daily.get()), int(self.v_days.get())
        except (ValueError, tk.TclError):
            return
        if k == "teacher":
            for d, v in ((p.teacher_max_daily, daily), (p.teacher_max_days, days)):
                if v > 0:
                    d[self.cur] = v
                else:
                    d.pop(self.cur, None)
        elif k == "students":
            if daily > 0:
                p.students_max_daily[self.cur] = daily
            else:
                p.students_max_daily.pop(self.cur, None)
        self.app.set_dirty()

    def save_globals(self):
        for attr, v in self.g_vars.items():
            try:
                setattr(self.app.project, attr, max(0, int(v.get())))
            except (ValueError, tk.TclError):
                pass
        self.app.set_dirty()


# ============================================================= التوليد
class GenerateTab(tk.Frame):
    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.q = queue.Queue()
        self.stop_flag = threading.Event()
        self.thread = None
        top = tk.Frame(self)
        top.pack(fill="x", padx=10, pady=8)
        self.seconds = tk.IntVar(value=60)
        self.seed = tk.StringVar(value="")
        self.keep = tk.BooleanVar(value=False)
        self.btn_start = ttk.Button(top, text="▶ ابدأ التوليد", command=self.start)
        self.btn_stop = ttk.Button(top, text="■ إيقاف", command=self.stop, state="disabled")
        self.btn_stop.pack(side="right", padx=4)
        self.btn_start.pack(side="right", padx=4)
        ttk.Spinbox(top, from_=0, to=86400, textvariable=self.seconds, width=7).pack(side="right")
        tk.Label(top, text="أقصى مدة (ثانية، 0 = بلا حد)", font=FONT).pack(side="right", padx=4)
        ttk.Entry(top, textvariable=self.seed, width=8).pack(side="right")
        tk.Label(top, text="بذرة عشوائية (اختياري)", font=FONT).pack(side="right", padx=4)
        ttk.Checkbutton(top, text="ابدأ من الجدول الحالي", variable=self.keep).pack(side="right", padx=8)
        self.prog = ttk.Progressbar(self, maximum=100)
        self.prog.pack(fill="x", padx=10)
        self.status = tk.Label(self, text="جاهز", font=BOLD, anchor="e")
        self.status.pack(fill="x", padx=10, pady=2)
        box = tk.Frame(self)
        box.pack(fill="both", expand=True, padx=10, pady=6)
        sb = ttk.Scrollbar(box)
        sb.pack(side="left", fill="y")
        self.log = tk.Text(box, font=MONO, yscrollcommand=sb.set, wrap="word")
        self.log.pack(side="right", fill="both", expand=True)
        sb.config(command=self.log.yview)

    def refresh(self):
        pass

    def write(self, msg):
        self.log.insert("end", msg + "\n")
        self.log.see("end")

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        p = self.app.project
        if not p.acts:
            messagebox.showinfo("لا توجد حصص", "أضف حصصاً أولاً.")
            return
        self.log.delete("1.0", "end")
        msgs = tt_solver.diagnose(p)
        for m in msgs:
            self.write("⚠ " + m)
        if p.extra_time or p.extra_space:
            self.write(f"⚠ {len(p.extra_time) + len(p.extra_space)} قيداً من الملف غير مدعوم هنا (يُحفظ ولا يُراعى).")
        if msgs and not messagebox.askyesno("تشخيص", "وُجدت استحالات محتملة (انظر السجل). المتابعة رغم ذلك؟"):
            return
        work = p.clone()
        try:
            seed = int(self.seed.get()) if self.seed.get().strip() else None
        except ValueError:
            seed = None
        self.stop_flag.clear()
        self.btn_start.config(state="disabled")
        self.btn_stop.config(state="normal")
        self.status.config(text="جارٍ التوليد…")
        secs, keep = int(self.seconds.get()), bool(self.keep.get())

        def run():
            try:
                r = tt_solver.generate(
                    work, seconds=secs, seed=seed, keep_existing=keep, stop=self.stop_flag.is_set,
                    log=lambda m: self.q.put(("log", m)),
                    progress=lambda f, t: self.q.put(("prog", f, t)))
                self.q.put(("done", r, work))
            except Exception as exc:  # noqa: BLE001
                self.q.put(("error", str(exc)))
        self.thread = threading.Thread(target=run, daemon=True)
        self.thread.start()
        self.after(150, self.poll)

    def stop(self):
        self.stop_flag.set()
        self.status.config(text="جارٍ الإيقاف…")

    def poll(self):
        done = False
        try:
            while True:
                item = self.q.get_nowait()
                if item[0] == "log":
                    self.write(item[1])
                elif item[0] == "prog":
                    self.prog.config(value=item[1] * 100)
                    self.status.config(text=item[2])
                elif item[0] == "error":
                    self.write("خطأ: " + item[1])
                    self.finish()
                    done = True
                elif item[0] == "done":
                    self.on_done(item[1], item[2])
                    done = True
        except queue.Empty:
            pass
        if not done:
            self.after(150, self.poll)

    def finish(self):
        self.btn_start.config(state="normal")
        self.btn_stop.config(state="disabled")

    def on_done(self, r, work):
        p = self.app.project
        p.placements = dict(work.placements)
        p.room_assign = dict(work.room_assign)
        self.prog.config(value=100)
        self.write(f"— النتيجة: تعارضات صلبة = {r.hard_left} · تكلفة ناعمة = {r.soft_cost} · {r.seconds:.1f} ث")
        for m in r.problems[:30]:
            self.write("  ✖ " + m)
        ok = r.hard_left == 0 and not r.problems
        self.status.config(text="✔ جدول بلا تعارضات" if ok else f"انتهى مع {len(r.problems)} مشكلة — راجع السجل")
        self.finish()
        self.app.set_dirty()
        self.app.reload_all()
        if ok:
            self.app.nb.select(self.app.results)


# ============================================================= النتائج
class ResultsTab(tk.Frame):
    KINDS = [("teacher", "الأساتذة"), ("class", "الأقسام"), ("room", "القاعات")]
    C_OK, C_NO, C_SWAP, C_CUR = "#C6EFCE", "#F4B6B6", "#BDD7EE", "#FFE699"

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.view = None
        self.visible = []
        self.problems = []
        self.highlight = set()      # أرقام الحصص المطلوب إبرازها (عند الانتقال من لوحة المشاكل)
        self.cells = {}             # عنصر الواجهة -> (يوم، حصة، Lesson أو None)
        self.drag = None
        self.ghost = None
        self.lock_moved = tk.BooleanVar(value=True)
        bar = tk.Frame(self)
        bar.pack(fill="x", padx=6, pady=4)
        for text, cmd in [("فحص التعارضات", self.conflicts), ("كل الجداول للطباعة", self.html_all),
                          ("الجدول الحالي للطباعة", self.html_current), ("تصدير Excel", self.excel),
                          ("تصدير aSc XML", self.asc)]:
            ttk.Button(bar, text=text, command=cmd).pack(side="right", padx=3)
        ttk.Checkbutton(bar, text="تثبيت الحصة التي أنقلها", variable=self.lock_moved).pack(side="left", padx=6)
        # لوحة المشاكل (أسفل النافذة)
        self.pf = tk.LabelFrame(self, text="لوحة المشاكل", font=BOLD)
        self.pf.pack(side="bottom", fill="x", padx=6, pady=4)
        self.ptree = ttk.Treeview(self.pf, columns=("kind", "text"), show="headings", height=5, selectmode="browse")
        self.ptree.heading("kind", text="النوع")
        self.ptree.heading("text", text="الوصف (انقر للانتقال إلى الحصة المسببة)")
        self.ptree.column("kind", width=90, anchor="e")
        self.ptree.column("text", width=900, anchor="e")
        psb = ttk.Scrollbar(self.pf, command=self.ptree.yview)
        self.ptree.configure(yscrollcommand=psb.set)
        ttk.Button(self.pf, text="تحديث", command=self.update_problems).pack(side="left", padx=4, anchor="n")
        psb.pack(side="left", fill="y")
        self.ptree.pack(side="right", fill="x", expand=True)
        self.ptree.bind("<<TreeviewSelect>>", self.on_problem)
        side = tk.Frame(self)
        side.pack(side="right", fill="y", padx=6, pady=4)
        self.kind = ttk.Combobox(side, state="readonly", values=[k[1] for k in self.KINDS], justify="right")
        self.kind.current(0)
        self.kind.pack(fill="x")
        self.listbox = tk.Listbox(side, width=26, font=FONT, exportselection=False)
        self.listbox.pack(fill="both", expand=True, pady=4)
        main = tk.Frame(self)
        main.pack(side="left", fill="both", expand=True, padx=6, pady=4)
        self.title = tk.Label(main, text="", font=TITLE)
        self.title.pack(fill="x")
        self.hint = tk.Label(main, text="اسحب أي حصة وأفلتها في خانة أخرى (الأخضر مسموح، الأحمر ممنوع، الأزرق تبديل).",
                             font=FONT, anchor="e")
        self.hint.pack(fill="x")
        self.gf = tk.Frame(main)
        self.gf.pack(fill="both", expand=True)
        self.kind.bind("<<ComboboxSelected>>", lambda _e: self._on_kind())
        self.listbox.bind("<<ListboxSelect>>", lambda _e: self._on_pick())

    @property
    def kind_key(self):
        return self.KINDS[self.kind.current()][0]

    def say(self, text, error=False):
        self.hint.config(text=text, fg="#C00000" if error else PAL["fg"])

    def _on_kind(self):
        self.highlight = set()
        self.fill()

    def _on_pick(self):
        self.highlight = set()
        self.show()

    def refresh(self):
        name = self.current()
        self.view = self.app.project.to_view()
        self.fill(select=name)
        self.update_problems()

    def fill(self, select=None):
        self.listbox.delete(0, "end")
        self.visible = []
        if self.view:
            for n in self.view.entities(self.kind_key):
                self.visible.append(n)
                self.listbox.insert("end", f"{n}   ({self.view.weekly_hours(self.kind_key, n)})")
        if self.visible:
            i = self.visible.index(select) if select in self.visible else 0
            self.listbox.selection_set(i)
            self.listbox.see(i)
        self.show()

    def current(self):
        s = self.listbox.curselection()
        return self.visible[s[0]] if s and s[0] < len(self.visible) else None

    # ------------------------------------------------------------- لوحة المشاكل
    def update_problems(self):
        p = self.app.project
        try:
            self.problems = tt_edit.find_problems(p)
        except Exception as exc:  # noqa: BLE001
            print("problems error", exc, file=sys.stderr)
            self.problems = []
        self.ptree.delete(*self.ptree.get_children())
        for i, pr in enumerate(self.problems[:500]):
            self.ptree.insert("", "end", iid=str(i), values=(tt_edit.KIND_TITLE.get(pr.kind, pr.kind), pr.text))
        n = len(self.problems)
        if not p.placements:
            self.pf.config(text="لوحة المشاكل — ولّد الجدول أولاً")
        else:
            self.pf.config(text=f"لوحة المشاكل — {n} مشكلة" if n else "لوحة المشاكل — لا توجد مشاكل ✔")

    def on_problem(self, _e=None):
        sel = self.ptree.selection()
        if sel and int(sel[0]) < len(self.problems):
            self.goto(self.problems[int(sel[0])])

    def goto(self, pr):
        """ينتقل إلى جدول العنصر المعني ويُبرز الحصة المسببة للمشكلة."""
        if pr.entity is None or pr.kind in ("unplaced", "room"):
            if pr.ids and pr.ids[0] in self.app.project.acts:
                self.app.nb.select(self.app.acts)
                tree = self.app.acts.tree
                tree.selection_set(str(pr.ids[0]))
                tree.see(str(pr.ids[0]))
                self.say(pr.text, error=True)
            return
        kinds = [k for k, _ in self.KINDS]
        kind, name = pr.entity
        if self.view is None:
            self.view = self.app.project.to_view()
        if name not in self.view.entities(kind):
            a = self.app.project.acts.get(pr.ids[0]) if pr.ids else None
            if a and a.teachers:
                kind, name = "teacher", a.teachers[0]
        self.app.nb.select(self)
        self.kind.current(kinds.index(kind))
        self.highlight = set(pr.ids)
        self.fill(select=name)
        self.say("⚠ " + pr.text, error=True)

    # ------------------------------------------------------------- الجدول
    def _reg(self, w, d, h, ls):
        self.cells[w] = (d, h, ls)

    def show(self):
        for w in self.gf.winfo_children():
            w.destroy()
        self.cells = {}
        name = self.current()
        if not (self.view and name):
            self.title.config(text="")
            return
        p, kind = self.view, self.kind_key
        self.title.config(text=f"{exporters.KIND_TITLES[kind]}: {name}")
        nd, nh = len(p.real_days), len(p.real_hours)
        g = self.gf
        for c in range(nd + 1):
            g.columnconfigure(c, weight=1, uniform="c")
        for r in range(nh + 1):
            g.rowconfigure(r, weight=1, uniform="r")
        tk.Label(g, text="الحصة", bg="#305496", fg="white", font=BOLD, relief="solid", bd=1).grid(row=0, column=nd, sticky="nsew")
        for d, dn in enumerate(p.real_days):
            tk.Label(g, text=dn, bg="#305496", fg="white", font=BOLD, relief="solid", bd=1).grid(
                row=0, column=nd - 1 - d, sticky="nsew")
        grid, covered, skipped = exporters.build_grid(p, kind, name)
        over = {}       # حصص متداخلة لم تُعرض: تُنسب إلى الحصة المعروضة في نفس الخانة
        for ls in skipped:
            host = grid.get((ls.day, ls.hour)) or next(
                (x for (hd, hh), x in grid.items() if hd == ls.day and hh <= ls.hour < hh + x.span), None)
            if host is not None:
                over.setdefault(id(host), []).append(ls)
        wrap = int(font_size() * 17)
        for h, hn in enumerate(p.real_hours):
            tk.Label(g, text=hn, bg="#D9E1F2", fg="black", font=BOLD, relief="solid", bd=1).grid(
                row=1 + h, column=nd, sticky="nsew")
            for d in range(nd):
                if (d, h) in covered:
                    continue
                ls = grid.get((d, h))
                if ls:
                    lines = p.cell_text(kind, ls)
                    clash = over.get(id(ls), [])
                    ids_here = {ls.activity.id} | {x.activity.id for x in ls.also} | {x.activity.id for x in clash}
                    if clash:
                        lines = lines + ["⚠ تعارض مع: " + "، ".join(
                            f"{x.activity.subject} (حصة {x.activity.id})" for x in clash)]
                    lb = tk.Label(g, text="\n".join(lines), bg=subject_color(ls.activity.subject), fg="black",
                                  font=FONT, relief="solid", bd=1, wraplength=wrap, justify="center", cursor="hand2",
                                  highlightthickness=0)
                    if ids_here & self.highlight:
                        lb.configure(highlightthickness=5, highlightbackground="#E00000", highlightcolor="#E00000")
                    elif clash:
                        lb.configure(highlightthickness=2, highlightbackground="#C00000", highlightcolor="#C00000")
                    lb.grid(row=1 + h, column=nd - 1 - d, rowspan=ls.span, sticky="nsew")
                    self._reg(lb, d, h, ls)
                    lb.bind("<ButtonPress-1>", lambda e, w=lb: self.press(e, w))
                    lb.bind("<B1-Motion>", self.motion)
                    lb.bind("<ButtonRelease-1>", self.release)
                else:
                    lb = tk.Label(g, text="", relief="solid", bd=1, bg=PAL["field"], fg="black")
                    lb.grid(row=1 + h, column=nd - 1 - d, sticky="nsew")
                    self._reg(lb, d, h, None)

    # ------------------------------------------------------------- سحب وإفلات
    def press(self, ev, w):
        d, h, ls = self.cells.get(w, (None, None, None))
        if ls is None:
            return
        self.drag = {"aid": ls.activity.id, "x": ev.x_root, "y": ev.y_root, "started": False, "w": w}

    def motion(self, ev):
        dr = self.drag
        if not dr:
            return
        if not dr["started"]:
            if abs(ev.x_root - dr["x"]) + abs(ev.y_root - dr["y"]) < 6:
                return
            dr["started"] = True
            self.start_drag(dr["aid"])
            first = str(dr["w"].cget("text")).split("\n")[0] if dr.get("w") is not None else ""
            self.ghost = tk.Label(self, text=first, bg=self.C_CUR, fg="black", relief="raised", bd=2, font=BOLD)
        if self.ghost is not None:
            self.ghost.place(x=ev.x_root - self.winfo_rootx() + 10, y=ev.y_root - self.winfo_rooty() + 10)
        self._hover(self.winfo_containing(ev.x_root, ev.y_root))

    def start_drag(self, aid):
        """يلوّن الخانات: أخضر مسموح، أحمر ممنوع، أزرق تبديل ممكن، أصفر مكان الحصة الحالي."""
        p = self.app.project
        ids = set(tt_edit.bundle_ids(p, aid))
        smap = tt_edit.slot_map(p, aid)
        info = {"map": smap, "swap": {}}
        for w, (d, h, ls) in self.cells.items():
            if ls is None:
                w.configure(bg=self.C_NO if smap.get((d, h)) else self.C_OK)
            elif ls.activity.id in ids:
                w.configure(bg=self.C_CUR)
            else:
                why = tt_edit.swap_reasons(p, aid, ls.activity.id)
                info["swap"][w] = why
                w.configure(bg=self.C_NO if why else self.C_SWAP)
        if self.drag is not None:
            self.drag.update(info)
        return info

    def _hover(self, w):
        dr = self.drag
        if not dr or w not in self.cells:
            return
        d, h, ls = self.cells[w]
        if ls is None:
            why = dr["map"].get((d, h), [])
            self.say("✔ يمكن وضعها هنا" if not why else "✖ " + "؛ ".join(why[:3]), error=bool(why))
        elif w in dr["swap"]:
            why = dr["swap"][w]
            self.say("⇄ تبديل ممكن" if not why else "✖ لا يمكن التبديل: " + "؛ ".join(why[:3]), error=bool(why))

    def release(self, ev):
        dr, self.drag = self.drag, None
        if self.ghost is not None:
            self.ghost.destroy()
            self.ghost = None
        if not dr:
            return
        if not dr["started"]:
            self.describe(dr["aid"])
            return
        w = self.winfo_containing(ev.x_root, ev.y_root)
        if w in self.cells:
            d, h, ls = self.cells[w]
            self.drop_on(dr["aid"], d, h, ls.activity.id if ls else None)
        else:
            self.show()

    def describe(self, aid):
        a = self.app.project.acts[aid]
        n = len(tt_edit.bundle_ids(self.app.project, aid))
        room = self.app.project.room_assign.get(aid) or a.room or "/".join(a.rooms)
        self.say(f"حصة {aid}: {a.subject} — {'، '.join(a.teachers)} — {'، '.join(a.students)}"
                 + (f" — قاعة {room}" if room else "") + (f" — متزامنة مع {n - 1} أخرى" if n > 1 else "")
                 + (" 📌" if aid in self.app.project.locked else ""))

    def drop_on(self, aid, d, h, other=None) -> bool:
        """ينقل الحصة aid إلى (d, h) أو يبدّلها مع الحصة other. يعيد True عند النجاح."""
        p = self.app.project
        ids = tt_edit.bundle_ids(p, aid)
        if other is not None and other in ids:
            self.show()
            return False
        lock = bool(self.lock_moved.get()) or bool(tt_edit.locked_in(p, aid))
        if other is None:
            if p.placements.get(aid) == (d, h):
                self.show()
                return False
            why = tt_edit.reasons(p, tt_edit.Board(p, exclude=set(ids)), ids, d, h)
            if why:
                self.say("✖ لا يمكن النقل: " + "؛ ".join(why[:3]), error=True)
                self.show()
                return False
            tt_edit.apply_move(p, aid, d, h, lock=lock)
            msg = f"✔ نُقلت الحصة {aid} إلى {p.days[d]} — {p.periods[h]}" + (" (مثبّتة 📌)" if lock else "")
        else:
            why = tt_edit.swap_reasons(p, aid, other)
            if why:
                self.say("✖ لا يمكن التبديل: " + "؛ ".join(why[:3]), error=True)
                self.show()
                return False
            tt_edit.apply_swap(p, aid, other, lock=lock)
            msg = f"✔ بُدّلت الحصتان {aid} و{other}" + (" (مثبّتتان 📌)" if lock else "")
        self.app.set_dirty()
        self.app.reload_all()
        self.say(msg)
        return True

    # ------------------------------------------------------------- أدوات
    def _need(self):
        if not self.app.project.placements:
            messagebox.showinfo("لا يوجد جدول", "ولّد الجدول أولاً.")
            return False
        self.view = self.app.project.to_view()
        return True

    def conflicts(self):
        if not self._need():
            return
        self.update_problems()
        n = len(self.problems)
        if not n:
            messagebox.showinfo("فحص التعارضات", "لا توجد مشاكل في الجدول (تعارضات، عدم توفّر، حدود، قيود).")
            return
        messagebox.showwarning("المشاكل", f"عدد المشاكل: {n}\n\nانقر أي مشكلة في «لوحة المشاكل» أسفل النافذة "
                                          "للانتقال إلى الحصة المسببة لها.")

    def _open_html(self, items):
        path = os.path.join(tempfile.gettempdir(), "timetables.html")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(exporters.standalone_html(self.view, items))
        webbrowser.open("file:///" + path.replace("\\", "/"))

    def html_current(self):
        n = self.current()
        if self._need() and n:
            self._open_html([(self.kind_key, n)])

    def html_all(self):
        if self._need():
            self._open_html(exporters.all_items(self.view, (self.kind_key,)))

    def excel(self):
        if not self._need():
            return
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", initialfile="الجداول.xlsx",
                                            filetypes=[("Excel", "*.xlsx")])
        if not path:
            return
        try:
            n = exporters.export_excel(self.view, path)
        except ImportError:
            messagebox.showerror("ينقص openpyxl", "نفّذ في نافذة الأوامر:\npip install openpyxl")
            return
        messagebox.showinfo("تم", f"تم تصدير {n} جدول إلى:\n{path}")

    def asc(self):
        self.app.export_asc()


# ============================================================= التطبيق
def apply_style(root) -> None:
    """مظهر أحدث: سمة النظام، خطوط واضحة، صفوف أعرض، عناوين بارزة."""
    st = ttk.Style(root)
    for theme in ("vista", "winnative", "clam"):
        if theme in st.theme_names():
            st.theme_use(theme)
            break
    st.configure("TButton", padding=(10, 4), font=FONT)
    st.configure("Treeview", rowheight=row_height(), font=FONT)
    st.configure("Treeview.Heading", font=BOLD)
    st.configure("TNotebook.Tab", padding=(14, 6), font=BOLD)
    st.configure("Accent.TButton", font=BOLD)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.geometry("1250x760")
        self.prefs = load_prefs()
        init_fonts(self, self.prefs["font"])
        self.project = Project()
        self.path = ""
        self.dirty = False
        self.history = History()
        self.history.reset(self.project)
        apply_style(self)
        self.theme = Theme(self)
        self.var_dark = tk.BooleanVar(value=self.prefs["dark"])
        self._menu()
        self._toolbar()
        self.status = tk.Label(self, text="", anchor="e", relief="sunken", font=FONT, padx=8)
        self.status.pack(side="bottom", fill="x")
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=4, pady=4)
        self.settings = SettingsTab(self.nb, self)
        self.names = NamesTab(self.nb, self)
        self.classes = ClassesTab(self.nb, self)
        self.acts = ActsTab(self.nb, self)
        self.cons = ConstraintsTab(self.nb, self)
        self.adv = app_constraints.ConstraintsHub(self.nb, self)
        self.gen = GenerateTab(self.nb, self)
        self.results = ResultsTab(self.nb, self)
        self.tabs = [self.settings, self.names, self.classes, self.acts, self.cons, self.adv, self.gen, self.results]
        titles = ["① الإعدادات", "② الأساتذة والمواد والقاعات", "③ الأقسام", "④ الحصص", "⑤ التوفّر والحدود",
                  "⑥ القيود (زمانية ومكانية)", "⑦ التوليد", "⑧ الجداول والتصدير"]
        # الواجهة عربية: نضيف التبويبات بترتيب معكوس ليبدأ ① من أقصى اليمين
        for tab, title in reversed(list(zip(self.tabs, titles))):
            self.nb.add(tab, text=title)
        self.nb.select(self.settings)
        self.bind("<Control-s>", lambda _e: self.save())
        self.bind("<Control-o>", lambda _e: self.open_dialog())
        self.bind("<Control-Key>", self._ctrl_key)
        self.bind_class("Toplevel", "<Map>", lambda e: self.theme.walk(e.widget) if self.theme.dark else None)
        self.protocol("WM_DELETE_WINDOW", self.quit_app)
        self.reload_all()
        if self.prefs["dark"]:
            self.theme.apply(True)
        self._update_undo()

    def _toolbar(self):
        bar = tk.Frame(self, bd=1, relief="groove")
        bar.pack(side="top", fill="x")
        for text, cmd, style in [("⚙ توليد الجدول", self.go_generate, "Accent.TButton"),
                                 ("⤓ تصدير aSc", self.export_asc, "TButton"),
                                 ("💾 حفظ", self.save, "TButton"),
                                 ("📂 فتح", self.open_dialog, "TButton"),
                                 ("🆕 جديد", self.new, "TButton")]:
            ttk.Button(bar, text=text, command=cmd, style=style).pack(side="right", padx=3, pady=4)
        ttk.Button(bar, text="❓ دليل سريع", command=self.help).pack(side="left", padx=6)
        ttk.Button(bar, text="A+", width=3, command=self.font_bigger).pack(side="left", padx=1)
        ttk.Button(bar, text="A−", width=3, command=self.font_smaller).pack(side="left", padx=1)
        ttk.Button(bar, text="🌙 داكن / ☀ فاتح", command=self.toggle_dark).pack(side="left", padx=6)
        self.btn_redo = ttk.Button(bar, text="↷ إعادة", command=self.redo)
        self.btn_redo.pack(side="left", padx=2)
        self.btn_undo = ttk.Button(bar, text="↶ تراجع", command=self.undo)
        self.btn_undo.pack(side="left", padx=2)

    def go_generate(self):
        self.nb.select(self.gen)
        self.gen.start()

    def help(self):
        messagebox.showinfo("دليل سريع", "1) الإعدادات: الأيام والحصص ونمط اليوم.\n"
                            "2) أضف الأساتذة والمواد والقاعات والأقسام.\n"
                            "3) أضف الحصص (يدوياً أو من Excel).\n"
                            "4) التوفّر والحدود ثم القيود المتقدمة.\n"
                            "5) التوليد ثم الجداول والتصدير (Excel / طباعة / aSc).")

    def _status(self, prefix: str = ""):
        p = self.project
        n_pl = sum(1 for a in p.acts if a in p.placements)
        self.status.config(text=prefix + f"{len(p.teachers)} أستاذ · {len(p.classes())} قسم · {len(p.acts)} حصة "
                                f"({n_pl} موضوعة) · {len(p.constraints)} قيد متقدم · {len(p.rooms)} قاعة")

    # ---- قائمة
    def _menu(self):
        m = tk.Menu(self)
        f = tk.Menu(m, tearoff=0)
        f.add_command(label="مشروع جديد", command=self.new)
        f.add_command(label="فتح ملف FET…   Ctrl+O", command=self.open_dialog)
        f.add_command(label="حفظ   Ctrl+S", command=self.save)
        f.add_command(label="حفظ باسم…", command=self.save_as)
        f.add_separator()
        f.add_command(label="تصدير إلى aSc (XML)…", command=self.export_asc)
        f.add_command(label="تحويل ملف FET جاهز إلى aSc…", command=self.convert_file)
        f.add_separator()
        f.add_command(label="مشروع تجريبي", command=self.load_demo)
        f.add_command(label="خروج", command=self.quit_app)
        m.add_cascade(label="ملف", menu=f)
        e = tk.Menu(m, tearoff=0)
        e.add_command(label="تراجع   Ctrl+Z", command=self.undo)
        e.add_command(label="إعادة   Ctrl+Y", command=self.redo)
        m.add_cascade(label="تحرير", menu=e)
        v = tk.Menu(m, tearoff=0)
        v.add_checkbutton(label="الوضع الداكن", variable=self.var_dark, command=self.toggle_dark_menu)
        v.add_command(label="تكبير الخط   Ctrl +", command=self.font_bigger)
        v.add_command(label="تصغير الخط   Ctrl −", command=self.font_smaller)
        v.add_command(label="حجم الخط الافتراضي   Ctrl 0", command=self.font_reset)
        m.add_cascade(label="عرض", menu=v)
        self.config(menu=m)

    def report_callback_exception(self, exc, val, tb):
        """يُظهر أي خطأ غير متوقع في نافذة بدل أن يتجاهله البرنامج بصمت (مهم في نسخة exe بلا شاشة أوامر)."""
        import traceback
        msg = "".join(traceback.format_exception(exc, val, tb))
        try:
            with open(os.path.join(os.path.expanduser("~"), "timetabler_error.log"), "a", encoding="utf-8") as fh:
                fh.write(msg + "\n")
        except OSError:
            pass
        try:
            messagebox.showerror("خطأ غير متوقع", f"{val}\n\nالتفاصيل محفوظة في:\n~/timetabler_error.log")
        except Exception:  # noqa: BLE001
            print(msg, file=sys.stderr)

    def set_dirty(self):
        self.dirty = True
        self.history.commit(self.project)
        self._retitle()
        self._update_undo()

    def _retitle(self):
        name = os.path.basename(self.path) if self.path else "بلا اسم"
        self.title(f"مولّد الجداول — {name}{' *' if self.dirty else ''}")

    def reload_all(self):
        for t in self.tabs:
            try:
                t.refresh()
            except Exception as exc:  # noqa: BLE001
                print("refresh error", t, exc, file=sys.stderr)
        self._retitle()
        self._status()
        if self.theme.dark:
            self.theme.walk()

    # ---- تراجع / إعادة
    def _busy(self) -> bool:
        t = getattr(self.gen, "thread", None)
        return bool(t and t.is_alive())

    def _update_undo(self):
        try:
            self.btn_undo.config(state="normal" if self.history.can_undo else "disabled")
            self.btn_redo.config(state="normal" if self.history.can_redo else "disabled")
        except tk.TclError:
            pass

    def _restore(self, pr, what: str):
        pr.path = self.path
        self.project = pr
        self.dirty = True
        self.reload_all()
        self._status(what + " — ")
        self._update_undo()

    def undo(self):
        if self._busy():
            return
        pr = self.history.undo()
        if pr is not None:
            self._restore(pr, "تم التراجع")
        self._update_undo()

    def redo(self):
        if self._busy():
            return
        pr = self.history.redo()
        if pr is not None:
            self._restore(pr, "تمت الإعادة")
        self._update_undo()

    def _text_focus(self) -> bool:
        try:
            w = self.focus_get()
            return w is not None and w.winfo_class() in ("Entry", "Text", "TEntry", "TCombobox", "Spinbox", "TSpinbox")
        except Exception:  # noqa: BLE001
            return False

    def _ctrl_key(self, e):
        """اختصارات مستقلة عن لغة لوحة المفاتيح (تعمل مع العربية أيضاً)."""
        if self._text_focus():
            return None
        k = (getattr(e, "keysym", "") or "").lower()
        code = getattr(e, "keycode", 0) if sys.platform == "win32" else 0
        shift = bool(getattr(e, "state", 0) & 1)
        if k == "z" or code == 90:
            (self.redo if shift else self.undo)()
        elif k == "y" or code == 89:
            self.redo()
        elif k in ("plus", "equal") or code in (187, 107):
            self.font_bigger()
        elif k in ("minus", "underscore") or code in (189, 109):
            self.font_smaller()
        elif k == "0" or code in (48, 96):
            self.font_reset()
        else:
            return None
        return "break"

    # ---- سمة وخط
    def toggle_dark(self):
        self.set_dark(not self.theme.dark)

    def toggle_dark_menu(self):
        self.set_dark(bool(self.var_dark.get()))

    def set_dark(self, dark: bool):
        self.prefs["dark"] = bool(dark)
        self.var_dark.set(bool(dark))
        save_prefs(self.prefs)
        self.theme.apply(dark)
        self.reload_all()
        self.theme.walk()

    def set_font_size(self, n: int):
        n = resize_fonts(n)
        self.prefs["font"] = n
        save_prefs(self.prefs)
        ttk.Style(self).configure("Treeview", rowheight=row_height())
        for nm in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
            try:
                import tkinter.font as tkfont
                tkfont.nametofont(nm).configure(size=n)
            except Exception:  # noqa: BLE001
                pass
        self.reload_all()

    def font_bigger(self):
        self.set_font_size(font_size() + 1)

    def font_smaller(self):
        self.set_font_size(font_size() - 1)

    def font_reset(self):
        self.set_font_size(DEFAULT_FONT)

    def _confirm_discard(self) -> bool:
        return not self.dirty or messagebox.askyesno("تغييرات غير محفوظة", "تجاهل التغييرات غير المحفوظة؟")

    # ---- ملفات
    def new(self):
        if self._confirm_discard():
            self.project, self.path, self.dirty = Project(), "", False
            self.history.reset(self.project)
            self.reload_all()
            self._update_undo()

    def load_demo(self):
        if self._confirm_discard():
            import make_demo
            self.project, self.path, self.dirty = make_demo.demo(16), "", True
            self.history.reset(self.project)
            self.reload_all()
            self._update_undo()

    def open_dialog(self):
        path = filedialog.askopenfilename(title="فتح ملف FET", filetypes=[("FET", "*.fet"), ("All", "*.*")])
        if path:
            self.open_file(path)

    def open_file(self, path):
        if not self._confirm_discard():
            return
        try:
            self.project = Project.load(path)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("تعذّر فتح الملف", str(exc))
            return
        self.path, self.dirty = path, False
        self.history.reset(self.project)
        self.reload_all()
        self._update_undo()
        extra = len(self.project.extra_time) + len(self.project.extra_space)
        if extra:
            messagebox.showinfo("تنبيه", f"في الملف {extra} قيداً غير مدعوم في هذا المولّد؛ سيُحفظ كما هو "
                                          "لكنه لن يُراعى عند التوليد.")

    def save(self):
        if not self.path:
            return self.save_as()
        self._save_to(self.path)

    def save_as(self):
        path = filedialog.asksaveasfilename(defaultextension=".fet", filetypes=[("FET", "*.fet")])
        if path:
            self._save_to(path)

    def _save_to(self, path):
        try:
            self.project.save(path)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("فشل الحفظ", str(exc))
            return
        self.path, self.dirty = path, False
        self.project.path = path
        self._retitle()

    def export_asc(self):
        p = self.project
        if not p.placements:
            messagebox.showinfo("لا يوجد جدول", "ولّد الجدول أولاً (أو افتح ملف FET يحتوي الأوقات).")
            return
        base = os.path.splitext(os.path.basename(self.path))[0] if self.path else "timetable"
        path = filedialog.asksaveasfilename(defaultextension=".xml", initialfile=f"{base}_aSc.xml",
                                            filetypes=[("aSc XML", "*.xml")])
        if not path:
            return
        n = asc_export.export_asc(p, path)
        messagebox.showinfo("تم", f"صُدّرت {n} حصة إلى:\n{path}\nاستورده في aSc Timetables.")

    def convert_file(self):
        src = filedialog.askopenfilename(title="ملف FET جاهز", filetypes=[("FET", "*.fet"), ("All", "*.*")])
        if not src:
            return
        try:
            p = Project.load(src)
            out = filedialog.asksaveasfilename(defaultextension=".xml",
                                               initialfile=os.path.splitext(os.path.basename(src))[0] + "_aSc.xml",
                                               filetypes=[("aSc XML", "*.xml")])
            if out:
                n = asc_export.export_asc(p, out)
                messagebox.showinfo("تم", f"حُوّلت {n} حصة ({len(p.placements)} بوقت) إلى:\n{out}")
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("فشل التحويل", str(exc))

    def quit_app(self):
        if self._confirm_discard():
            self.destroy()


def main():
    app = App()
    if len(sys.argv) > 1 and os.path.isfile(sys.argv[1]):
        app.open_file(sys.argv[1])
    app.mainloop()


if __name__ == "__main__":
    main()
