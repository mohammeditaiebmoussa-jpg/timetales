"""اختبار كل قيد على حدة: نولّد ثم نتحقق باستقلال من تحقق القيد في النتيجة."""
import os, sys, collections
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import make_demo, tt_solver
from tt_constraints import Constraint

def fresh():
    return make_demo.demo(8, per_teacher=4, unavail_teachers=0)

def run(p, secs=12):
    r = tt_solver.generate(p, seconds=secs, seed=1)
    return r

def seg_masks(p, kind, name):
    """يعيد {(day, half): مجموعة الحصص المشغولة} لأستاذ/فوج."""
    H = p.half_len; out = collections.defaultdict(set)
    for a in p.acts.values():
        d, pp = p.placements[a.id]
        for k in range(a.duration):
            who = a.teachers if kind == "teacher" else [lf for s in a.students for lf in p.leaves(s)]
            if name in who: out[(d, (pp + k) // H)].add((pp + k) % H)
    return out

ok = True
def check(label, cond, extra=""):
    global ok
    print(("PASS " if cond else "FAIL ") + label, extra)
    ok &= bool(cond)

# 1) أقصى فراغات أسبوعياً = 0 لكل الأساتذة (وزن 100)
p = fresh(); p.constraints = [Constraint("max_gaps_week", "teacher", "", 0, True)]
r = run(p); m = {t: sum((max(s) - min(s) + 1) - len(s) for k, s in seg_masks(p, "teacher", t).items()) for t in p.teachers}
check("max_gaps_week=0", r.hard_left == 0 and max(m.values()) == 0, f"hard={r.hard_left}")

# 2) أقصى ساعات متتالية = 2 لكل الأقسام
p = fresh(); p.constraints = [Constraint("max_hours_cont", "students", "", 2, True)]
r = run(p)
def maxrun(s):
    best = cur = 0
    for k in range(8):
        cur = cur + 1 if k in s else 0; best = max(best, cur)
    return best
lv = {lf for y in p.years for g in y.groups for lf in g.subgroups}
check("max_hours_cont=2", r.hard_left == 0 and all(maxrun(s) <= 2 for l in lv for s in seg_masks(p, "students", l).values()), f"hard={r.hard_left}")

# 3) أدنى ساعات يومية = 2 للأساتذة
p = fresh(); p.constraints = [Constraint("min_hours_daily", "teacher", "", 2, True)]
r = run(p)
check("min_hours_daily=2", r.hard_left == 0 and all(len(s) >= 2 for t in p.teachers for s in seg_masks(p, "teacher", t).values()), f"hard={r.hard_left}")

# 4) أقصى امتداد = 3 للأقسام
p = fresh(); p.constraints = [Constraint("max_span_day", "students", "", 3, True)]
r = run(p)
check("max_span_day=3", r.hard_left == 0 and all(max(s) - min(s) + 1 <= 3 for l in lv for s in seg_masks(p, "students", l).values()), f"hard={r.hard_left}")

# 5) أستاذ محدد: أقصى أيام 3 (min_days_week 3 مع max عبر basic)
p = fresh(); t0 = p.teachers[0]
p.constraints = [Constraint("min_days_week", "teacher", t0, 5, True)]
r = run(p); days = {d for (d, h) in seg_masks(p, "teacher", t0)}
check("min_days_week=5", r.hard_left == 0 and len(days) == 5, f"days={len(days)}")

# 6) أقصى صباحات = 2 لأستاذ
p = fresh(); t0 = p.teachers[1]
p.constraints = [Constraint("max_mornings", "teacher", t0, 2, True)]
r = run(p); mornings = {d for (d, h) in seg_masks(p, "teacher", t0) if h == 0}
check("max_mornings=2", r.hard_left == 0 and len(mornings) <= 2, f"mornings={len(mornings)}")

# 7) حصص: نفس الوقت، نفس اليوم، لا تتداخل، أيام بين الحصص، متتاليتان، ترتيب، أوقات مفضلة
p = fresh(); ids = sorted(p.acts)
a, b = ids[0], ids[40]
p.constraints = [Constraint("same_time", "acts", ids=[a, b])]
r = run(p); check("same_time", r.hard_left == 0 and p.placements[a] == p.placements[b], f"hard={r.hard_left} {p.placements[a]} {p.placements[b]}")

p = fresh(); p.constraints = [Constraint("same_day", "acts", ids=[a, b])]
r = run(p); check("same_day", r.hard_left == 0 and p.placements[a][0] == p.placements[b][0], f"hard={r.hard_left}")

p = fresh(); c, d = ids[1], ids[2]
p.constraints = [Constraint("consecutive", "acts", ids=[c, d])]
r = run(p); pc, pd = p.placements[c], p.placements[d]
check("consecutive", r.hard_left == 0 and pc[0] == pd[0] and pd[1] == pc[1] + p.acts[c].duration, f"hard={r.hard_left} {pc} {pd}")

p = fresh(); p.constraints = [Constraint("ordered", "acts", ids=[c, d])]
r = run(p); pc, pd = p.placements[c], p.placements[d]
check("ordered", r.hard_left == 0 and pc[0] == pd[0] and pd[1] >= pc[1] + p.acts[c].duration, f"hard={r.hard_left} {pc} {pd}")

p = fresh(); p.constraints = [Constraint("min_days", "acts", value=2, ids=[c, d, ids[3]])]
r = run(p); dd = sorted(p.placements[i][0] for i in (c, d, ids[3]))
check("min_days=2", r.hard_left == 0 and all(dd[i + 1] - dd[i] >= 2 for i in range(2)), f"hard={r.hard_left} {dd}")

p = fresh(); slots = [(0, 0), (0, 1), (2, 4)]
p.constraints = [Constraint("pref_times", "acts", ids=[c], slots=slots)]
r = run(p); check("pref_times(hard)", r.hard_left == 0 and p.placements[c] in slots, f"{p.placements[c]}")

p = fresh(); p.constraints = [Constraint("pref_times", "acts", ids=[c], slots=[(4, 7)], weight=60)]
r = run(p); check("pref_times(soft)", r.hard_left == 0)

# 8) قاعات: قاعة ثابتة لقسم/مادة
p = fresh(); grp = p.years[0].groups[0].name
p.constraints = [Constraint("home_students", "students", grp, rooms=["مخبر1"]),
                 Constraint("subject_rooms", "subject", "العربية", rooms=["مخبر2", "مخبر1"])]
r = run(p)
rooms_ok = all(p.room_assign.get(a.id) == "مخبر1" for a in p.acts.values() if grp in a.students and not a.room and not a.rooms and a.subject != "العربية") 
check("home_students room assigned", r.hard_left == 0 and rooms_ok and not r.problems, f"{r.problems[:2]}")
arabic = [a.id for a in p.acts.values() if a.subject == "العربية" and grp not in a.students]
check("subject_rooms assigned", all(p.room_assign.get(i) in ("مخبر1", "مخبر2") for i in arabic))
# تعارض قاعتين: لا يجتمع نشاطان في مخبر1 بنفس الوقت
occ = collections.Counter()
for a in p.acts.values():
    rm = p.room_assign.get(a.id)
    if rm:
        d, pp = p.placements[a.id]
        for k in range(a.duration): occ[(rm, d, pp + k)] += 1
check("no room double booking", max(occ.values()) == 1)

# 9) قراءة/كتابة FET للقيود
from tt_model import Project
p = fresh()
p.constraints = [Constraint("max_gaps_week", "teacher", "", 1, True, weight=90), Constraint("max_hours_cont", "students", p.years[0].groups[0].name, 3, True),
                 Constraint("min_days", "acts", value=1, flag=True, ids=[1, 2, 3]), Constraint("consecutive", "acts", ids=[4, 5]),
                 Constraint("pref_times", "acts", ids=[6], slots=[(0, 0), (1, 5)]), Constraint("home_teacher", "teacher", p.teachers[0], rooms=["مخبر1"]),
                 Constraint("subject_rooms", "subject", "العربية", rooms=["مخبر1", "مخبر2"])]
p.save("/tmp/c.fet"); q = Project.load("/tmp/c.fet")
def key(c): return (c.kind, c.who, c.target, c.value, tuple(c.ids), tuple(sorted(c.slots)), tuple(c.rooms), c.weight)
check("fet round trip constraints", sorted(map(key, p.constraints)) == sorted(map(key, q.constraints)) and not q.extra_time and not q.extra_space,
      f"{len(q.constraints)}/{len(p.constraints)}")
print("ALL OK" if ok else "SOME FAILED")
