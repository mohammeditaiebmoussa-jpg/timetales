"""توافق مع FET: وسوم أوقات البدء المفضّلة الحقيقية، والاستراحة لا تُحسب فراغاً ولا تكسر التجاور."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import xml.etree.ElementTree as ET
import tt_constraints as tc
import tt_solver
import make_demo
from tt_model import Project

ok = True
def check(name, cond, extra=""):
    global ok
    ok &= bool(cond)
    print(("PASS" if cond else "FAIL"), name, extra)

# 1) ConstraintActivityPreferredStartingTimes بوسوم FET الحقيقية (Preferred_Starting_Day/Hour)
xml = """<ConstraintActivityPreferredStartingTimes><Weight_Percentage>100</Weight_Percentage>
<Activity_Id>3</Activity_Id><Number_of_Preferred_Starting_Times>2</Number_of_Preferred_Starting_Times>
<Preferred_Starting_Time><Preferred_Starting_Day>A</Preferred_Starting_Day><Preferred_Starting_Hour>h1</Preferred_Starting_Hour></Preferred_Starting_Time>
<Preferred_Starting_Time><Preferred_Starting_Day>B</Preferred_Starting_Day><Preferred_Starting_Hour>h2</Preferred_Starting_Hour></Preferred_Starting_Time>
<Active>true</Active></ConstraintActivityPreferredStartingTimes>"""
days, hours = ["A", "B"], ["h1", "h2"]
def to_real(d, h):
    return (days.index(d), hours.index(h)) if d in days and h in hours else None
c = tc.from_element(ET.fromstring(xml), to_real)
check("قراءة أوقات البدء المفضّلة", c is not None and sorted(c.slots) == [(0, 0), (1, 1)], getattr(c, "slots", None))
e = tc.to_element(c, lambda d, p: (days[d], hours[p]))[1]
check("كتابتها بوسوم FET", e.find("Preferred_Starting_Time/Preferred_Starting_Day") is not None)

# 2) الاستراحة: لا فراغ ولا كسر للتجاور
p = make_demo.demo(8)
p.constraints.append(tc.Constraint("break_times", "", slots=[(d, 2) for d in range(p.n_days)]))
s = tt_solver.Solver(p, seed=1)
check("skipb يتخطى الاستراحة", s.skipb[2] == 3 and s.skipb[1] == 1)
check("cpos يضغط الاستراحة", s.cpos[0][3] == s.cpos[0][2] and s.cpos[0][3] == 2, s.cpos[0][:5])
print("ALL OK" if ok else "SOME FAILED")
sys.exit(0 if ok else 1)
