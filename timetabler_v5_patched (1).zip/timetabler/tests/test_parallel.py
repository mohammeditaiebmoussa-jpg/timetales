"""اختبار الحصص المتزامنة: أستاذان مختلفان يدرّسان نفس القسم في نفس الحصة."""
import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import tt_model, tt_solver, exporters, asc_export

ok = True
def check(label, cond, extra=""):
    global ok
    print(("PASS " if cond else "FAIL ") + label, extra)
    ok &= bool(cond)

def base():
    p = tt_model.Project()
    p.days = ["د1", "د2", "د3"]
    p.periods = [f"ح{i}" for i in range(1, 5)]
    p.halves = 1
    p.teachers = ["أ", "ب", "ج"]
    p.subjects = ["عربية", "تمازيغية", "رياضيات"]
    p.years = [tt_model.Year("س1", [tt_model.Group("ق1", [])])]
    return p

# 1) بدون تزامن: حصتان لنفس القسم لا تتداخلان أبداً
p = base()
p.add_activities(["أ"], "عربية", ["ق1"], [2])
p.add_activities(["ب"], "تمازيغية", ["ق1"], [2])
r = tt_solver.generate(p, seconds=3, seed=1)
v = p.to_view()
same = len({tuple(p.placements[i]) for i in p.acts}) == 1
check("بدون تزامن: لا تداخل", r.hard_left == 0 and not same and not v.conflicts())

# 2) مع التزامن: نفس الوقت، بلا تعارض، والأستاذان مختلفان
p = base()
a = p.add_activities(["أ"], "عربية", ["ق1"], [2, 1])
b = p.add_activities(["ب"], "تمازيغية", ["ق1"], [2, 1])
p.add_parallel_to(a[0], b)
check("ربط سلسلة بسلسلة", [p.acts[i].parallel for i in a + b].count(0) == 0
      and p.acts[a[0]].parallel == p.acts[b[0]].parallel != p.acts[a[1]].parallel)
c = p.add_activities(["ج"], "رياضيات", ["ق1"], [1])
r = tt_solver.generate(p, seconds=4, seed=2)
check("المولّد: لا تعارض صلب", r.hard_left == 0, f"hard={r.hard_left} {r.problems[:3]}")
check("أ وب في نفس الوقت", p.placements[a[0]] == p.placements[b[0]] and p.placements[a[1]] == p.placements[b[1]])
check("حصة ج لا تتداخل مع القسم", all(p.placements[c[0]] != p.placements[x] for x in a + b))
v = p.to_view()
check("فحص التعارضات نظيف", not v.conflicts(), str(v.conflicts()[:2]))
check("ساعات القسم تُحتسب مرة واحدة", v.weekly_hours("class", "ق1") == 2 + 1 + 1, str(v.weekly_hours("class", "ق1")))
grid, covered, skipped = exporters.build_grid(v, "class", "ق1")
merged = [ls for ls in grid.values() if ls.also]
check("العرض: خانة واحدة تجمع الحصتين ولا حصص مُهمَلة", len(merged) == 2 and not skipped)
txt = "\n".join(v.cell_text("class", merged[0]))
check("نص الخانة يحوي المادتين والأستاذين", all(x in txt for x in ["عربية", "تمازيغية", "أ", "ب"]))
check("عرض الأستاذ لا يتأثر", all(not ls.also for ls in v.lessons) and
      not any(ls.also for ls in exporters.build_grid(v, "teacher", "أ")[0].values()))
# تكرار بناء الشبكة لا يضاعف المحتوى
g2 = exporters.build_grid(v, "class", "ق1")[0]
check("بناء الشبكة مكرراً ثابت", all(len(ls.also) == 1 for ls in g2.values() if ls.also))

# 3) حفظ وقراءة
fd, path = tempfile.mkstemp(suffix=".fet"); os.close(fd)
p.save(path)
q = tt_model.Project.load(path)
check("الحفظ/القراءة يحفظ التزامن", {i: q.acts[i].parallel for i in q.acts} == {i: p.acts[i].parallel for i in p.acts})
check("FetProject.load يقرأ التزامن", any(x.parallel for x in __import__("fet_model").FetProject.load(path).activities.values()))
os.remove(path)

# 4) تصدير aSc: فوجان مختلفان للحصتين المتزامنتين
xml = asc_export.build_asc_xml(p)
import re
lessons = re.findall(r'<lesson id="\*(\d+)"[^>]*groupids="([^"]*)"', xml)
gid = {int(i): g for i, g in lessons}
check("aSc: فوج مختلف لكل حصة متزامنة", gid[a[0]] != gid[b[0]] and gid[a[0]] == gid[a[1]])

# 5) تحقق الأخطاء
p2 = base()
x = p2.add_activities(["أ"], "عربية", ["ق1"], [1])[0]
y = p2.add_activities(["أ"], "تمازيغية", ["ق1"], [1])[0]
try:
    p2.link_parallel([x, y]); check("نفس الأستاذ مرفوض", False)
except ValueError:
    check("نفس الأستاذ مرفوض", True)
z = p2.add_activities(["ب"], "رياضيات", ["ق1"], [2])[0]
try:
    p2.link_parallel([x, z]); check("مدد مختلفة مرفوضة", False)
except ValueError:
    check("مدد مختلفة مرفوضة", True)

# 6) استيراد بعمود التزامن
p3 = base()
p3.import_rows([["أ", "عربية", "ق1", "2+1", "", "G1"], ["ب", "تمازيغية", "ق1", "2+1", "", "G1"]])
check("الاستيراد يربط بالرمز", sum(1 for a_ in p3.acts.values() if a_.parallel) == 4 and not p3.import_parallel_errors)

# 7) فكّ التزامن
p3.unlink_parallel(list(p3.acts))
check("فكّ التزامن", all(a_.parallel == 0 for a_ in p3.acts.values()))
print("ALL OK" if ok else "SOME FAILED")
sys.exit(0 if ok else 1)
