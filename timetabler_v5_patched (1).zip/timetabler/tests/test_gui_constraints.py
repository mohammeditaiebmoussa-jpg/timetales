"""واجهة القيود الجديدة (محاكي tkinter): إضافة/تعديل/حذف لكل تصنيف ثم توليد."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fake_tk
tk = fake_tk.install()
import app_tk, make_demo, tt_constraints as tcm

app = app_tk.App()
app.project = make_demo.demo(8, per_teacher=4)
app.project.rooms += ["قاعة أ", "قاعة ب", "قاعة ج"]
app.reload_all()
hub, ed, p = app.adv, app.adv.editor, app.project
ids = sorted(p.acts)
ok = True
def check(label, cond, extra=""):
    global ok
    print(("PASS " if cond else "FAIL ") + label, extra); ok &= bool(cond)

def new(cat, kind, who):
    hub.tree.sel = [f"type:{cat}:{kind}:{who}"]; hub.on_tree()
    return ed

# شجرة: كل التصنيفات موجودة
nodes = [i for i in hub.tree.items if str(i).startswith("cat:")]
check("tree has all categories", len(nodes) == len(tcm.CATEGORIES), f"{len(nodes)}")
types = [i for i in hub.tree.items if str(i).startswith("type:")]
check("tree has many constraint types", len(types) >= 35, f"{len(types)}")

# زمانية للطلاب
e = new("time_students", "max_gaps_week", "students"); e.w["target"].set("(الجميع)"); e.w["value"].set(1); e.save()
check("students max_gaps_week", any(c.kind == "max_gaps_week" and c.who == "students" and c.value == 1 for c in p.constraints))
# زمانية للأساتذة: ساعات يومية -> الحقول الأساسية (جسر)
e = new("time_teachers", "max_hours_daily", "teacher"); e.w["target"].set(p.teachers[0]); e.w["value"].set(4); e.save()
check("teacher max_hours_daily bridged to basic", p.teacher_max_daily.get(p.teachers[0]) == 4 and not any(c.kind == "max_hours_daily" for c in p.constraints))
e = new("time_teachers", "min_hours_daily", "teacher"); e.w["target"].set("(الجميع)"); e.w["value"].set(2); e.save()
check("teachers min_hours_daily", any(c.kind == "min_hours_daily" and not c.target for c in p.constraints))
# حصص: متتاليتان
e = new("time_acts", "consecutive", "acts"); e.w["pickers"][0].ids = [ids[0]]; e.w["pickers"][1].ids = [ids[1]]; e.save()
check("consecutive", any(c.kind == "consecutive" and c.ids == [ids[0], ids[1]] for c in p.constraints))
e = new("time_acts", "grouped3", "acts"); [setattr(pk, "ids", [ids[i]]) for i, pk in zip((5, 6, 7), e.w["pickers"])]; e.save()
check("grouped3", any(c.kind == "grouped3" and len(c.ids) == 3 for c in p.constraints))
e = new("time_acts", "pref_slots", "acts"); e.w["acts"].ids = [ids[2]]; e.w["grid"].slots = {(0, 0), (0, 1), (1, 0), (1, 1)}; e.save()
check("pref_slots", any(c.kind == "pref_slots" and len(c.slots) == 4 for c in p.constraints))
e = new("time_acts", "same_hour", "acts"); e.w["acts"].ids = [ids[9], ids[40]]; e.save()
e = new("time_acts", "min_days", "acts"); e.w["acts"].ids = [ids[3], ids[4]]; e.w["value"].set(2); e.save()
check("min_days value", any(c.kind == "min_days" and c.value == 2 for c in p.constraints))
e = new("time_acts", "ends_students_day", "acts"); e.w["acts"].ids = [ids[11]]; e.save()
e = new("time_acts", "acts_pref_slots", "acts"); e.w["f_subject"].set("الرياضة"); e.w["f_duration"].set(2); e.w["grid"].slots = {(d, q) for d in range(5) for q in range(4, 8)}; e.save()
check("acts_pref_slots filter", any(c.kind == "acts_pref_slots" and c.f_subject == "الرياضة" and c.f_duration == 2 for c in p.constraints))
# عامة
e = new("time_global", "break_times", ""); e.w["grid"].slots = {(d, 3) for d in range(5)}; e.save()
check("break_times", any(c.kind == "break_times" and len(c.slots) == 5 for c in p.constraints))
# مكانية
e = new("space_students", "home_students", "students"); e.w["target"].set(p.years[0].groups[0].name); e.w["rooms"].sel = [3]; e.save()
e = new("space_subjects", "subject_rooms", "subject"); e.w["target"].set("العربية"); e.w["rooms"].sel = [4, 5]; e.save()
e = new("space_acts", "acts_rooms", "acts"); e.w["f_subject"].set("الفلسفة"); e.w["rooms"].sel = [4]; e.save()
check("space constraints", {c.kind for c in p.constraints} >= {"home_students", "subject_rooms", "acts_rooms"})
# أخطاء التحقق لا تُحفظ
n0 = len(p.constraints)
e = new("time_acts", "same_time", "acts"); e.w["acts"].ids = [ids[0]]; e.save()
check("validation rejects 1 activity", len(p.constraints) == n0 and "حصتين" in fake_tk.MSG[-1][1])
e = new("time_acts", "consecutive", "acts"); e.w["pickers"][0].ids = [ids[0]]; e.w["pickers"][1].ids = [ids[0]]; e.save()
check("validation rejects same act twice", len(p.constraints) == n0)
e = new("time_global", "break_times", ""); e.save()
check("validation rejects empty slots", len(p.constraints) == n0)

# الجدول يعرض كل شيء + المرشّح بالتصنيف
hub.show_all(); total = len(hub.rows)
hub.tree.sel = ["cat:time_acts"]; hub.on_tree(); acts_rows = len(hub.rows)
check("table filter by category", 0 < acts_rows < total, f"{acts_rows}/{total}")
hub.show_all()
# تعديل
i = next(i for i, c in enumerate(p.constraints) if c.kind == "min_days")
hub.table.sel = [f"c{i}"]; hub.edit(); check("edit loads editor", ed.ref == ("c", i) and ed.kind == "min_days")
ed.w["value"].set(3); ed.save(); check("edit saved", p.constraints[i].value == 3)
# تفعيل/تعطيل
hub.table.sel = [f"c{i}"]; hub.toggle(); check("toggle", p.constraints[i].active is False); hub.toggle()
# حذف صف أساسي
brow = next(k for k, (ref, c) in hub.rows.items() if ref[0] == "b" and ref[1] == ("max_hours_daily", "teacher", p.teachers[0]))
hub.table.sel = [brow]; hub.delete(); check("delete basic row", p.teacher_max_daily.get(p.teachers[0]) is None)
# قيد غير مدعوم من ملف يظهر ويُحذف
p.extra_time.append("<ConstraintTeacherMaxThreeConsecutiveDays><Weight_Percentage>100</Weight_Percentage><Teacher>x</Teacher></ConstraintTeacherMaxThreeConsecutiveDays>")
hub.refresh(); trow = next(k for k, (ref, c) in hub.rows.items() if ref[0] == "t")
hub.table.sel = [trow]; hub.edit(); check("unsupported shows info", "لا يدعمه" in fake_tk.MSG[-1][1])
hub.delete(); check("unsupported deleted", not p.extra_time)

# توليد مع كل القيود
app.reload_all(); app.gen.seconds.set(15); app.gen.seed.set("1"); app.gen.start(); fake_tk.pump()
rep = tt_edit_problems = None
import tt_edit
probs = tt_edit.find_problems(p)
check("generation with all constraints", len(p.placements) == len(p.acts) and not [x for x in probs if x.kind in ("clash", "rule", "limit")],
      f"placed={len(p.placements)}/{len(p.acts)} problems={[x.text for x in probs][:3]}")
print("ALL OK" if ok else "SOME FAILED")
