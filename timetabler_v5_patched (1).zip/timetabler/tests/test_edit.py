"""اختبار التعديل اليدوي (تلوين الممنوع، نقل، تبديل) ولوحة المشاكل."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import tt_model, tt_solver, tt_edit, make_demo
from tt_constraints import Constraint

ok = True
def check(label, cond, extra=""):
    global ok
    print(("PASS " if cond else "FAIL ") + label, extra)
    ok &= bool(cond)

def base():
    p = tt_model.Project()
    p.days = ["د1", "د2", "د3"]; p.periods = [f"ح{i}" for i in range(1, 5)]; p.halves = 1
    p.teachers = ["أ", "ب", "ج"]; p.subjects = ["ع", "ر", "ف"]
    p.years = [tt_model.Year("س", [tt_model.Group("ق1", []), tt_model.Group("ق2", [])])]
    p.rooms = ["م1"]
    return p

p = base()
a = p.add_activities(["أ"], "ع", ["ق1"], [1])[0]
b = p.add_activities(["ب"], "ر", ["ق1"], [1])[0]
c = p.add_activities(["أ"], "ف", ["ق2"], [2])[0]
p.placements = {a: (0, 0), b: (0, 1), c: (1, 0)}
p.unavail[("teacher", "ب")] = {(2, 3)}

# 1) خريطة الخانات
m = tt_edit.slot_map(p, a)
check("الخانة الحالية مسموحة", m[(0, 0)] == [])
check("قسم مشغول يُمنع", any("القسم" in r for r in m[(0, 1)]))
check("أستاذ مشغول يُمنع (حصة ج الممتدة)", any("الأستاذ «أ»" in r for r in m[(1, 0)]) and any("الأستاذ «أ»" in r for r in m[(1, 1)]))
check("خانة حرة مسموحة", m[(2, 0)] == [])
mb = tt_edit.slot_map(p, b)
check("عدم توفّر الأستاذ يُمنع", any("غير متوفر" in r for r in mb[(2, 3)]))
mc = tt_edit.slot_map(p, c)
check("حصة ساعتين لا تتجاوز نهاية اليوم", mc[(0, 3)] and "نهاية" in mc[(0, 3)][0])

# 2) نقل
tt_edit.apply_move(p, a, 2, 0)
check("النقل ينفَّذ", p.placements[a] == (2, 0))
check("لا مشاكل بعد النقل", not [x for x in tt_edit.find_problems(p) if x.kind != "unplaced"])

# 3) تبديل
r = tt_edit.swap_reasons(p, a, b)
check("تبديل صالح", r == [], str(r))
pa, pb = p.placements[a], p.placements[b]
tt_edit.apply_swap(p, a, b)
check("التبديل ينفَّذ", p.placements[a] == pb and p.placements[b] == pa)
p.placements[b] = (2, 3)           # في وقت غير متوفر للأستاذ ب
pr = tt_edit.find_problems(p)
check("مشكلة عدم توفّر مع إحداثيات وعنصر", any(x.kind == "unavail" and x.entity == ("teacher", "ب") and x.day == 2 and x.period == 3 for x in pr), str([x.text for x in pr]))
r = tt_edit.swap_reasons(p, a, c)
check("تبديل ممنوع يعطي أسباباً", isinstance(r, list))

# 4) تعارض وانتقال
p.placements[b] = p.placements[a]
pr = tt_edit.find_problems(p)
cl = [x for x in pr if x.kind == "clash"]
check("تعارض قسم وأستاذ؟ (قسم ق1 فقط)", any(x.entity == ("class", "ق1") and set(x.ids) == {a, b} for x in cl), str([x.text for x in cl]))

# 5) غير موضوعة
del p.placements[c]
pr = tt_edit.find_problems(p)
check("غير موضوعة", any(x.kind == "unplaced" and x.ids == [c] for x in pr))

# 6) حدود يومية
p2 = base(); p2.default_teacher_max_daily = 2
ids = [p2.add_activities(["أ"], "ع", ["ق1"], [1])[0] for _ in range(3)]
p2.placements = {ids[0]: (0, 0), ids[1]: (0, 1), ids[2]: (1, 0)}
mm = tt_edit.slot_map(p2, ids[2])
check("حدّ ساعات الأستاذ يمنع الخانة", any("يتجاوز 2" in r for r in mm[(0, 2)]))
p2.placements[ids[2]] = (0, 2)
check("لوحة المشاكل تلتقط الحدّ", any(x.kind == "limit" for x in tt_edit.find_problems(p2)))

# 7) حصص متزامنة تتحرك معاً
p3 = base()
x = p3.add_activities(["أ"], "ع", ["ق1"], [1])[0]
y = p3.add_activities(["ب"], "ر", ["ق1"], [1])[0]
z = p3.add_activities(["ج"], "ف", ["ق1"], [1])[0]
p3.link_parallel([x, y])
p3.placements = {x: (0, 0), y: (0, 0), z: (0, 1)}
check("لا مشكلة بين المتزامنتين", not tt_edit.find_problems(p3))
check("وحدة واحدة", tt_edit.bundle_ids(p3, x) == sorted([x, y]))
mx = tt_edit.slot_map(p3, y)
check("خانة المتزامنتين الحالية مسموحة وخانة ج ممنوعة", mx[(0, 0)] == [] and mx[(0, 1)])
tt_edit.apply_move(p3, y, 1, 2)
check("النقل يحرّك المتزامنة معاً", p3.placements[x] == p3.placements[y] == (1, 2))
p3.locked.add(x)
check("مثبّتة", tt_edit.locked_in(p3, y) == [x])

# 8) قيود متقدمة (فراغات) تظهر كمشكلة
p4 = make_demo.demo(4, per_teacher=3, unavail_teachers=0)
p4.constraints = [Constraint("max_gaps_week", "teacher", "", 0, True)]
tt_solver.generate(p4, seconds=6, seed=1)
check("جدول جيد بلا مشاكل صلبة", not [x for x in tt_edit.find_problems(p4) if x.kind != "unplaced"], str([x.text for x in tt_edit.find_problems(p4)[:3]]))
t0 = p4.teachers[0]
mine = sorted([i for i, a_ in p4.acts.items() if t0 in a_.teachers])
if len(mine) >= 2:
    # أبعد حصة أخرى لهذا الأستاذ إلى آخر اليوم لإحداث فراغ
    p4.placements[mine[0]] = (0, 0); p4.placements[mine[1]] = (0, p4.n_periods - 1)
    pr4 = tt_edit.find_problems(p4)
    check("مخالفة قيد الفراغات تظهر", any(x.kind in ("rule", "clash", "unavail", "limit") for x in pr4), str(len(pr4)))
print("ALL OK" if ok else "SOME FAILED")
sys.exit(0 if ok else 1)
