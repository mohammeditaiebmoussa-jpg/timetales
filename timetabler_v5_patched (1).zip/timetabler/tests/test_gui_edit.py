"""اختبار واجهة: سحب/إفلات، تراجع/إعادة، لوحة المشاكل، السمة الداكنة، حجم الخط (بلا شاشة)."""
import os, sys, json, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ["TIMETABLER_PREFS"] = os.path.join(tempfile.gettempdir(), "tt_prefs_test.json")
if os.path.exists(os.environ["TIMETABLER_PREFS"]): os.remove(os.environ["TIMETABLER_PREFS"])
import fake_tk
tk = fake_tk.install()
import app_tk, make_demo, tt_solver, tt_edit

ok = True
def check(label, cond, extra=""):
    global ok
    print(("PASS " if cond else "FAIL ") + label, extra)
    ok &= bool(cond)

app = app_tk.App()
app.project = make_demo.demo(6, per_teacher=3, unavail_teachers=0)
app.history.reset(app.project)
app.reload_all()
check("لا تراجع في البداية", not app.history.can_undo)

# توليد ثم تراجع/إعادة
app.gen.seconds.set(6); app.gen.seed.set("1"); app.gen.start(); fake_tk.pump()
n_pl = len(app.project.placements)
check("التوليد وُضعت الحصص", n_pl == len(app.project.acts), str(n_pl))
check("التوليد قابل للتراجع", app.history.can_undo)
app.undo()
check("التراجع يلغي التوليد", len(app.project.placements) == 0)
app.redo()
check("الإعادة تعيد الجدول", len(app.project.placements) == n_pl)

# سحب وإفلات
R = app.results
R.refresh()
p = app.project
aid = sorted(p.acts)[0]
smap = tt_edit.slot_map(p, aid)
free = [k for k, v in smap.items() if not v and k != p.placements[aid]]
bad = [k for k, v in smap.items() if v]
old = p.placements[aid]
check("توجد خانات مسموحة وممنوعة", bool(free) and bool(bad))
R.show(); info = R.start_drag(aid)
check("start_drag يحسب الخريطة", info["map"] == smap)
if bad:
    before = dict(p.placements)
    check("إفلات في خانة ممنوعة مرفوض", R.drop_on(aid, *bad[0]) is False and p.placements == before)
d, h = free[0]
check("إفلات في خانة مسموحة ينجح", R.drop_on(aid, d, h) is True and p.placements[aid] == (d, h))
check("الحصة المنقولة مثبّتة", aid in p.locked)
check("النقل قابل للتراجع", app.history.can_undo)
app.undo()
check("التراجع يعيد المكان", app.project.placements[aid] == old and aid not in app.project.locked)
p = app.project
# تبديل
a2 = next(i for i in sorted(p.acts) if i != aid and not tt_edit.swap_reasons(p, aid, i))
pa, pb = p.placements[aid], p.placements[a2]
check("تبديل ينجح", R.drop_on(aid, 0, 0, a2) is True and p.placements[aid] == pb and p.placements[a2] == pa)
app.undo()
p = app.project

# لوحة المشاكل
check("جدول سليم بلا تعارضات في اللوحة", not [x for x in R.problems if x.kind == "clash"])
b2 = next(i for i in sorted(p.acts) if i != aid and set(p.acts[i].students) & set(p.acts[aid].students))
p.placements[b2] = p.placements[aid]
R.update_problems()
cl = [x for x in R.problems if x.kind == "clash"]
check("اللوحة تُظهر التعارض", any({aid, b2} <= set(x.ids) for x in cl), str(len(R.problems)))
pr = next(x for x in cl if {aid, b2} <= set(x.ids))
R.goto(pr)
check("الانتقال يحدّد العنصر ويُبرز الحصص", R.highlight >= {aid, b2} and R.current() == pr.entity[1])
R.ptree.sel = ["0"]; R.on_problem()
check("on_problem يعمل", True)
del p.placements[b2]
R.update_problems()
un = [x for x in R.problems if x.kind == "unplaced"]
check("غير موضوعة تظهر", any(x.ids == [b2] for x in un))
R.goto(next(x for x in un if x.ids == [b2]))
check("الانتقال لغير الموضوعة يحدّد الحصة في تبويب الحصص", app.acts.tree.sel == [str(b2)])

# سمة وخط
app.set_dark(True)
check("وضع داكن", app.theme.dark and app_tk.PAL["bg"] == app_tk.Theme.DARK["bg"])
check("حُفظ في التفضيلات", json.load(open(os.environ["TIMETABLER_PREFS"]))["dark"] is True)
app.set_dark(False)
check("وضع فاتح", not app.theme.dark and app_tk.PAL["field"] == "white")
f0 = app_tk.font_size()
app.font_bigger(); check("تكبير الخط", app_tk.font_size() == f0 + 1 and app_tk.FONT.o["size"] == f0 + 1)
app.font_smaller(); app.font_reset()
check("إعادة الحجم", app_tk.font_size() == app_tk.DEFAULT_FONT)
for _ in range(30): app.font_bigger()
check("حدّ أقصى للخط", app_tk.font_size() == app_tk.MAX_FONT)
app.font_reset()
prefs = app_tk.load_prefs()
check("تحميل التفضيلات", prefs["font"] == app_tk.DEFAULT_FONT and prefs["dark"] is False)

# اختصارات
class E: keysym = "z"; keycode = 90; state = 0
app.set_dirty()
app._ctrl_key(E())
print("ALL OK" if ok else "SOME FAILED")
sys.exit(0 if ok else 1)
