import os, sys, time, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fake_tk
tk = fake_tk.install()
import app_tk

errs = []
app = app_tk.App()
import make_demo
app.project = make_demo.demo(8, per_teacher=4)
app.reload_all()
print("tabs refreshed; acts:", len(app.project.acts))
# قيود: اختر أستاذاً وبدّل خانة
app.cons.kind.current(0); app.cons.fill_list()
app.cons.lb.selection_set(0); app.cons.select()
app.cons.toggle(1, 2); app.cons.toggle_day(3); app.cons.toggle_period(0)
app.cons.v_daily.set(5); app.cons.v_days.set(4); app.cons.save_limits()
t0 = app.project.teachers[0]
print("limits:", app.project.teacher_max_daily.get(t0), app.project.teacher_max_days.get(t0), "unavail slots:", len(app.project.unavail.get(("teacher", t0), ())))
# إضافة حصة من النموذج
app.acts.t_lb.items = list(app.project.teachers); app.acts.t_lb.sel = [0]
app.acts.s_lb.items = list(app.project.all_group_names()); app.acts.s_lb.sel = [0]
app.acts.subj.value = "مادة جديدة"; app.acts.pattern.set("2+1"); app.acts.room.value = ""
n0 = len(app.project.acts); app.acts.add(); print("added acts:", len(app.project.acts) - n0)
# توليد
app.gen.seconds.set(8); app.gen.seed.set("1")
app.gen.start()
fake_tk.pump()
print("placed:", len(app.project.placements), "of", len(app.project.acts))
print("log tail:", app.gen.log.text.strip().splitlines()[-2:])
# نتائج
app.results.refresh(); app.results.listbox.selection_set(0); app.results.show()
app.results.conflicts(); print("messages:", fake_tk.MSG[-1])
# تصدير aSc
out = os.path.join(tempfile.gettempdir(), "smoke_asc.xml")
tk.filedialog.paths.append(out); app.export_asc(); print("asc exists:", os.path.exists(out), os.path.getsize(out))
# حفظ وفتح
fp = os.path.join(tempfile.gettempdir(), "smoke.fet")
tk.filedialog.paths.append(fp); app.save_as(); print("saved:", os.path.exists(fp))
app.dirty = False; app.open_file(fp); print("reopened acts:", len(app.project.acts), "placements:", len(app.project.placements))
# تعديل الإعدادات (يمسح الجدول)
app.settings.days.text = "\n".join(app.project.days[:4]); app.settings.periods.text = "\n".join(app.project.periods)
app.settings.halves.set("2"); app.settings.apply(); print("after settings: days", len(app.project.days), "placements", len(app.project.placements))
print("OK")

