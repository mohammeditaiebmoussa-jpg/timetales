"""بديل خفيف لـ tkinter لاختبار منطق الواجهة بلا شاشة (يُستعمل في الاختبارات فقط)."""
import sys, types

_after_queue = []
MSG = []   # رسائل messagebox المعترضة


class W:
    def __init__(self, *a, **k):
        self.children = []
        self.opts = dict(k)
        self.master = a[0] if a and isinstance(a[0], W) else None
        if self.master is not None:
            self.master.children.append(self)
        self.binds = {}
        self.items = []
        self.sel = []
        self.text = ""
        self.cur = 0
        self.value = ""
        self.tv = k.get("textvariable")
    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return lambda *a, **k: None
    def pack(self, *a, **k): return None
    def grid(self, *a, **k): return None
    def place(self, *a, **k): return None
    def config(self, *a, **k): self.opts.update(k)
    configure = config
    def bind(self, seq, fn, *a): self.binds[seq] = fn
    def winfo_children(self): return list(self.children)
    def destroy(self):
        if self.master: 
            try: self.master.children.remove(self)
            except ValueError: pass
    def after(self, ms, fn=None, *a): _after_queue.append(fn)
    def wait_window(self, w): pass
    def mainloop(self): pass
    # Listbox
    def insert(self, idx, *vals, **k):
        if isinstance(self, Text):
            self.text += vals[0]; return
        if isinstance(self, Treeview):
            return self._tv_insert(idx, *vals, **k)
        self.items.extend(vals)
    def delete(self, *args):
        a = args[0] if args else None
        if isinstance(self, Text): self.text = ""; return
        if isinstance(self, Treeview): return self._tv_delete(a)
        self.items = []; self.sel = []
    def get(self, a=None, b=None):
        if isinstance(self, Text): return self.text
        if isinstance(self, Listbox): return self.items[a]
        if isinstance(self, (Combobox, Entry)):
            return self.tv.get() if self.tv is not None else self.value
        return None
    def curselection(self): return tuple(self.sel)
    def selection_set(self, i): self.sel = [i]
    def current(self, i=None):
        if i is None: return self.cur
        self.cur = i
    def set(self, v): self.value = v


class Listbox(W): pass
class Text(W): pass
class Entry(W): pass
class Combobox(W): pass
class Treeview(W):
    def _tv_insert(self, parent, idx, iid=None, text="", values=(), **k):
        self.items.append(iid)
        return iid
    def _tv_delete(self, *a): self.items = []
    def get_children(self, *a): return list(self.items)
    def selection(self): return tuple(self.sel)
    def item(self, iid, opt=None): return ""


class Var:
    def __init__(self, master=None, value=None, **k): self.v = "" if value is None else value
    def get(self): return self.v
    def set(self, v): self.v = v
    def trace_add(self, *a, **k): pass


class Tk(W):
    def title(self, t=None): self._title = t
    def geometry(self, g): pass


def install():
    tk = types.ModuleType("tkinter")
    for n in ["Frame", "Label", "LabelFrame", "Toplevel", "Menu", "Scrollbar", "Button", "Canvas"]:
        setattr(tk, n, type(n, (W,), {}))
    tk.Tk, tk.Listbox, tk.Text, tk.Entry = Tk, Listbox, Text, Entry
    tk.StringVar = tk.IntVar = tk.BooleanVar = Var
    tk.TclError = type("TclError", (Exception,), {})
    ttk = types.ModuleType("tkinter.ttk")
    for n in ["Button", "Entry", "Spinbox", "Checkbutton", "Progressbar", "Scrollbar", "Notebook", "Label"]:
        setattr(ttk, n, type(n, (W,), {}))
    ttk.Entry = type("Entry", (Entry,), {})
    class Style(W):
        def theme_names(self): return ["clam"]
    ttk.Style = Style
    ttk.Combobox, ttk.Treeview = Combobox, Treeview
    font = types.ModuleType("tkinter.font")
    class Font:
        def __init__(self, root=None, **k): self.o = dict(k)
        def configure(self, **k): self.o.update(k)
        def cget(self, k): return self.o.get(k)
    font.Font = Font
    font.nametofont = lambda n, *a, **k: Font()
    tk.font = font
    sys.modules["tkinter.font"] = font
    fd = types.ModuleType("tkinter.filedialog")
    mb = types.ModuleType("tkinter.messagebox")
    sd = types.ModuleType("tkinter.simpledialog")
    fd.paths = []
    fd.askopenfilename = lambda **k: fd.paths.pop(0) if fd.paths else ""
    fd.asksaveasfilename = lambda **k: fd.paths.pop(0) if fd.paths else ""
    for n in ["showinfo", "showwarning", "showerror"]:
        setattr(mb, n, lambda t, m, *a, **k: MSG.append((t, m)))
    mb.askyesno = lambda *a, **k: True
    sd.askstring = lambda *a, **k: None
    tk.ttk, tk.filedialog, tk.messagebox, tk.simpledialog = ttk, fd, mb, sd
    sys.modules.update({"tkinter": tk, "tkinter.ttk": ttk, "tkinter.filedialog": fd,
                        "tkinter.messagebox": mb, "tkinter.simpledialog": sd})
    return tk


def pump(max_rounds=2000, sleep=0.05):
    import time
    for _ in range(max_rounds):
        if not _after_queue:
            return
        fn = _after_queue.pop(0)
        fn()
        time.sleep(sleep)
