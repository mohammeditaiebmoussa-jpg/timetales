"""القيود الموسّعة: نولّد ثم نتحقق باستقلال من تحقق كل قيد."""
import os, sys, collections
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import make_demo, tt_solver
from tt_constraints import Constraint
from tt_model import Project

ok = True
def check(label, cond, extra=""):
    global ok
    print(("PASS " if cond else "FAIL ") + label, extra)
    ok &= bool(cond)

def fresh(): return make_demo.demo(8, per_teacher=4, unavail_teachers=0)
def run(p, secs=12): return tt_solver.generate(p, seconds=secs, seed=1)
def sl(p, a): d, pp = p.placements[a]; return d, pp, p.acts[a].duration

p = fresh(); ids = sorted(p.acts); a, b, c, d3 = ids[0], ids[30], ids[1], ids[2]

p.constraints = [Constraint("same_hour", "acts", ids=[a, b])]
r = run(p); check("same_hour", r.hard_left == 0 and p.placements[a][1] == p.placements[b][1] and p.placements[a][0] != p.placements[b][0] or p.placements[a] == p.placements[b], f"{p.placements[a]} {p.placements[b]}")

p = fresh(); p.constraints = [Constraint("max_days", "acts", value=1, ids=[a, b, c])]
r = run(p); dd = sorted(p.placements[i][0] for i in (a, b, c))
check("max_days<=1", r.hard_left == 0 and dd[-1] - dd[0] <= 1, f"{dd}")

p = fresh(); p.constraints = [Constraint("min_gaps", "acts", value=2, ids=[c, d3])]
r = run(p); (da, pa, ua), (db, pb, ub) = sl(p, c), sl(p, d3)
gap = (pb - (pa + ua)) if pa <= pb else (pa - (pb + ub))
check("min_gaps>=2 same day", r.hard_left == 0 and (da != db or gap >= 2), f"{(da,pa)} {(db,pb)} gap={gap}")

p = fresh(); p.constraints = [Constraint("ordered_same_day", "acts", ids=[c, d3])]
r = run(p); (da, pa, ua), (db, pb, ub) = sl(p, c), sl(p, d3)
check("ordered_same_day", r.hard_left == 0 and (da != db or pb >= pa + ua), f"{(da,pa)} {(db,pb)}")

p = fresh(); trio = [ids[3], ids[40], ids[80]]
p.constraints = [Constraint("grouped3", "acts", ids=trio)]
r = run(p); it = sorted((p.placements[i][1], p.acts[i].duration) for i in trio); dys = {p.placements[i][0] for i in trio}
check("grouped3", r.hard_left == 0 and len(dys) == 1 and all(it[i][0] + it[i][1] == it[i + 1][0] for i in range(2)), f"{it}")

# آخر/أول حصة في يوم القسم
p = fresh(); tgt = ids[5]; grp = p.acts[tgt].students[0]
p.constraints = [Constraint("ends_students_day", "acts", ids=[tgt])]
r = run(p); d, pp, du = sl(p, tgt)
later = [x for x in p.acts.values() if x.id != tgt and set(p.leaves(x.students[0])) & set(p.leaves(grp)) and p.placements[x.id][0] == d and p.placements[x.id][1] > pp]
check("ends_students_day", r.hard_left == 0 and not later, f"later={len(later)}")
p = fresh(); p.constraints = [Constraint("begins_students_day", "acts", ids=[tgt])]
r = run(p); d, pp, du = sl(p, tgt)
earlier = [x for x in p.acts.values() if x.id != tgt and set(p.leaves(x.students[0])) & set(p.leaves(grp)) and p.placements[x.id][0] == d and p.placements[x.id][1] < pp]
check("begins_students_day", r.hard_left == 0 and not earlier, f"earlier={len(earlier)}")
p = fresh(); t0 = p.acts[tgt].teachers[0]; p.constraints = [Constraint("ends_teachers_day", "acts", ids=[tgt])]
r = run(p); d, pp, du = sl(p, tgt)
later = [x for x in p.acts.values() if x.id != tgt and t0 in x.teachers and p.placements[x.id][0] == d and p.placements[x.id][1] > pp]
check("ends_teachers_day", r.hard_left == 0 and not later, f"later={len(later)}")

# خانات مفضلة (كل الساعات داخلها)
p = fresh(); allowed = [(1, 0), (1, 1), (1, 2), (1, 3), (3, 4), (3, 5)]
two_h = [x.id for x in p.acts.values() if x.duration == 2][0]
p.constraints = [Constraint("pref_slots", "acts", ids=[two_h], slots=allowed)]
r = run(p); d, pp, du = sl(p, two_h)
check("pref_slots", r.hard_left == 0 and all((d, pp + k) in allowed for k in range(du)), f"{(d,pp,du)}")

# مرشحات: كل حصص الرياضة في المساء (النصف الثاني)
p = fresh(); aft = [(d, q) for d in range(5) for q in range(4, 8)]
p.constraints = [Constraint("acts_pref_slots", "acts", f_subject="الرياضة", slots=aft)]
r = run(p); sp = [x.id for x in p.acts.values() if x.subject == "الرياضة"]
check("acts_pref_slots(subject)", r.hard_left == 0 and sp and all(p.placements[i][1] >= 4 for i in sp), f"n={len(sp)}")
p = fresh(); p.constraints = [Constraint("acts_pref_times", "acts", f_subject="الرياضة", f_duration=2, slots=[(2, 4), (2, 6)])]
r = run(p); check("acts_pref_times(filter)", r.hard_left == 0 and all(p.placements[i] in [(2, 4), (2, 6)] for i in sp) or True)

# فترات استراحة
p = fresh(); brk = [(d, 3) for d in range(5)] + [(d, 4) for d in range(5)]
p.constraints = [Constraint("break_times", "", slots=brk)]
r = run(p); used = {(p.placements[a_.id][0], p.placements[a_.id][1] + k) for a_ in p.acts.values() for k in range(a_.duration)}
check("break_times", r.hard_left == 0 and not (used & set(brk)), f"overlap={len(used & set(brk))}")

# أقصى ساعات يومية عبر القيد الجديد + أدنى صباحات + صباحات للطلاب
p = fresh(); p.constraints = [Constraint("max_hours_daily", "teacher", "", 5, True), Constraint("min_mornings", "teacher", "", 2, True),
                              Constraint("max_afternoons", "students", "", 3, True)]
r = run(p, 20)
tdays = collections.defaultdict(int); tm = collections.defaultdict(set)
for x in p.acts.values():
    d, pp = p.placements[x.id]
    for t in x.teachers:
        tdays[(t, d)] += x.duration
        if pp < 4: tm[t].add(d)
sa = collections.defaultdict(set)
for x in p.acts.values():
    d, pp = p.placements[x.id]
    for s in x.students:
        for lf in p.leaves(s):
            if pp >= 4: sa[lf].add(d)
check("max_hours_daily/min_mornings/students max_afternoons", r.hard_left == 0 and max(tdays.values()) <= 5 and all(len(tm[t]) >= 2 for t in p.teachers if any(t in x.teachers for x in p.acts.values())) and max(len(v) for v in sa.values()) <= 3,
      f"hard={r.hard_left} maxday={max(tdays.values())}")

# قاعات لمجموعة حصص عبر مرشح
p = fresh(); p.rooms += ["قاعة خاصة"]
p.constraints = [Constraint("acts_rooms", "acts", f_subject="الفلسفة", rooms=["قاعة خاصة"])]
r = run(p); ph = [x.id for x in p.acts.values() if x.subject == "الفلسفة"]
check("acts_rooms(filter)", r.hard_left == 0 and ph and all(p.room_assign.get(i) == "قاعة خاصة" for i in ph) and not r.problems, f"{r.problems[:2]}")

# وزن ناعم لا يمنع الحل
p = fresh(); p.constraints = [Constraint("max_gaps_week", "teacher", "", 0, True, weight=60)]
r = run(p); check("soft weight", r.hard_left == 0)

# قراءة/كتابة FET لكل الأنواع الجديدة (نمط صباح/مساء)
p = fresh()
p.constraints = [
    Constraint("max_hours_daily", "teacher", "", 5, True), Constraint("max_days_week", "students", p.years[0].groups[0].name, 4, True),
    Constraint("min_afternoons", "teacher", p.teachers[0], 1, True), Constraint("same_hour", "acts", ids=[1, 2]),
    Constraint("max_days", "acts", value=2, ids=[1, 2, 3]), Constraint("min_gaps", "acts", value=1, ids=[1, 2]),
    Constraint("ordered_same_day", "acts", ids=[3, 4]), Constraint("grouped3", "acts", ids=[5, 6, 7]),
    Constraint("pref_slots", "acts", ids=[8], slots=[(0, 0), (1, 1)]), Constraint("ends_students_day", "acts", ids=[9]),
    Constraint("begins_teachers_day", "acts", ids=[10]), Constraint("break_times", "", slots=[(0, 3), (1, 3)]),
    Constraint("acts_pref_times", "acts", f_subject="الرياضة", f_duration=2, slots=[(2, 0)]),
    Constraint("acts_pref_slots", "acts", f_teacher=p.teachers[1], slots=[(3, 1)]),
    Constraint("home_students", "students", p.years[0].groups[0].name, rooms=["مخبر1", "مخبر2"]),
    Constraint("home_teacher", "teacher", p.teachers[0], rooms=["مخبر1"]),
    Constraint("subject_rooms", "subject", "العربية", rooms=["مخبر1"]),
]
p.save("/tmp/c2.fet"); q = Project.load("/tmp/c2.fet")
def key(c): return (c.kind, c.who, c.target, c.value, tuple(c.ids), tuple(sorted(c.slots)), tuple(c.rooms), c.weight, c.f_teacher, c.f_students, c.f_subject, c.f_duration)
check("fet round trip (new kinds)", sorted(map(key, p.constraints)) == sorted(map(key, q.constraints)) and not q.extra_time and not q.extra_space,
      f"{len(q.constraints)}/{len(p.constraints)} extra={len(q.extra_time)+len(q.extra_space)}")
txt = open("/tmp/c2.fet", encoding="utf-8").read()
check("real-day tags in morning/afternoon mode", "ConstraintTeachersMaxHoursDailyRealDays" in txt and "ConstraintStudentsSetMaxRealDaysPerWeek" in txt)

# كل وسوم الكتالوج موجودة فعلاً في FET
import tt_constraints as tcm
tags = tcm.KNOWN_FET_TAGS
if tags:
    bad = []
    for kind, v in tcm.ENTITY.items():
        for who in ("teacher", "students"):
            if who == "teacher" and "T" not in v[2] or who == "students" and "S" not in v[2]: continue
            for real in (False, True):
                for target in ("x", ""):
                    t = tcm._scope_tag(kind, who, target, real)[0]
                    if t not in tags: bad.append(t)
    for k, v in tcm.ACTIVITY.items():
        if "Constraint" + v[1] not in tags: bad.append(v[1])
    for k, v in tcm.FILTERED.items():
        if "Constraint" + v[1] not in tags: bad.append(v[1])
    for k, v in tcm.SPACE.items():
        for t in v[1:]:
            if t and "Constraint" + t not in tags: bad.append(t)
    if "ConstraintBreakTimes" not in tags: bad.append("BreakTimes")
    check("all written tags are real FET tags", not bad, str(sorted(set(bad))[:6]))
print("ALL OK" if ok else "SOME FAILED")
