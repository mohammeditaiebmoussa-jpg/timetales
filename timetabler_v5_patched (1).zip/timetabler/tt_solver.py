"""مولّد الجدول الزمني — لغة Python خالصة، بلا مكتبات خارجية.

الطريقة (مشابهة في الفكرة لمولّد FET لكن بحث محلي بدل التوليد التكراري):
  1) بناء نطاق الأوقات الممكنة لكل حصة (مراعاة عدم التوفّر وحدود نصف اليوم).
  2) وضع أولي جشع: الحصص الأصعب أولاً في أقل الأوقات تكلفة.
  3) إزالة التعارضات بـ min-conflicts مع قائمة محظورة (tabu) وهزّات عند الركود.
  4) تحسين الجودة: تقليل الفراغات، توزيع حصص المادة على أيام مختلفة، تبديلات.
  5) توزيع القاعات المتعددة الخيارات بعد تثبيت الأوقات.

القيود الصلبة: تعارض الأستاذ/القسم(الفوج)/القاعة المحددة، عدم التوفّر، أقصى ساعات يومية،
أقصى أيام أسبوعية للأستاذ، الحصص المثبّتة. القيود الناعمة: الفراغات، تباعد حصص المادة.
"""
from __future__ import annotations

import random
import re
import time
from dataclasses import dataclass, field

import tt_constraints as tcm

W_OVER = 1000      # تداخل مورد واحد
W_LIM = 300        # تجاوز حدّ يومي/أسبوعي
# قيود «أحادية الاتجاه»: إضافة حصة لا تُصلحها أبداً (بخلاف الفراغات والحدود الدنيا التي قد تُصلحها حصة لاحقة)
CORE_ADV = {"max_hours_cont", "max_hours_daily", "max_days_week", "max_afternoons", "max_mornings", "max_span_day"}


def unit(w: int) -> int:
    """عقوبة المخالفة الواحدة: 100% إجباري، وما دونه ناعم متناسب."""
    return W_LIM if w >= 100 else max(1, int(w * 0.3))


KINDS = {0: "teacher", 1: "students", 2: "room"}


def room_context(project):
    hs, ht, sr = {}, {}, {}
    for c in project.constraints:
        if not c.active or c.weight <= 0 or not c.rooms:
            continue
        if c.kind == "home_students":
            hs[c.target] = list(c.rooms)
        elif c.kind == "home_teacher":
            ht[c.target] = list(c.rooms)
        elif c.kind == "subject_rooms":
            sr[c.target] = list(c.rooms)
    return hs, ht, sr


def effective_rooms(project, a, ctx) -> list:
    """قاعات الحصة: المحددة فيها، وإلا القاعة الثابتة للقسم/الأستاذ، وإلا قاعات المادة."""
    if a.room:
        return [a.room]
    if a.rooms:
        return list(a.rooms)
    ar = project.acts_rooms_for(a)
    if ar:
        return ar
    hs, ht, sr = ctx
    for s in a.students:
        for nm in [s] + project.parents(s):
            if nm in hs:
                return hs[nm]
    for t in a.teachers:
        if t in ht:
            return ht[t]
    return sr.get(a.subject, [])


@dataclass
class Result:
    placements: dict = field(default_factory=dict)   # id -> (day, period)
    room_assign: dict = field(default_factory=dict)  # id -> room
    hard_left: int = 0
    soft_cost: int = 0
    problems: list = field(default_factory=list)     # نصوص بالمشاكل المتبقية
    unplaceable: list = field(default_factory=list)  # حصص نطاقها فارغ
    seconds: float = 0.0
    iterations: int = 0


# ------------------------------------------------------------------ تشخيص مسبق
def diagnose(project) -> list:
    """ملاحظات فورية عن استحالة واضحة (مثل ما يفعله FET قبل التوليد)."""
    msgs = []
    P, D = project.n_periods, project.n_days
    total = D * P
    t_load, l_load = {}, {}
    par_seen = set()
    for a in project.acts.values():
        if not a.active:
            continue
        for t in a.teachers:
            t_load[t] = t_load.get(t, 0) + a.duration
        seen = set()
        for s in a.students:
            for lf in project.leaves(s):
                if lf not in seen:
                    seen.add(lf)
                    if a.parallel:
                        # الحصص المتزامنة تشغل القسم مرة واحدة فقط
                        pk = (a.parallel, lf)
                        if pk in par_seen:
                            continue
                        par_seen.add(pk)
                    l_load[lf] = l_load.get(lf, 0) + a.duration
        if not a.teachers:
            msgs.append(f"الحصة {a.id} ({a.subject}) بلا أستاذ")
        if not a.students:
            msgs.append(f"الحصة {a.id} ({a.subject}) بلا قسم")
        if a.duration > (project.half_len if project.halves > 1 else P):
            msgs.append(f"الحصة {a.id}: المدة {a.duration} أكبر من نصف اليوم")
    # سعة القاعات (شرط هول على المجمّعات الفعلية: القاعة المحددة، القاعات الثابتة للقسم/الأستاذ، قاعات المادة)
    ctx = room_context(project)
    keys = {}
    for a in project.acts.values():
        if not a.active:
            continue
        r = effective_rooms(project, a, ctx)
        if r:
            k = tuple(sorted(set(r)))
            keys[k] = keys.get(k, 0) + max(1, a.duration)
    for U in Solver._hall_closure(list(keys)):
        su = set(U)
        h = sum(v for k, v in keys.items() if set(k) <= su)
        cap = sum(total - len(project.unavail.get(("room", n), ())) for n in U)
        if h > cap:
            msgs.append(f"القاعات {' / '.join(U)}: المطلوب {h} ساعة لكن السعة {cap} فقط — "
                        f"تعارضات القاعات حتمية (وزّع الحصص على قاعات أخرى أو خفّض الحصص)")
    for t, h in sorted(t_load.items()):
        free = total - len(project.unavail.get(("teacher", t), ()))
        lim = project.teacher_max_daily.get(t) or project.default_teacher_max_daily
        md = project.teacher_max_days.get(t)
        if lim:
            free = min(free, lim * (md or D))
        elif md:
            free = min(free, md * P)
        if h > free:
            msgs.append(f"الأستاذ «{t}»: {h} ساعة مطلوبة لكن المتاح {free} فقط")
    for lf, h in sorted(l_load.items()):
        free = total
        for (k, n), slots in project.unavail.items():
            if k == "students" and lf in project.leaves(n):
                free = min(free, total - len(slots))
        lim = project.students_max_daily.get(lf) or project.default_students_max_daily
        if lim:
            free = min(free, lim * D)
        if h > free:
            msgs.append(f"القسم «{lf}»: {h} ساعة مطلوبة لكن المتاح {free} فقط")
    return msgs


# ------------------------------------------------------------------ المولّد
class Solver:
    def __init__(self, project, seed=None, log=None, stop=None, keep_existing=False, seed_low=False,
                 t_factor=None):
        self.pr = project
        self.rng = random.Random(seed)
        self.log = log or (lambda m: None)
        self.stop = stop or (lambda: False)
        self.keep_existing = keep_existing
        # البدء من جدول جاهز (مثلاً ناتج FET) بتلدين منخفض الحرارة يحافظ على بنيته ويحسّن الناعم فقط
        self.seed_low = bool(seed_low and keep_existing)
        self.t_factor = t_factor
        self.polish = False    # جُرّب صقل منخفض الحرارة في آخر الوقت فلم يُحسّن النتيجة (مُعطّل افتراضياً)
        self.polish_T = 1.5
        self.g0_seed = 0.12     # وزن القيود الصلبة عند البدء من بذرة (يرتفع تدريجياً إلى 1)
        self.patience = 20.0
        self._build()

    # ------------------------------------------------------------ بناء المسألة
    def _build(self) -> None:
        pr = self.pr
        self.P, self.D = pr.n_periods, pr.n_days
        self.halves = pr.halves if pr.halves > 1 else 1
        self.H = pr.half_len if self.halves > 1 else self.P
        self.S = self.P * self.D

        acts = [a for a in pr.acts.values() if a.active and a.teachers is not None]
        acts.sort(key=lambda a: a.id)
        tnames = list(dict.fromkeys(pr.teachers + [t for a in acts for t in a.teachers]))
        lnames = []
        for a in acts:
            for s in a.students:
                for lf in pr.leaves(s):
                    lnames.append(lf)
        lnames = list(dict.fromkeys(lnames))
        self.room_ctx = room_context(pr)

        def room_key(a):
            r = effective_rooms(pr, a, self.room_ctx)
            return tuple(sorted(dict.fromkeys(r))) if r else None
        base_pools = list(dict.fromkeys(k for k in (room_key(a) for a in acts) if k))
        pools = self._hall_closure(base_pools)
        self.T, self.L = len(tnames), len(lnames)
        self.TL = self.T + self.L
        tix = {n: i for i, n in enumerate(tnames)}
        lix = {n: self.T + i for i, n in enumerate(lnames)}
        rix = {k: self.TL + i for i, k in enumerate(pools)}
        self.rnames = tnames + lnames + ["قاعة: " + "/".join(k) for k in pools]
        self.cap = [1] * self.TL + [len(k) for k in pools]
        self.R = len(pools)
        nres = self.TL + len(pools)

        # توفّر
        avail = [[True] * self.S for _ in range(nres)]

        def block(r, slots):
            for d, p in slots:
                if 0 <= d < self.D and 0 <= p < self.P:
                    avail[r][d * self.P + p] = False
        for (k, name), slots in pr.unavail.items():
            if k == "teacher" and name in tix:
                block(tix[name], slots)
            elif k == "room":
                for key, ri in rix.items():
                    if name in key and len(key) == 1:
                        block(ri, slots)
            elif k == "students":
                for lf in pr.leaves(name):
                    if lf in lix:
                        block(lix[lf], slots)

        for key, ri in rix.items():
            if len(key) > 1:
                sets = [pr.unavail.get(("room", n), set()) for n in key]
                common = set.intersection(*[set(x) for x in sets]) if sets else set()
                block(ri, common)

        # حدود
        self.maxdaily = [0] * self.TL
        self.maxdays = [0] * self.TL
        self.wgap = [0] * self.TL
        for n, i in tix.items():
            self.maxdaily[i] = pr.teacher_max_daily.get(n) or pr.default_teacher_max_daily
            self.maxdays[i] = pr.teacher_max_days.get(n, 0)
            self.wgap[i] = pr.w_gaps_teacher
        for n, i in lix.items():
            self.maxdaily[i] = pr.default_students_max_daily
            self.wgap[i] = pr.w_gaps_students
        for name, v in pr.students_max_daily.items():
            for lf in pr.leaves(name):
                if lf in lix:
                    cur = self.maxdaily[lix[lf]]
                    self.maxdaily[lix[lf]] = min(cur, v) if cur else v

        # قواعد متقدمة للأساتذة/الأفواج
        self.adv = {}
        for c in pr.constraints:
            if not c.active or c.weight <= 0 or c.kind not in tcm.ENTITY:
                continue
            if c.who == "teacher":
                rs = [tix[c.target]] if c.target in tix else ([] if c.target else list(tix.values()))
            else:
                rs = [lix[lf] for lf in pr.leaves(c.target) if lf in lix] if c.target else list(lix.values())
            for r in rs:
                self.adv.setdefault(r, []).append((c.kind, c.value, c.weight))
        pref_hard, cover_hard, pref_soft, brk, brk_soft = {}, {}, [], set(), []
        for c in pr.constraints:
            if not c.active or c.weight <= 0:
                continue
            if c.kind == "break_times":
                sl = {d * self.P + p for d, p in c.slots}
                if c.weight >= 100:
                    brk |= sl
                else:
                    brk_soft.append((sl, c.weight))
                continue
            if c.kind in ("pref_times", "pref_slots") and len(c.ids) == 1:
                ids = [c.ids[0]]
            elif c.kind in ("acts_pref_times", "acts_pref_slots"):
                ids = [a.id for a in acts if pr.act_matches(a, c)]
            else:
                continue
            allowed = {d * self.P + p for d, p in c.slots}
            cover = c.kind in ("pref_slots", "acts_pref_slots")
            for aid in ids:
                if c.weight >= 100:
                    dct = cover_hard if cover else pref_hard
                    dct[aid] = (dct[aid] & allowed) if aid in dct else set(allowed)
                else:
                    pref_soft.append((aid, allowed, c.weight, "prefslots" if cover else "pref"))

        # ضغط الاستراحات: خانة الاستراحة الإجبارية لا تُحسب فراغاً (كما في FET)، فتُحذف من الأقنعة
        self.skipb = list(range(self.S + 2))
        for x in range(self.S, -1, -1):
            if x in brk:
                self.skipb[x] = self.skipb[x + 1]
        self.cpos = []
        for d in range(self.D):
            row = []
            for p in range(self.P):
                st = (p // self.H) * self.H if self.halves > 1 else 0
                row.append((p - st) - sum(1 for q in range(st, p) if d * self.P + q in brk))
            self.cpos.append(row)
        # الحصص — الحصص المتزامنة (نفس الرقم والمدة) تُدمج في وحدة واحدة تُوضع في وقت واحد
        # وتُحسب مواردها (أساتذة/أقسام/قاعات) مرة واحدة للقسم، فيُسمح بأكثر من أستاذ للقسم نفسه.
        self.aid, self.dur, self.res, self.tl, self.dom = [], [], [], [], []
        self.group, self.movable, self.fixed_pos = [], [], []
        self.members = []
        gid_index = {}
        self.unplaceable = []
        items, bykey = [], {}
        for a in acts:
            if a.parallel:
                k = (a.parallel, max(1, a.duration))
                if k in bykey:
                    bykey[k].append(a)
                    continue
                bykey[k] = [a]
                items.append(bykey[k])
            else:
                items.append([a])
        for ms in items:
            a = ms[0]
            tl = []
            for m in ms:
                tl += [tix[t] for t in m.teachers]
                for s in m.students:
                    tl += [lix[lf] for lf in pr.leaves(s)]
            tl = list(dict.fromkeys(tl))
            res = list(tl)
            for m in ms:
                rk = room_key(m)
                if rk:
                    # شرط هول: تُحتسب الحصة في كل مجمّع (اتحاد مجمّعات متقاطعة) يحتوي قاعاتها كلها
                    srk = set(rk)
                    res += [ri for key, ri in rix.items() if srk <= set(key)]
            dur = max(1, a.duration)
            lk = next((m for m in ms if m.id in pr.locked and m.id in pr.placements), None)
            if lk is not None:
                d, p = pr.placements[lk.id]
                dom = [d * self.P + p]
                mov = False
            else:
                dom = []
                for d in range(self.D):
                    for p in range(self.P):
                        if p + dur > self.P:
                            continue
                        if self.halves > 1 and p // self.H != (p + dur - 1) // self.H:
                            continue
                        s0 = d * self.P + p
                        if all(avail[r][s0 + k] for r in res for k in range(dur)):
                            dom.append(s0)
                mov = True
                for m in ms:
                    if m.id in pref_hard:
                        dom = [x for x in dom if x in pref_hard[m.id]]
                    if m.id in cover_hard:
                        cs_ = cover_hard[m.id]
                        dom = [x for x in dom if all((x + k) in cs_ for k in range(dur))]
                if brk:
                    dom = [x for x in dom if not any((x + k) in brk for k in range(dur))]
            if not dom:
                self.unplaceable.extend(m.id for m in ms)
            g = -1
            if a.group_id:
                g = gid_index.setdefault(a.group_id, len(gid_index))
            self.aid.append(a.id)
            self.members.append([m.id for m in ms])
            self.dur.append(dur)
            self.res.append(res)
            self.tl.append(tl)
            self.dom.append(dom)
            self.group.append(g)
            self.movable.append(mov and bool(dom))
            self.fixed_pos.append(dom[0] if not mov and dom else -1)
        self.N = len(self.aid)
        if self.halves == 2 and self.pattern_reduce:
            self._reduce_afternoons(tix)
        self.ngroups = len(gid_index)
        idx = {m: i for i, ms in enumerate(self.members) for m in ms}
        self.prules, self.rules_of = [], [[] for _ in range(self.N)]
        two = {"consecutive", "ordered", "ordered_same_day", "grouped"}
        daykinds = ("ends_students_day", "begins_students_day", "ends_teachers_day", "begins_teachers_day")
        for c in pr.constraints:
            if not c.active or c.weight <= 0 or c.kind not in tcm.ACTIVITY or c.kind in ("pref_times", "pref_slots"):
                continue
            if c.kind in daykinds:
                if len(c.ids) != 1 or c.ids[0] not in idx:
                    continue
                t = idx[c.ids[0]]
                stu = "students" in c.kind
                mine = {r for r in self.tl[t] if (self.T <= r < self.TL) == stu}
                others = [b for b in range(self.N) if b != t and mine & set(self.tl[b])]
                if others:
                    self._add_prule((c.kind, (t,) + tuple(others), None, False, c.weight))
                continue
            mem = tuple(dict.fromkeys(idx[i] for i in c.ids if i in idx))
            if (c.kind in two and len(mem) != 2) or (c.kind == "grouped3" and len(mem) != 3) or len(mem) < 2:
                continue
            self._add_prule((c.kind, mem, c.value, c.flag, c.weight))
        for aid, allowed, w, mode in pref_soft:
            if aid in idx:
                self._add_prule((mode, (idx[aid],), allowed, False, w))
        for sl, w in brk_soft:
            for i in range(self.N):
                self._add_prule(("avoid", (i,), sl, False, w))

        # جداول لكل قناع (قطعة يوم): فراغات، عدد، امتداد، أطول تتابع، أول خانة
        size = 1 << min(self.H, 16)
        self.gtab, self.t_pop, self.t_span, self.t_run, self.t_low = [0] * size, [0] * size, [0] * size, [0] * size, [0] * size
        for m in range(1, size):
            low = (m & -m).bit_length() - 1
            high = m.bit_length() - 1
            pop = bin(m).count("1")
            self.gtab[m] = (high - low + 1) - pop
            self.t_pop[m], self.t_span[m], self.t_low[m] = pop, high - low + 1, low
            run = best = 0
            for k in range(high + 1):
                run = run + 1 if (m >> k) & 1 else 0
                best = max(best, run)
            self.t_run[m] = best

        # جيران كل حصة: حصص تشاركها قسماً/فوجاً أو أستاذاً، بنفس المدة وقابلة للتحريك (لحركات التبديل)
        by_res = {}
        for a in range(self.N):
            for r in self.tl[a]:
                by_res.setdefault(r, []).append(a)
        self.nb_same = []
        for a in range(self.N):
            seen = set()
            for r in self.tl[a]:
                for b in by_res[r]:
                    if b != a and self.movable[b] and self.dur[b] == self.dur[a]:
                        seen.add(b)
            self.nb_same.append(sorted(seen))
        self.by_dur = {}
        for a in range(self.N):
            if self.movable[a]:
                self.by_dur.setdefault(self.dur[a], []).append(a)
        self.domset = [set(d) for d in self.dom]
        self.res_set = [frozenset(r) for r in self.res]
        by_all = {}
        for a in range(self.N):
            for r in self.res[a]:
                by_all.setdefault(r, []).append(a)
        self.nb_all = []
        for a in range(self.N):
            seen = set()
            for r in self.res[a]:
                seen.update(by_all[r])
            seen.discard(a)
            self.nb_all.append(sorted(seen))
        self._compile_adv()

    @staticmethod
    def _hall_closure(base, limit=80):
        """مجمّعات القاعات + اتحادات كل مجمّعين متقاطعين (شرط هول للتوزيع).
        بدونها يُحسَب {A,B} و{B,C} موردين مستقلين فيمرّ جدول يستحيل توزيع قاعاته."""
        fam = [frozenset(k) for k in base]
        seen = set(fam)
        changed = True
        while changed and len(seen) < limit:
            changed = False
            cur = list(seen)
            for i in range(len(cur)):
                for j in range(i + 1, len(cur)):
                    a, b = cur[i], cur[j]
                    if a & b and not (a <= b or b <= a):
                        u = a | b
                        if u not in seen:
                            seen.add(u)
                            changed = True
                            if len(seen) >= limit:
                                break
                if len(seen) >= limit:
                    break
        keys = [tuple(sorted(f)) for f in seen]
        order = {k: i for i, k in enumerate(base)}
        keys.sort(key=lambda k: (order.get(k, len(base)), len(k), k))
        return keys

    pattern_reduce = False   # تجربة غير محسومة: تقليص مساءات الأساتذة مسبقاً

    def _reduce_afternoons(self, tix) -> None:
        """تقليص النطاقات: لكل أستاذ حدّه الإجباري «أقصى مساءات = k» نختار مسبقاً k مساءات (الأوفر خانات)
        ونحذف بقية المساءات من نطاق حصصه، فلا يمكن خرق القيد أثناء البحث."""
        H = self.H
        by_t = {}
        for a in range(self.N):
            for r in self.tl[a]:
                if r < self.T:
                    by_t.setdefault(r, []).append(a)
        for r, rules in self.adv.items():
            if r >= self.T:
                continue
            ks = [v for kind, v, w in rules if kind == "max_afternoons" and w >= 100]
            if not ks:
                continue
            k = min(ks)
            acts_r = [a for a in by_t.get(r, []) if self.movable[a]]
            cover = {}
            for a in acts_r:
                for x in self.dom[a]:
                    sg = x // H
                    if sg % 2 == 1:
                        cover[sg] = cover.get(sg, 0) + 1
            if len(cover) <= k:
                continue
            ranked = sorted(cover, key=lambda g: (-cover[g], self.rng.random()))
            keep = set(ranked[:k])
            for a in acts_r:
                nd = [x for x in self.dom[a] if (x // H) % 2 == 0 or (x // H) in keep]
                if nd:
                    self.dom[a] = nd

    def _add_prule(self, rule) -> None:
        self.prules.append(rule)
        for m in rule[1]:
            self.rules_of[m].append(rule)

    # ------------------------------------------------------------ الحالة
    def _reset_state(self) -> None:
        self.occ = [[0] * self.S for _ in range(self.TL + self.R)]
        self.dayh = [[0] * self.D for _ in range(self.TL)]
        self.mask = [[0] * (self.D * self.halves) for _ in range(self.TL)]
        self.used = [0] * self.TL
        self.grpday = [[0] * self.D for _ in range(self.ngroups)]
        self.pos = [-1] * self.N
        self.advc, self.advh, self.advk, self.advs = {}, {}, {}, {}
        for r in self.adv:
            self._refresh_adv(r)

    def _add(self, a: int, s: int) -> None:
        P, H, halves = self.P, self.H, self.halves
        dur = self.dur[a]
        d, p = divmod(s, P)
        seg = d * halves + (p // H if halves > 1 else 0)
        bits = ((1 << dur) - 1) << self.cpos[d][p]
        for r in self.res[a]:
            o = self.occ[r]
            for x in range(s, s + dur):
                o[x] += 1
        for r in self.tl[a]:
            if self.dayh[r][d] == 0:
                self.used[r] += 1
            self.dayh[r][d] += dur
            self.mask[r][seg] |= bits
        if self.adv:
            for r in self.tl[a]:
                if r in self.adv:
                    self._refresh_adv(r)
        g = self.group[a]
        if g >= 0:
            self.grpday[g][d] += 1
        self.pos[a] = s

    def _remove(self, a: int) -> None:
        s = self.pos[a]
        P, H, halves = self.P, self.H, self.halves
        dur = self.dur[a]
        d, p = divmod(s, P)
        seg = d * halves + (p // H if halves > 1 else 0)
        for r in self.res[a]:
            o = self.occ[r]
            for x in range(s, s + dur):
                o[x] -= 1
        for r in self.tl[a]:
            self.dayh[r][d] -= dur
            if self.dayh[r][d] == 0:
                self.used[r] -= 1
            # أعد بناء قناع القطعة من الإشغال
            o = self.occ[r]
            m = 0
            base = d * P + (p // H) * H if halves > 1 else d * P
            cp = self.cpos[d]
            off = base - d * P
            for k in range(H if halves > 1 else P):
                if o[base + k] > 0:
                    m |= 1 << cp[off + k]
            self.mask[r][seg] = m
        if self.adv:
            for r in self.tl[a]:
                if r in self.adv:
                    self._refresh_adv(r)
        g = self.group[a]
        if g >= 0:
            self.grpday[g][d] -= 1
        self.pos[a] = -1

    def _ovl(self, a: int, s: int) -> bool:
        """هل يسبّب وضع a (المُزالة مؤقتاً) في s تداخلاً في أي مورد؟"""
        dur = self.dur[a]
        cap = self.cap
        for r in self.res[a]:
            o = self.occ[r]
            cp = cap[r]
            for x in range(s, s + dur):
                if o[x] >= cp:
                    return True
        return False

    def _cost(self, a: int, s: int, soft: bool = True) -> int:
        """تكلفة وضع الحصة a (المُزالة مؤقتاً) في الخانة s."""
        P, H, halves = self.P, self.H, self.halves
        dur = self.dur[a]
        d, p = divmod(s, P)
        c = 0
        cap = self.cap
        for r in self.res[a]:
            o = self.occ[r]
            cp = cap[r]
            for x in range(s, s + dur):
                if o[x] >= cp:
                    c += 1
        c *= W_OVER
        seg = d * halves + (p // H if halves > 1 else 0)
        bits = ((1 << dur) - 1) << self.cpos[d][p]
        for r in self.tl[a]:
            h = self.dayh[r][d]
            lim = self.maxdaily[r]
            if lim:
                c += W_LIM * (max(0, h + dur - lim) - max(0, h - lim))
            md = self.maxdays[r]
            if md and h == 0 and self.used[r] >= md:
                c += W_LIM
            if soft:
                m = self.mask[r][seg]
                c += self.wgap[r] * (self.gtab[m | bits] - self.gtab[m])
        if soft:
            g = self.group[a]
            if g >= 0:
                c += self.pr.w_min_days * self.grpday[g][d]
        if self.adv:
            for r in self.tl[a]:
                if r in self.adv:
                    m = list(self.mask[r])
                    m[seg] |= bits
                    c += self._adv_cost(r, m)[0] - self.advc[r]
        if self.rules_of[a]:
            c += self._prule_cost(a, s)
        return c

    def _is_bad(self, a: int) -> bool:
        s = self.pos[a]
        dur = self.dur[a]
        d = s // self.P
        for r in self.res[a]:
            o = self.occ[r]
            cp = self.cap[r]
            for x in range(s, s + dur):
                if o[x] > cp:
                    return True
        for r in self.tl[a]:
            lim = self.maxdaily[r]
            if lim and self.dayh[r][d] > lim:
                return True
            md = self.maxdays[r]
            if md and self.used[r] > md:
                return True
            if r in self.advk and self.advk[r] > 0:
                return True
        for rule in self.rules_of[a]:
            if rule[4] >= 100 and self._prule_viol(rule, a, s) > 0:
                return True
        return False

    # ------------------------------------------------------------ قواعد متقدمة
    SEG_KINDS = ("max_gaps_day", "max_hours_cont", "min_hours_daily", "max_span_day")

    def _compile_adv(self) -> None:
        """يجهّز لكل كيان جدول تكلفة لكل قناع نصف-يوم (قواعد على مستوى القطعة) + قواعد أسبوعية مجمّعة،
        فيصبح تقييم الكيان مروراً واحداً على الأقنعة بدل مرور لكل قاعدة."""
        size = len(self.gtab)
        pop, span, run, gt = self.t_pop, self.t_span, self.t_run, self.gtab
        self.seg_c, self.seg_h, self.seg_k, self.wk, self.seg_ch, self.seg_ck = {}, {}, {}, {}, {}, {}
        self.wm = [1.0] * max(1, self.TL)
        self.need_daily, self._memo = {}, {}
        for r, rules in self.adv.items():
            tc, th, tk = [0] * size, [0] * size, [0] * size
            tch = [0] * size
            tck = [0] * size
            wk = []
            for kind, val, w in rules:
                if kind in self.SEG_KINDS:
                    for m in range(size):
                        if kind == "max_gaps_day":
                            v = max(0, gt[m] - val)
                        elif kind == "max_hours_cont":
                            v = max(0, run[m] - val)
                        elif kind == "min_hours_daily":
                            v = max(0, val - pop[m]) if m else 0
                        else:
                            v = max(0, span[m] - val)
                        if v:
                            if w >= 100:
                                if kind in CORE_ADV:
                                    tck[m] += unit(w) * v
                                    tk[m] += v
                                else:
                                    tch[m] += unit(w) * v
                                th[m] += v
                            else:
                                tc[m] += unit(w) * v
                else:
                    wk.append((kind, val, w, unit(w), w >= 100 and kind in CORE_ADV))
            self.seg_c[r], self.seg_h[r], self.seg_k[r], self.wk[r] = tc, th, tk, wk
            self.seg_ch[r] = tch
            self.seg_ck[r] = tck
            self.need_daily[r] = any(k == "max_hours_daily" for k, *_ in wk)

    def _adv_cost(self, r: int, masks, detail: bool = False):
        if detail or r not in self.seg_c:
            return self._adv_cost_slow(r, masks, detail)
        p = self._adv_parts(r, masks)
        return p[0] + p[1] * self.wm[r] + p[2], p[3], p[4]

    def _adv_parts(self, r: int, masks):
        """(تكلفة ناعمة، تكلفة إجبارية غير موزونة، عدد مخالفات إجبارية، عدد المخالفات الأساسية) مع تخزين مؤقت."""
        key = (r, tuple(masks))
        memo = self._memo
        hit = memo.get(key)
        if hit is not None:
            return hit
        tc, th, tk, tch, tck = self.seg_c[r], self.seg_h[r], self.seg_k[r], self.seg_ch[r], self.seg_ck[r]
        halves, D = self.halves, self.D
        low = self.t_low
        cost = hard = core = costh = costk = 0
        gaps = used = morn = aft = early = 0
        gt, pop = self.gtab, self.t_pop
        wk = self.wk[r]
        need_daily = self.need_daily[r]
        daily = []
        i = 0
        for d in range(D):
            anyd = False
            dh = 0
            for k in range(halves):
                m = masks[i]
                i += 1
                if m:
                    anyd = True
                    cost += tc[m]
                    costh += tch[m]
                    costk += tck[m]
                    hard += th[m]
                    core += tk[m]
                    gaps += gt[m]
                    dh += pop[m]
                    if low[m] == 1:
                        early += 1
                    if halves > 1:
                        if k == 0:
                            morn += 1
                        else:
                            aft += 1
            if anyd:
                used += 1
            if need_daily:
                daily.append(dh)
        for kind, val, w, u, iscore in wk:
            if kind == "max_gaps_week":
                v = gaps - val
            elif kind == "max_hours_daily":
                v = sum(max(0, h - val) for h in daily)
            elif kind == "min_mornings":
                v = (val - morn) if halves > 1 else 0
            elif kind == "min_afternoons":
                v = (val - aft) if halves > 1 else 0
            elif kind == "min_days_week":
                v = val - used
            elif kind == "max_days_week":
                v = used - val
            elif kind == "max_mornings":
                v = (morn - val) if halves > 1 else 0
            elif kind == "max_afternoons":
                v = (aft - val) if halves > 1 else 0
            elif kind == "early_second":
                v = early - val
            else:
                v = 0
            if v > 0:
                if w >= 100:
                    if iscore:
                        costk += u * v
                        core += v
                    else:
                        costh += u * v
                    hard += v
                else:
                    cost += u * v
        out = (cost, costh, costk, hard, core)
        if len(memo) > 600000:
            memo.clear()
        memo[key] = out
        return out

    def _adv_cost_slow(self, r: int, masks, detail: bool = False):
        """(التكلفة، عدد المخالفات الإجبارية) لقواعد الكيان r على أقنعة الأسبوع."""
        halves = self.halves
        cost = hard = core = 0
        det = []
        pop, span, run, low, gt = self.t_pop, self.t_span, self.t_run, self.t_low, self.gtab
        used = sum(1 for d in range(self.D) if any(masks[d * halves + k] for k in range(halves)))
        for kind, val, w in self.adv[r]:
            v = 0
            if kind == "max_gaps_week":
                v = max(0, sum(gt[m] for m in masks) - val)
            elif kind == "max_gaps_day":
                v = sum(max(0, gt[m] - val) for m in masks)
            elif kind == "max_hours_cont":
                v = sum(max(0, run[m] - val) for m in masks)
            elif kind == "max_hours_daily":
                v = sum(max(0, sum(pop[masks[d * halves + k]] for k in range(halves)) - val) for d in range(self.D))
            elif kind == "min_mornings" and halves > 1:
                v = max(0, val - sum(1 for d in range(self.D) if masks[d * halves]))
            elif kind == "min_afternoons" and halves > 1:
                v = max(0, val - sum(1 for d in range(self.D) if masks[d * halves + 1]))
            elif kind == "min_hours_daily":
                v = sum(max(0, val - pop[m]) for m in masks if m)
            elif kind == "max_span_day":
                v = sum(max(0, span[m] - val) for m in masks)
            elif kind == "min_days_week":
                v = max(0, val - used)
            elif kind == "max_days_week":
                v = max(0, used - val)
            elif kind == "max_mornings" and halves > 1:
                v = max(0, sum(1 for d in range(self.D) if masks[d * halves]) - val)
            elif kind == "max_afternoons" and halves > 1:
                v = max(0, sum(1 for d in range(self.D) if masks[d * halves + 1]) - val)
            elif kind == "early_second":
                v = max(0, sum(1 for m in masks if m and low[m] == 1) - val)
            if v:
                cost += unit(w) * v
                if w >= 100:
                    hard += v
                    if kind in CORE_ADV:
                        core += v
                if detail:
                    det.append((kind, v, w))
        return (cost, hard, core, det) if detail else (cost, hard, core)

    def _refresh_adv(self, r: int) -> None:
        if r in self.seg_c:
            p = self._adv_parts(r, self.mask[r])
            self.advs[r] = p[0]
            self.advc[r], self.advh[r], self.advk[r] = p[0] + p[1] * self.wm[r] + p[2], p[3], p[4]
        else:
            self.advc[r], self.advh[r], self.advk[r] = self._adv_cost(r, self.mask[r])
            self.advs[r] = self.advc[r] - self.advh[r] * W_LIM

    def _pv(self, kind, par, flag, sa, da, sb, db) -> int:
        """مخالفة زوج (a ثم b) لقاعدة؛ sa/sb خانات خطية، da/db مدد."""
        P = self.P
        if kind == "same_time":
            return int(sa != sb)
        if kind == "same_day":
            return int(sa // P != sb // P)
        if kind == "not_overlap":
            return int(sa < sb + db and sb < sa + da)
        if kind == "min_days":
            gap = abs(sa // P - sb // P)
            if gap >= par:
                return 0
            if gap == 0 and flag and (self.skipb[sa + da] == sb or self.skipb[sb + db] == sa):
                return 0
            return 1
        if kind == "same_hour":
            return int(sa % P != sb % P)
        if kind == "max_days":
            return int(abs(sa // P - sb // P) > par)
        if kind == "min_gaps":
            if sa // P != sb // P:
                return 0
            gap = (sb - (sa + da)) if sa <= sb else (sa - (sb + db))
            return int(gap < par)
        same = sa // P == sb // P
        if kind == "ordered_same_day":
            return int(same and sb < sa + da)
        if kind == "consecutive":
            return int(not (same and sb == self.skipb[sa + da]))
        if kind == "ordered":
            return int(not (same and sb >= sa + da))
        if kind == "grouped":
            return int(not (same and (sb == self.skipb[sa + da] or sa == self.skipb[sb + db])))
        return 0

    _DAYKINDS = ("ends_students_day", "begins_students_day", "ends_teachers_day", "begins_teachers_day")

    def _ev_day(self, kind, sa, da, sb, db) -> int:
        """مخالفة «آخر/أول حصة في اليوم»: b في نفس يوم a ويأتي بعدها (ends) أو قبلها (begins)."""
        # FET في نمط صباح/مساء يطبّق «أول/آخر حصة في اليوم» على نصف اليوم (يوم FET الخام) لا اليوم الحقيقي
        seg = self.H if self.halves > 1 else self.P
        if sa // seg != sb // seg:
            return 0
        return int(sb > sa) if kind.startswith("ends") else int(sb < sa)

    def _viol3(self, items) -> int:
        """ثلاث حصص متجاورة بأي ترتيب في يوم واحد."""
        if any(p < 0 for p, _d in items):
            return 0
        items = sorted(items)
        P = self.P
        if len({p // P for p, _d in items}) != 1:
            return 1
        ok = all(self.skipb[items[i][0] + items[i][1]] == items[i + 1][0] for i in range(2))
        return int(not ok)

    def _prule_viol(self, rule, a: int, s: int) -> int:
        """مخالفات القاعدة التي تشمل a لو وُضعت a في الخانة s (الباقي من الحالة)."""
        kind, mem, par, flag, w = rule
        if kind == "pref":
            return int(s not in par)
        if kind in ("prefslots", "avoid"):
            cov = sum(1 for k in range(self.dur[a]) if (s + k) in par)
            return (self.dur[a] - cov) if kind == "prefslots" else cov
        v = 0
        da = self.dur[a]
        if kind in self._DAYKINDS:
            t = mem[0]
            if a == t:
                return sum(self._ev_day(kind, s, da, self.pos[y], self.dur[y]) for y in mem[1:] if self.pos[y] >= 0)
            return self._ev_day(kind, self.pos[t], self.dur[t], s, da) if self.pos[t] >= 0 else 0
        if kind == "grouped3":
            return self._viol3([(s if b == a else self.pos[b], self.dur[b]) for b in mem])
        if kind in ("consecutive", "ordered", "ordered_same_day", "grouped"):
            x, y = mem
            if a == x:
                sb = self.pos[y]
                return self._pv(kind, par, flag, s, da, sb, self.dur[y]) if sb >= 0 else 0
            sa = self.pos[x]
            return self._pv(kind, par, flag, sa, self.dur[x], s, da) if sa >= 0 else 0
        for b in mem:
            if b != a and self.pos[b] >= 0:
                v += self._pv(kind, par, flag, s, da, self.pos[b], self.dur[b])
        return v

    def _prule_cost(self, a: int, s: int) -> int:
        c = 0
        for rule in self.rules_of[a]:
            v = self._prule_viol(rule, a, s)
            if v:
                c += unit(rule[4]) * v
        return c

    def _prule_totals(self, detail: bool = False):
        hard, soft, msgs = 0, 0, []
        for rule in self.prules:
            kind, mem, par, flag, w = rule
            v = 0
            if kind == "pref":
                a = mem[0]
                v = int(self.pos[a] >= 0 and self.pos[a] not in par)
            elif kind in ("prefslots", "avoid"):
                a = mem[0]
                if self.pos[a] >= 0:
                    v = self._prule_viol(rule, a, self.pos[a])
            elif kind in self._DAYKINDS:
                t = mem[0]
                if self.pos[t] >= 0:
                    v = sum(self._ev_day(kind, self.pos[t], self.dur[t], self.pos[y], self.dur[y])
                            for y in mem[1:] if self.pos[y] >= 0)
            elif kind == "grouped3":
                v = self._viol3([(self.pos[b], self.dur[b]) for b in mem])
            elif kind in ("consecutive", "ordered", "ordered_same_day", "grouped"):
                x, y = mem
                if self.pos[x] >= 0 and self.pos[y] >= 0:
                    v = self._pv(kind, par, flag, self.pos[x], self.dur[x], self.pos[y], self.dur[y])
            else:
                for i in range(len(mem)):
                    for j in range(i + 1, len(mem)):
                        a, b = mem[i], mem[j]
                        if self.pos[a] >= 0 and self.pos[b] >= 0:
                            v += self._pv(kind, par, flag, self.pos[a], self.dur[a], self.pos[b], self.dur[b])
            if v:
                if w >= 100:
                    hard += v
                else:
                    soft += unit(w) * v
                if detail:
                    ids = [self.aid[m] for m in (mem[:1] if kind in self._DAYKINDS or kind in ("pref", "prefslots", "avoid") else mem)]
                    title = {"pref": "أوقات مفضّلة", "prefslots": "خانات مفضّلة", "avoid": "فترة استراحة"}.get(
                        kind) or tcm.kind_title(kind)
                    msgs.append(f"{'إجباري' if w >= 100 else 'ناعم'}: {title} — الحصص {ids}")
        return (hard, soft, msgs) if detail else (hard, soft)

    # ------------------------------------------------------------ قياس
    def hard_cost(self) -> int:
        tot = 0
        for r in range(self.TL + self.R):
            cp = self.cap[r]
            for v in self.occ[r]:
                if v > cp:
                    tot += v - cp
        for r in range(self.TL):
            lim = self.maxdaily[r]
            if lim:
                tot += sum(max(0, h - lim) for h in self.dayh[r])
            md = self.maxdays[r]
            if md and self.used[r] > md:
                tot += self.used[r] - md
        tot += sum(self.advh.values()) + self._prule_totals()[0]
        return tot

    def soft_cost(self) -> int:
        tot = 0
        for r in range(self.TL):
            w = self.wgap[r]
            for m in self.mask[r]:
                tot += w * self.gtab[m]
        for g in range(self.ngroups):
            for v in self.grpday[g]:
                if v > 1:
                    tot += self.pr.w_min_days * (v * (v - 1) // 2)
        tot += sum(self.advs.values()) + self._prule_totals()[1]
        return tot

    # ------------------------------------------------------------ الخوارزمية
    # ------------------------------------------------------------ بناء جزئي مع الإخراج (IFS)
    def _core_violation(self, a: int):
        """أول مخالفة أحادية الاتجاه تخص الحصة a الموضوعة، أو None."""
        s = self.pos[a]
        d = s // self.P
        for r in self.res[a]:
            o = self.occ[r]
            cp = self.cap[r]
            for x in range(s, s + self.dur[a]):
                if o[x] > cp:
                    return ("ovl", r)
        for r in self.tl[a]:
            lim = self.maxdaily[r]
            if lim and self.dayh[r][d] > lim:
                return ("daily", r)
            md = self.maxdays[r]
            if md and self.used[r] > md:
                return ("days", r)
            if self.advk.get(r, 0) > 0:
                return ("adv", r)
        for rule in self.rules_of[a]:
            if rule[4] >= 100 and self._prule_viol(rule, a, s) > 0:
                return ("rule", rule)
        return None

    def _victims(self, a: int, v) -> list:
        kind, x = v
        pos, rng, H = self.pos, self.rng, self.H
        d = pos[a] // self.P
        mv = self.movable
        if kind == "ovl":
            s, dur = pos[a], self.dur[a]
            c = [b for b in self.nb_all[a] if pos[b] >= 0 and mv[b] and self.res_set[b] & self.res_set[a]
                 and pos[b] < s + dur and s < pos[b] + self.dur[b]]
            return [rng.choice(c)] if c else [a]
        if kind == "rule":
            c = [self.members_idx for self.members_idx in x[1] if self.members_idx != a and pos[self.members_idx] >= 0 and mv[self.members_idx]]
            return [rng.choice(c)] if c else [a]
        mine = [b for b in self.nb_all[a] if x in self.tl[b] and pos[b] >= 0]
        if kind == "adv":
            det = [k for k, _v, w in self._adv_cost(x, self.mask[x], True)[3] if w >= 100 and k in CORE_ADV]
            k0 = det[0] if det else ""
            if k0 in ("max_afternoons", "max_mornings") and self.halves > 1:
                par = 1 if k0 == "max_afternoons" else 0
                segs = {}
                for b in mine:
                    sg = pos[b] // H
                    if sg % 2 == par and sg != pos[a] // H:
                        segs.setdefault(sg, []).append(b)
                if segs:
                    sg = min(segs, key=lambda k: (sum(self.dur[b] for b in segs[k]), rng.random()))
                    return segs[sg] if all(mv[b] for b in segs[sg]) else [a]
                return [a]
            if k0 == "max_days_week":
                kind = "days"
            else:
                c = [b for b in mine if pos[b] // self.P == d and mv[b]]
                return [rng.choice(c)] if c else [a]
        if kind == "daily":
            c = [b for b in mine if pos[b] // self.P == d and mv[b]]
            return [rng.choice(c)] if c else [a]
        days = {}
        for b in mine:
            if pos[b] // self.P != d:
                days.setdefault(pos[b] // self.P, []).append(b)
        if not days:
            return [a]
        dd = min(days, key=lambda k: (sum(self.dur[b] for b in days[k]), rng.random()))
        return days[dd] if all(mv[b] for b in days[dd]) else [a]

    def _eject_place(self, a: int, s: int):
        """يضع a في s ويُخرج ما يلزم لتبقى القيود الأحادية صحيحة. يعيد [(حصة، موضعها القديم)] أو None."""
        bl = self._blockers(a, s)
        if any(not self.movable[b] for b in bl):
            return None
        ej = []
        for b in bl:
            ej.append((b, self.pos[b]))
            self._remove(b)
        self._add(a, s)
        for _ in range(40):
            v = self._core_violation(a)
            if v is None:
                return ej
            for b in self._victims(a, v):
                if b == a:
                    self._remove(a)
                    ej.append((a, s))
                    return ej
                ej.append((b, self.pos[b]))
                self._remove(b)
        self._remove(a)
        ej.append((a, s))
        return ej

    def _repair_core(self, movable, deadline) -> None:
        """يُخرج الحصص المخالِفة للقيود الأحادية ويعيد إدخالها بالإخراج؛ يُقبل الناتج فقط إن لم يسُؤ."""
        for _ in range(8):
            now = time.time()
            bad = [a for a in movable if self._is_bad(a)]
            if not bad or now >= deadline or self.stop():
                return
            key0 = (self.hard_cost(), self.soft_cost())
            snap = list(self.pos)
            old = {a: self.pos[a] for a in bad}
            for a in bad:
                self._remove(a)
            left = self._ifs(movable, now + max(1.0, (deadline - now) / 3), start_U=bad, old=old)
            for a in left:
                best, bs = None, []
                for s_ in self.dom[a]:
                    c = self._cost(a, s_)
                    if best is None or c < best:
                        best, bs = c, [s_]
                    elif c == best:
                        bs.append(s_)
                if bs:
                    self._add(a, self.rng.choice(bs))
            key1 = (self.hard_cost(), self.soft_cost())
            self.log(f"  إصلاح بالإخراج: صلب {key0[0]}→{key1[0]} · ناعم {key0[1]}→{key1[1]}")
            if key1 > key0:
                self._reset_state()
                for a, s_ in enumerate(snap):
                    if s_ >= 0:
                        self._add(a, s_)

    # --- سجلّ عمليات يتيح التراجع (للبناء التكراري)
    def _tadd(self, a: int, s: int) -> None:
        self._add(a, s)
        self._trail.append((1, a, s))

    def _trem(self, a: int) -> None:
        s = self.pos[a]
        self._remove(a)
        self._trail.append((0, a, s))

    def _undo(self, mark: int) -> None:
        tr = self._trail
        while len(tr) > mark:
            op, a, s = tr.pop()
            if op == 1:
                self._remove(a)
            else:
                self._add(a, s)

    def _eject_place_t(self, a: int, s: int):
        """مثل _eject_place لكن بسجلّ تراجع؛ يعيد None إن لم يمكن (حصة مثبّتة/مرساة أو فشل)."""
        bl = self._blockers(a, s)
        if any(not self.movable[b] for b in bl):
            return None
        ej = []
        for b in bl:
            ej.append((b, self.pos[b]))
            self._trem(b)
        self._tadd(a, s)
        for _ in range(40):
            v = self._core_violation(a)
            if v is None:
                return ej
            for b in self._victims(a, v):
                if b == a:
                    return None
                ej.append((b, self.pos[b]))
                self._trem(b)
        return None

    RS_LIMIT = 6      # أقصى عمق للتكرار
    RS_BUDGET = 40    # أقصى عدد استدعاءات تكرارية لكل حصة

    def _rplace(self, a: int, level: int) -> bool:
        """يضع a (غير موضوعة) مع إعادة وضع الحصص المعطِّلة تكرارياً. عند الفشل تُلغى كل التغييرات."""
        if level >= self.RS_LIMIT or self._rs_budget <= 0:
            return False
        self._rs_budget -= 1
        rng = self.rng
        cand = self.dom[a]
        if len(cand) > 40:
            cand = rng.sample(cand, 40)
        avoid = self._avoid.get(a)
        scored = []
        for s in cand:
            if s == avoid:
                continue
            mark = len(self._trail)
            ej = self._eject_place_t(a, s)
            n = len(ej) if ej is not None else None
            self._undo(mark)
            if n is None:
                continue
            scored.append((n, self._cost(a, s), rng.random(), s))
        scored.sort()
        k = 4 if level == 0 else (3 if level == 1 else 2)
        self.movable[a] = False          # مرساة: لا يجوز إخراجها أثناء السلسلة
        try:
            for n, _c, _r, s in scored[:k]:
                mark = len(self._trail)
                ej = self._eject_place_t(a, s)
                if ej is None:
                    self._undo(mark)
                    continue
                ok = True
                for b, o in ej:
                    self._avoid[b] = o     # لا تعد الحصة المُخرَجة إلى مكانها القديم
                    ok = self._rplace(b, level + 1)
                    self._avoid.pop(b, None)
                    if not ok:
                        break
                if ok:
                    return True
                self._undo(mark)
            return False
        finally:
            self.movable[a] = True

    def _rplace_top(self, a: int) -> bool:
        self._trail, self._rs_budget, self._avoid = [], self.RS_BUDGET, {}
        ok = self._rplace(a, 0)
        if not ok:
            self._undo(0)
        self._trail = None
        return ok

    def _ifs(self, movable, deadline, start_U=None, old=None, recursive=True):
        rng = self.rng
        if start_U is None:
            self._reset_state()
            for a in range(self.N):
                if not self.movable[a] and self.dom[a]:
                    self._add(a, self.dom[a][0])
            U = sorted(movable, key=lambda a: (len(self.dom[a]), -self.dur[a]))
            tabu = {}
        else:
            U = list(start_U)
            tabu = {(a, p): 40 for a, p in (old or {}).items()}
        arrival = {a: i for i, a in enumerate(U)}
        tick = len(U)
        fails = {}
        it, last = 0, time.time()
        best_u, best_pos, best_list = len(U), list(self.pos), list(U)
        while U and time.time() < deadline and not self.stop():
            a = max(U, key=lambda x: (fails.get(x, 0), -arrival[x]))   # ترتيب ديناميكي: الأصعب (الأكثر فشلاً) أولاً
            U.remove(a)
            it += 1
            if recursive and self._rplace_top(a):
                if len(U) < best_u:
                    best_u, best_pos, best_list = len(U), list(self.pos), list(U)
                continue
            fails[a] = fails.get(a, 0) + 1
            cand = self.dom[a]
            if len(cand) > 40:
                cand = rng.sample(cand, 40)
            best, bs = None, []
            for s in cand:
                c = self._cost(a, s)
                if tabu.get((a, s), 0) > it:
                    c += 5000
                if best is None or c < best:
                    best, bs = c, [s]
                elif c == best:
                    bs.append(s)
            s = rng.choice(bs)
            ej = self._eject_place(a, s)
            if ej is None:
                tabu[(a, s)] = it + 60
                U.append(a)
                arrival[a] = tick
                tick += 1
                continue
            for b, o in ej:
                tabu[(b, o)] = it + 8 + rng.randint(0, 8)
                U.append(b)
                arrival[b] = tick
                tick += 1
            if len(U) < best_u:
                best_u, best_pos, best_list = len(U), list(self.pos), list(U)
            if time.time() - last > 3:
                last = time.time()
                self.log(f"  بناء جزئي… غير موضوعة: {len(U)} (أدنى: {best_u})")
        if U and best_u < len(U):
            self._restore(best_pos)
            U = best_list
        return list(U)

    def _greedy(self) -> None:
        self._reset_state()
        order = list(range(self.N))
        load = {}
        for a in range(self.N):
            for r in self.tl[a]:
                load[r] = load.get(r, 0) + self.dur[a]
        order.sort(key=lambda a: (len(self.dom[a]) if self.movable[a] else -1,
                                  -self.dur[a], -max([load.get(r, 0) for r in self.tl[a]] or [0])))
        for a in order:
            if not self.dom[a]:
                continue
            if not self.movable[a]:
                self._add(a, self.dom[a][0])
        for a in order:
            if not self.movable[a]:
                continue
            init = None
            if self.keep_existing and self.aid[a] in self.pr.placements:
                d, p = self.pr.placements[self.aid[a]]
                if d * self.P + p in self.dom[a]:
                    init = d * self.P + p
            if init is None:
                best, bs = None, []
                for s in self.dom[a]:
                    c = self._cost(a, s)
                    if best is None or c < best:
                        best, bs = c, [s]
                    elif c == best:
                        bs.append(s)
                init = self.rng.choice(bs)
            self._add(a, init)

    def _move_best(self, a: int, it: int, tabu: dict, noise: float, tenure: int) -> None:
        old = self.pos[a]
        self._remove(a)
        dom = self.dom[a]
        if self.rng.random() < noise:
            new = self.rng.choice(dom)
        else:
            best, bs = None, []
            for s in dom:
                c = self._cost(a, s)
                if tabu.get((a, s), 0) > it and s != old:
                    c += 400
                if best is None or c < best:
                    best, bs = c, [s]
                elif c == best:
                    bs.append(s)
            new = self.rng.choice(bs)
        self._add(a, new)
        if new != old:
            tabu[(a, old)] = it + tenure + self.rng.randint(0, 6)

    def solve(self, seconds: float = 60.0, soft_seconds: float = None, progress=None) -> Result:
        t0 = time.time()
        res = Result()
        res.unplaceable = list(self.unplaceable)
        movable = [a for a in range(self.N) if self.movable[a]]
        if not movable:
            self._greedy()
            return self._finish(res, t0, 0)
        if soft_seconds is None:
            soft_seconds = max(2.0, seconds * 0.8)
        hard_deadline = t0 + max(1.0, seconds - soft_seconds)
        self.log(f"عدد الحصص: {self.N} ({len(movable)} قابلة للتحريك) — أساتذة {self.T}، أفواج {self.L}، قاعات {self.R}")
        if self.keep_existing:
            self._greedy()
            if self.seed_low:
                self.log(f"بذرة جاهزة: صلب {self.hard_cost()} · ناعم {self.soft_cost()}")
        else:
            left = self._ifs(movable, t0 + seconds * 0.2)
            self.log(f"انتهى البناء الجزئي: غير موضوعة {len(left)}")
            for a in left:
                best, bs = None, []
                for s_ in self.dom[a]:
                    c = self._cost(a, s_)
                    if best is None or c < best:
                        best, bs = c, [s_]
                    elif c == best:
                        bs.append(s_)
                if bs:
                    self._add(a, self.rng.choice(bs))
        it, tabu = 0, {}
        best_bad, best_pos, since_best = None, None, 0
        bad = []
        last_report = t0
        while True:
            if it % 20 == 0:
                bad = [a for a in movable if self._is_bad(a)]
                nb = len(bad)
                if best_bad is None or nb < best_bad:
                    best_bad, best_pos, since_best = nb, list(self.pos), 0
                else:
                    since_best += 20
                if nb == 0:
                    break
                now = time.time()
                if now > hard_deadline or self.stop():
                    break
                if now - last_report > 2:
                    last_report = now
                    self.log(f"  إزالة التعارضات… حصص متعارضة: {nb} (أفضل: {best_bad})")
                    if progress:
                        progress(min(0.7, (now - t0) / max(1.0, seconds)), f"تعارضات: {nb}")
                if since_best > 2500:
                    # هزّة: حرّك عدداً من الحصص عشوائياً ثم تابع
                    for a in self.rng.sample(movable, min(len(movable), max(3, len(movable) // 25))):
                        self._remove(a)
                        self._add(a, self.rng.choice(self.dom[a]))
                    since_best = 0
                    tabu.clear()
            if not bad:
                it += 1
                continue
            a = self.rng.choice(bad)
            if self._is_bad(a):
                self._move_best(a, it, tabu, 0.03, 8)
            it += 1
        if best_pos is not None and self.hard_cost() > 0:
            # استعد أفضل حالة صلبة
            self._reset_state()
            for a, s in enumerate(best_pos):
                if s >= 0:
                    self._add(a, s)
        hc = self.hard_cost()
        self.log(f"انتهت مرحلة التعارضات: تعارضات صلبة متبقية = {hc} (تكرارات {it})")
        # مرحلة التلدين: تُصلح ما تبقّى من قيود الفراغات/الحدود الدنيا وتحسّن الجودة معاً
        end = t0 + seconds
        if not self.stop() and time.time() < end - 1:
            remaining = end - time.time()
            reserve = max(5.0, remaining * (0.15 if not self.polish else 0.30))
            if self.seed_low:
                m = self._calibrate_T(movable)
                f = self.t_factor if self.t_factor else 3.0
                ts = max(0.3, m * f)
                self.log(f"معايرة: متوسط الزيادة {m:.2f} → حرارة البدء {ts:.2f}")
                self._anneal(movable, end - reserve, progress, t0, seconds, t_start=ts, t_end=max(0.1, ts / 12),
                             g0=self.g0_seed, ramp=0.6)
            else:
                self._anneal(movable, end - reserve, progress, t0, seconds)
            self._repair_core(movable, end - reserve * 0.3)
            # ما زالت هناك مخالفات؟ لا تُهدر الوقت المتبقي: تلدين إضافي بحرارة منخفضة من أفضل جدول
            if not self.stop() and self.hard_cost() > 0 and end - time.time() > 3:
                self._anneal(movable, end - 1.5, progress, t0, seconds, t_start=2.0, g0=0.6, ramp=0.3)
            if not self.stop() and self.hard_cost() == 0:
                if self.polish and end - time.time() > 4:
                    # صقل: تلدين منخفض الحرارة بكل الأوزان من أفضل جدول (يتحمّل فقط تدهوراً ناعماً صغيراً)
                    self._anneal(movable, time.time() + (end - time.time()) * 0.75, progress, t0, seconds,
                                 t_start=self.polish_T, t_end=0.15, g0=1.0, ramp=0.01)
                self._improve(movable, end, progress, t0, seconds)
        if self.hard_cost() == 0 and not self.stop():
            self._repair_rooms()
        res.iterations = it
        return self._finish(res, t0, it)

    def _is_viol(self, a: int) -> bool:
        """هل الحصة طرف في أي مخالفة إجبارية (بما فيها الفراغات والحدود الدنيا)؟"""
        s = self.pos[a]
        dur = self.dur[a]
        d = s // self.P
        for r in self.res[a]:
            o = self.occ[r]
            cp = self.cap[r]
            for x in range(s, s + dur):
                if o[x] > cp:
                    return True
        for r in self.tl[a]:
            lim = self.maxdaily[r]
            if lim and self.dayh[r][d] > lim:
                return True
            md = self.maxdays[r]
            if md and self.used[r] > md:
                return True
            if self.advh.get(r, 0) > 0:
                return True
        for rule in self.rules_of[a]:
            if rule[4] >= 100 and self._prule_viol(rule, a, s) > 0:
                return True
        return False

    def _blockers(self, a: int, s: int) -> list:
        """الحصص الموضوعة التي تمنع وضع a في الخانة s (تشغل مورداً ممتلئاً)."""
        dur = self.dur[a]
        out = []
        pos, dr, rs = self.pos, self.dur, self.res_set
        for r in self.res[a]:
            o = self.occ[r]
            cp = self.cap[r]
            for x in range(s, s + dur):
                if o[x] >= cp:
                    c = [b for b in self.nb_all[a] if r in rs[b] and pos[b] >= 0 and pos[b] <= x < pos[b] + dr[b]]
                    if cp > 1 and c:
                        c = [self.rng.choice(c)]
                    for b in c:
                        if b not in out:
                            out.append(b)
        return out

    def _chain(self, a: int, s2: int, T: float):
        """سلسلة إزاحة: ضع a في s2 وأخلِ الحصص المعطِّلة إلى أفضل خانات خالية لها.
        تُقبل السلسلة كلها أو تُلغى كلها بمعيار ميتروبوليس؛ تعيد فرق الكلفة عند القبول وإلا None."""
        import math
        pos, rng = self.pos, self.rng
        sa = pos[a]
        journal, placed = [], []
        self._remove(a)
        dE = -self._cost(a, sa)
        journal.append((a, sa))
        ok = True
        bl = self._blockers(a, s2)
        for b in bl:
            if not self.movable[b] or b in (a,):
                ok = False
                break
        if ok:
            for b in bl:
                sb = pos[b]
                self._remove(b)
                dE -= self._cost(b, sb)
                journal.append((b, sb))
            if self._ovl(a, s2):
                ok = False
            else:
                dE += self._cost(a, s2)
                self._add(a, s2)
                placed.append(a)
        if ok:
            for b in bl:
                best, bs = None, []
                for s in self.dom[b]:
                    if self._ovl(b, s):
                        continue
                    c = self._cost(b, s)
                    if best is None or c < best:
                        best, bs = c, [s]
                    elif c == best:
                        bs.append(s)
                if best is None:
                    ok = False
                    break
                self._add(b, rng.choice(bs))
                dE += best
                placed.append(b)
        if ok and (dE <= 0 or rng.random() < math.exp(-dE / T)):
            return dE
        for x in reversed(placed):
            self._remove(x)
        for x, sx in reversed(journal):
            self._add(x, sx)
        return None

    def _viol_resources(self) -> list:
        """الموارد (أساتذة/أفواج) التي ما زالت تخالف قيداً إجبارياً على مستوى الأسبوع/اليوم."""
        out = []
        for r in range(self.TL):
            if self.advh.get(r, 0) > 0:
                out.append(r)
                continue
            lim = self.maxdaily[r]
            if lim and any(h > lim for h in self.dayh[r]):
                out.append(r)
                continue
            md = self.maxdays[r]
            if md and self.used[r] > md:
                out.append(r)
        return out

    def _set_weights(self, wm_new: dict) -> None:
        for r, w in wm_new.items():
            self.wm[r] = w
            if r in self.adv:
                self._refresh_adv(r)

    def _apply_ramp(self, g: float, boost: list) -> None:
        """وزن كل مورد = g × boost[r]؛ يُحدَّث فقط ما تغيّر فعلاً بأكثر من 2%."""
        upd = {}
        for r in range(self.TL):
            w = g * boost[r]
            if abs(w - self.wm[r]) > 0.02 * max(self.wm[r], 1e-9):
                upd[r] = w
        if upd:
            self._set_weights(upd)

    def _calibrate_T(self, movable, n=600) -> float:
        """متوسط الزيادة الناعمة الموجبة لحركة نقل عشوائية (دون الحدود الصلبة): مقياس طبيعي لسلّم الحرارة."""
        rng, pos = self.rng, self.pos
        tot = cnt = 0
        for _ in range(n):
            a = rng.choice(movable)
            sa = pos[a]
            s2 = rng.choice(self.dom[a])
            if s2 == sa:
                continue
            self._remove(a)
            if not self._ovl(a, s2):
                d = self._cost(a, s2) - self._cost(a, sa)
                if 0 < d < W_LIM:
                    tot += d
                    cnt += 1
            self._add(a, sa)
        return (tot / cnt) if cnt else 4.0

    def _anneal(self, movable, deadline, progress, t0, seconds, t_start=12.0, t_end=0.6, g0=0.12, ramp=0.65) -> None:
        """تلدين محاكى + أوزان ديناميكية (breakout).
        حركات: نقل، تبديل حصتين متساويتين المدة (غالباً من نفس القسم/الأستاذ)، وسلسلة إزاحة تُخلي الحصص المعطِّلة.
        تُقبل الحركة الأسوأ باحتمال exp(-Δ/T). والقيود الإجبارية التي تبقى مخالَفة يرتفع وزنها تدريجياً
        فيتوقّف الخرق عن «التنقّل» بين الأساتذة. يُحفظ أفضل جدول (أقل مخالفات صلبة ثم أقل تكلفة ناعمة)."""
        import math
        rng, rnd = self.rng, self.rng.random
        start = time.time()
        span = max(0.5, deadline - start)
        n = acc = 0
        viol = []
        last = start
        T = t_start
        ratio = t_end / t_start
        nbs, domset = self.nb_same, self.domset
        pos, dur = self.pos, self.dur
        best_key = (self.hard_cost(), self.soft_cost())
        best_pos = list(pos)
        stale = 0
        boost = [1.0] * max(1, self.TL)
        g = g0
        self._apply_ramp(g, boost)
        self.log(f"تلدين محاكى… الحرارة {t_start} → {t_end} · البداية: صلب {best_key[0]} · ناعم {best_key[1]}")
        while True:
            if n % 64 == 0:
                now = time.time()
                if now >= deadline or self.stop():
                    break
                frac = (now - start) / span
                T = t_start * (ratio ** frac)
                g = g0 + (1.0 - g0) * min(1.0, frac / ramp)
            if n % 2500 == 0 and n:
                key = (self.hard_cost(), self.soft_cost())
                # لا تُقارَن اللقطات إلا عندما تكون الأوزان قريبة من 1 (وإلا فالمقارنة الحقيقية تبقى بالمفتاح الفعلي)
                if key < best_key:
                    best_key, best_pos, stale = key, list(pos), 0
                else:
                    stale += 1
                # أوزان ديناميكية: ارفع وزن الموارد المخالِفة الراكدة، وخفّف ما عداها
                if key[0] > 0 and stale >= 2 and g >= 0.5:
                    bad_r = set(self._viol_resources())
                    for r in range(self.TL):
                        if r in bad_r:
                            boost[r] = min(10.0, boost[r] * 1.25)
                        elif boost[r] > 1.0:
                            boost[r] = max(1.0, boost[r] * 0.97)
                elif key[0] == 0:
                    boost = [1.0] * max(1, self.TL)
                self._apply_ramp(g, boost)
                viol = [x for x in movable if self._is_viol(x)]
                now = time.time()
                if now - last > 3:
                    last = now
                    self.log(f"  T={T:.2f} · قُبلت {acc}/{n} · صلب {key[0]} · ناعم {key[1]} · (الأفضل: {best_key[0]}/{best_key[1]})")
                    if progress:
                        progress(min(0.99, 0.5 + 0.5 * (now - start) / span), f"تلدين: صلب {key[0]}")
            n += 1
            if viol and rnd() < 0.3:
                a = rng.choice(viol)
                chain_p = 0.5
            else:
                a = rng.choice(movable)
                chain_p = 0.03
            sa = pos[a]
            if rnd() < chain_p:
                s2 = rng.choice(self.dom[a])
                if s2 != sa and self._chain(a, s2, T) is not None:
                    acc += 1
            elif rnd() < 0.35:
                s2 = rng.choice(self.dom[a])
                if s2 == sa:
                    continue
                self._remove(a)
                if self._ovl(a, s2):
                    self._add(a, sa)
                    continue
                delta = self._cost(a, s2) - self._cost(a, sa)
                if delta <= 0 or rnd() < math.exp(-delta / T):
                    self._add(a, s2)
                    acc += 1
                else:
                    self._add(a, sa)
            else:
                nb = nbs[a] if rnd() < 0.8 and nbs[a] else self.by_dur[dur[a]]
                b = rng.choice(nb)
                if b == a:
                    continue
                sb = pos[b]
                if sb == sa or sb not in domset[a] or sa not in domset[b]:
                    continue
                self._remove(a)
                self._remove(b)
                if self._ovl(a, sb):
                    self._add(a, sa)
                    self._add(b, sb)
                    continue
                new = self._cost(a, sb)
                self._add(a, sb)
                if self._ovl(b, sa):
                    self._remove(a)
                    self._add(a, sa)
                    self._add(b, sb)
                    continue
                new += self._cost(b, sa)
                self._remove(a)
                old = self._cost(a, sa)
                self._add(a, sa)
                old += self._cost(b, sb)
                delta = new - old
                if delta <= 0 or rnd() < math.exp(-delta / T):
                    self._remove(a)
                    self._add(a, sb)
                    self._add(b, sa)
                    acc += 1
                else:
                    self._add(b, sb)
        # أعد الأوزان إلى 1 ثم قارن الحالة الحالية بأفضل لقطة بالحساب الفعلي
        self._set_weights({r: 1.0 for r in range(self.TL) if self.wm[r] != 1.0})
        cur_key = (self.hard_cost(), self.soft_cost())
        if best_key < cur_key:
            self._reset_state()
            for a, s_ in enumerate(best_pos):
                if s_ >= 0:
                    self._add(a, s_)
        self.log(f"انتهى التلدين: صلب {self.hard_cost()} · ناعم {self.soft_cost()} (حركات {n})")

    def _restore(self, plist) -> None:
        self._reset_state()
        for a, s_ in enumerate(plist):
            if s_ >= 0:
                self._add(a, s_)

    def solve_unlimited(self, cycle: float = 90.0, progress=None) -> Result:
        """بلا حدّ زمني: دورات متتالية تُحسّن أفضل جدول (إعادة تسخين منه)، وإعادة بدء كاملة عند الركود.
        يتوقف عند stop() ويعيد أفضل جدول (أقل مخالفات صلبة ثم أقل تكلفة ناعمة)."""
        t0 = time.time()
        res = self.solve(seconds=cycle, progress=progress)
        movable = [a for a in range(self.N) if self.movable[a]]
        best_key = (self.hard_cost(), self.soft_cost())
        best_pos = list(self.pos)
        k, stale, stale_h = 1, 0, 0
        self.log(f"[دورة 1] صلب {best_key[0]} · ناعم {best_key[1]}")
        while not self.stop() and movable and not (best_key[0] == 0 and best_key[1] == 0):
            k += 1
            end = time.time() + cycle
            if stale >= 3 or (best_key[0] > 0 and stale_h >= 2):
                self.log("  ركود — إعادة بدء كاملة")
                self.solve(seconds=cycle, progress=progress)
                stale = stale_h = 0
            else:
                self._restore(best_pos)
                self._anneal(movable, end - 5, progress, t0, cycle, t_start=3.0, g0=0.5, ramp=0.3)
                if not self.stop() and self.hard_cost() == 0:
                    self._improve(movable, end, progress, t0, cycle)
            key = (self.hard_cost(), self.soft_cost())
            stale_h = 0 if key[0] < best_key[0] else stale_h + 1
            if key < best_key:
                best_key, best_pos, stale = key, list(self.pos), 0
            else:
                stale += 1
            self.log(f"[دورة {k}] الحالي {key[0]}/{key[1]} · الأفضل {best_key[0]}/{best_key[1]}")
        self._restore(best_pos)
        if self.hard_cost() == 0:
            self._repair_rooms()
        return self._finish(res, t0, 0)

    def _improve(self, movable, deadline, progress, t0, seconds) -> None:
        rng = self.rng
        cur = self.soft_cost()
        self.log(f"تحسين الجودة… التكلفة الناعمة الحالية: {cur}")
        n, last = 0, time.time()
        best_seen, last_gain = cur, time.time()
        while time.time() < deadline and not self.stop() and cur > 0:
            if time.time() - last_gain > self.patience:
                self.log("لا تحسّن إضافي — توقّف مبكر")
                break
            a = rng.choice(movable)
            old = self.pos[a]
            self._remove(a)
            base = self._cost(a, old)
            best, bs = base, [old]
            for s in self.dom[a]:
                if s == old:
                    continue
                c = self._cost(a, s)
                if c < best:
                    best, bs = c, [s]
                elif c == best:
                    bs.append(s)
            self._add(a, rng.choice(bs))
            n += 1
            if n % 40 == 0 and movable:
                self._try_swap(movable)
            if time.time() - last > 2:
                last = time.time()
                cur = self.soft_cost()
                if cur < best_seen:
                    best_seen, last_gain = cur, time.time()
                if progress:
                    progress(min(0.99, 0.7 + 0.3 * (last - t0) / max(1.0, seconds)), f"جودة: {cur}")
        self.log(f"التكلفة الناعمة النهائية: {self.soft_cost()}")

    def _placements_now(self) -> dict:
        out = {}
        for a in range(self.N):
            if self.pos[a] >= 0:
                for mid in self.members[a]:
                    out[mid] = divmod(self.pos[a], self.P)
        return out

    def _repair_rooms(self, rounds: int = 40) -> None:
        """يعالج حصصاً لا تجد قاعة (غالباً متعددة الساعات): ينقلها إلى أوقات تتسع فيها قاعة."""
        pr, P = self.pr, self.P
        idx = {m: i for i, ms in enumerate(self.members) for m in ms}
        for _ in range(rounds):
            if self.stop():
                return
            pl = self._placements_now()
            assign, miss = assign_rooms(pr, pl)
            if not miss:
                return
            ids = [int(x) for m in miss for x in re.findall(r"حصة (\d+)", m)]
            occ = {}
            for aid, room in assign.items():
                d, p = pl[aid]
                for k in range(pr.acts[aid].duration):
                    occ[(room, d * P + p + k)] = aid
            moved = False
            for aid in ids:
                i = idx.get(aid)
                if i is None or len(self.members[i]) != 1 or not self.movable[i]:
                    continue
                rooms = effective_rooms(pr, pr.acts[aid], self.room_ctx)
                dur = self.dur[i]
                oldpos = self.pos[i]
                self._remove(i)
                best, bs = None, []
                for s in self.dom[i]:
                    if not any(all(occ.get((rm, s + k), aid) == aid for k in range(dur)) for rm in rooms):
                        continue
                    c = self._cost(i, s)
                    if c >= W_LIM:          # لا نقبل تعارضاً صلباً جديداً
                        continue
                    if best is None or c < best:
                        best, bs = c, [s]
                    elif c == best:
                        bs.append(s)
                if bs:
                    self._add(i, self.rng.choice(bs))
                    moved = True
                else:
                    self._add(i, oldpos)
            if not moved:
                return

    def _try_swap(self, movable) -> None:
        rng = self.rng
        a, b = rng.sample(movable, 2) if len(movable) > 1 else (movable[0], movable[0])
        if a == b or self.dur[a] != self.dur[b]:
            return
        sa, sb = self.pos[a], self.pos[b]
        if sb not in self.dom[a] or sa not in self.dom[b] or sa == sb:
            return
        # التكلفة قبل
        self._remove(a)
        self._remove(b)
        before = self._cost(a, sa)
        self._add(a, sa)
        before += self._cost(b, sb)
        self._remove(a)
        after = self._cost(a, sb)
        self._add(a, sb)
        after += self._cost(b, sa)
        if after < before:
            self._add(b, sa)
        else:
            self._remove(a)
            self._add(a, sa)
            self._add(b, sb)

    # ------------------------------------------------------------ نتيجة
    def _finish(self, res: Result, t0: float, it: int) -> Result:
        pr = self.pr
        for a in range(self.N):
            s = self.pos[a]
            if s >= 0:
                for mid in self.members[a]:
                    res.placements[mid] = divmod(s, self.P)
        res.hard_left = self.hard_cost()
        res.soft_cost = self.soft_cost()
        res.problems = self._problems()
        res.room_assign, miss = assign_rooms(pr, res.placements)
        res.problems += miss
        res.seconds = time.time() - t0
        res.iterations = it
        return res

    def _problems(self) -> list:
        out = []
        P = self.P
        for r in range(self.TL + self.R):
            kind = "أستاذ" if r < self.T else ("قسم/فوج" if r < self.TL else "قاعة")
            for s, v in enumerate(self.occ[r]):
                if v > self.cap[r]:
                    d, p = divmod(s, P)
                    out.append(f"تعارض {kind} «{self.rnames[r]}»: "
                               f"{self.pr.days[d]} — {self.pr.periods[p]}")
        for r in range(self.TL):
            lim = self.maxdaily[r]
            if lim:
                for d, h in enumerate(self.dayh[r]):
                    if h > lim:
                        out.append(f"«{self.rnames[r]}»: {h} ساعات يوم {self.pr.days[d]} (الحد {lim})")
            md = self.maxdays[r]
            if md and self.used[r] > md:
                out.append(f"«{self.rnames[r]}»: يعمل {self.used[r]} أيام (الحد {md})")
        for r in self.advc:
            if self.advh[r] > 0:
                for kind, v, w in self._adv_cost(r, self.mask[r], True)[3]:
                    if w >= 100:
                        out.append(f"«{self.rnames[r]}»: مخالفة قيد «{tcm.kind_title(kind)}» ({v})")
        out += [m for m in self._prule_totals(True)[2] if m.startswith("إجباري")]
        for aid in self.unplaceable:
            a = self.pr.acts[aid]
            out.append(f"الحصة {aid} ({a.subject} — {'، '.join(a.teachers)} — {'، '.join(a.students)}): "
                       f"لا يوجد أي وقت متاح لها")
        return out[:200]


# ------------------------------------------------------------------ القاعات
def assign_rooms(project, placements: dict):
    """يوزّع القاعات لحصص لها خيارات متعددة. يعيد (assign, رسائل)."""
    P = project.n_periods
    occupant = {}      # (room, slot) -> act id
    assign = {}
    ctx = room_context(project)
    eff = {a.id: effective_rooms(project, a, ctx) for a in project.acts.values()}
    for a in project.acts.values():
        if len(eff[a.id]) == 1 and a.id in placements:
            room = eff[a.id][0]
            d, p = placements[a.id]
            for k in range(a.duration):
                occupant[(room, d * P + p + k)] = a.id
            assign[a.id] = room
    flexible = [a for a in project.acts.values() if len(eff[a.id]) > 1 and a.active and a.id in placements]
    flex_rooms = {a.id: eff[a.id] for a in flexible}
    flexible.sort(key=lambda a: len(flex_rooms[a.id]))
    room_na = {n: {d * P + p for d, p in s} for (k, n), s in project.unavail.items() if k == "room"}

    def slots(a):
        d, p = placements[a.id]
        return [d * P + p + k for k in range(a.duration)]

    def try_place(a, depth, seen):
        sl = slots(a)
        for room in flex_rooms[a.id]:
            if any(x in room_na.get(room, ()) for x in sl):
                continue
            blockers = {occupant[(room, x)] for x in sl if (room, x) in occupant}
            if not blockers:
                for x in sl:
                    occupant[(room, x)] = a.id
                assign[a.id] = room
                return True
        if depth <= 0:
            return False
        for room in flex_rooms[a.id]:
            if any(x in room_na.get(room, ()) for x in sl):
                continue
            blockers = {occupant[(room, x)] for x in sl if (room, x) in occupant}
            if any(b in seen or b not in flex_rooms for b in blockers):
                continue
            saved = {}
            for b in blockers:
                ba = project.acts[b]
                saved[b] = assign.pop(b)
                for x in slots(ba):
                    occupant.pop((saved[b], x), None)
            for x in sl:
                occupant[(room, x)] = a.id
            assign[a.id] = room
            ok = True
            for b in blockers:
                if not try_place(project.acts[b], depth - 1, seen | {a.id}):
                    ok = False
                    break
            if ok:
                return True
            for x in sl:
                occupant.pop((room, x), None)
            assign.pop(a.id, None)
            for b in blockers:
                ba = project.acts[b]
                if b in assign:
                    for x in slots(ba):
                        occupant.pop((assign[b], x), None)
                    assign.pop(b)
                assign[b] = saved[b]
                for x in slots(ba):
                    occupant[(saved[b], x)] = b
        return False

    miss = []
    for a in flexible:
        if not try_place(a, 2, set()):
            miss.append(f"لا توجد قاعة حرّة للحصة {a.id} ({a.subject} — {'، '.join(a.students)})")
    return assign, miss


def generate(project, seconds=60.0, seed=None, log=None, stop=None, progress=None, keep_existing=False,
             seed_low=False, t_factor=None) -> Result:
    """يولّد جدولاً ويكتب النتيجة في project (placements/room_assign).
    seed_low=True مع keep_existing=True: ابدأ من الجدول الموجود (مثل ناتج FET) بتلدين منخفض الحرارة."""
    s = Solver(project, seed=seed, log=log, stop=stop, keep_existing=keep_existing, seed_low=seed_low,
               t_factor=t_factor)
    if seconds is None or seconds <= 0:
        r = s.solve_unlimited(progress=progress)
    else:
        r = s.solve(seconds=seconds, progress=progress)
    project.placements = dict(r.placements)
    project.room_assign = dict(r.room_assign)
    return r
