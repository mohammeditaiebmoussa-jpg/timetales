@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (python app_tk.py) else (py app_tk.py)
pause
