"""يبني مشروعاً تجريبياً واقعياً (ثانوية: 5 أيام × 8 حصص، صباح/مساء) لاختبار المولّد."""
import random
from tt_model import Project, Year, Group


def demo(n_classes=16, seed=3, per_teacher=4, unavail_teachers=4):
    rng = random.Random(seed)
    p = Project(institution="ثانوية تجريبية")
    subjects = [("الرياضيات", 4), ("الفيزياء", 3), ("العلوم", 3), ("العربية", 4), ("الفرنسية", 3),
                ("الإنجليزية", 2), ("التاريخ والجغرافيا", 3), ("الإسلامية", 2), ("الفلسفة", 2), ("الرياضة", 2)]
    p.subjects = [s for s, _ in subjects]
    # أساتذة: لكل مادة أستاذ لكل 4 أقسام تقريباً
    teachers = {}
    for si, (s, h) in enumerate(subjects):
        k = (n_classes + per_teacher - 1) // per_teacher
        teachers[s] = [f"أ.م{si + 1}-{i + 1}" for i in range(k)]
        p.teachers += teachers[s]
    halls = [f"قاعة رياضة {i + 1}" for i in range(max(1, n_classes // 10))]
    p.rooms = ["مخبر1", "مخبر2"] + halls
    for lvl in range(1, 4):
        y = Year(f"السنة {lvl}")
        for c in range(n_classes // 3 + (1 if lvl <= n_classes % 3 else 0)):
            g = Group(f"{lvl}م{c + 1}", [f"{lvl}م{c + 1}_ف1", f"{lvl}م{c + 1}_ف2"])
            y.groups.append(g)
        p.years.append(y)
    ci = 0
    for y in p.years:
        for g in y.groups:
            for s, h in subjects:
                t = teachers[s][ci // per_teacher % len(teachers[s])]
                if s == "الفيزياء":
                    # أعمال تطبيقية بالأفواج + درس بالقسم
                    p.add_activities([t], s, [g.name], [2], "")
                    p.add_activities([t], s + " (تطبيقي)", [g.subgroups[0]], [1], "مخبر1")
                    p.add_activities([t], s + " (تطبيقي)", [g.subgroups[1]], [1], "مخبر2")
                elif s == "الرياضة":
                    p.add_activities([t], s, [g.name], [2], "", halls)
                else:
                    pat = {4: [2, 1, 1], 3: [2, 1], 2: [1, 1]}[h]
                    p.add_activities([t], s, [g.name], pat)
            ci += 1
    # عدم توفّر أحد الأساتذة أيام الخميس مساءً
    for ts in list(teachers.values())[:unavail_teachers]:
        p.unavail[("teacher", ts[0])] = {(4, k) for k in range(4, 8)}
    p.default_teacher_max_daily = 6
    p.default_students_max_daily = 8
    return p
