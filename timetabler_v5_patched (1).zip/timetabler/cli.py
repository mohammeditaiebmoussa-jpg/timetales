"""واجهة سطر الأوامر.

  py cli.py generate مدخل.fet --out ناتج.fet [--asc ناتج.xml] [--xlsx جداول.xlsx] [--html جداول.html]
                      [--seconds 120] [--seed 1] [--keep]
  py cli.py asc      ملف.fet --out ملف_aSc.xml      (تحويل ملف جدول جاهز، كما يفعل FET to aSc)
  py cli.py check    ملف.fet                         (فحص تعارضات وتشخيص)
  py cli.py demo     --out مثال.fet                  (إنشاء مشروع تجريبي)
"""
import argparse
import sys

import asc_export
import exporters
import tt_solver
from tt_model import Project


def _log(m):
    print(m, flush=True)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["generate", "asc", "check", "demo"])
    ap.add_argument("input", nargs="?")
    ap.add_argument("--out")
    ap.add_argument("--asc")
    ap.add_argument("--xlsx")
    ap.add_argument("--html")
    ap.add_argument("--seconds", type=float, default=60, help="0 = بلا حدّ زمني (أوقفه بـ Ctrl+C فيُحفظ الأفضل)")
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--keep", action="store_true", help="ابدأ من الأوقات الموجودة في الملف")
    ap.add_argument("--seed-low", action="store_true", help="مع --keep: ابدأ من جدول FET الجاهز بتلدين أبرد")
    ap.add_argument("--t-factor", type=float, default=None, help="معامل حرارة البدء عند --seed-low (الافتراضي 3.0)")
    a = ap.parse_args(argv)

    if a.cmd == "demo":
        import make_demo
        p = make_demo.demo(16)
        p.save(a.out or "demo.fet")
        print("تم إنشاء", a.out or "demo.fet", "—", len(p.acts), "حصة")
        return 0
    if not a.input:
        ap.error("حدّد ملف الإدخال")
    p = Project.load(a.input)
    print(f"{p.institution}: {len(p.teachers)} أستاذ، {len(p.classes())} قسم، {len(p.acts)} حصة، "
          f"{len(p.placements)} موضوعة")
    if p.extra_time or p.extra_space:
        print(f"تنبيه: {len(p.extra_time) + len(p.extra_space)} قيداً غير مدعوم في هذا المولّد "
              f"(يُحفظ في الملف ولا يُراعى عند التوليد)")

    if a.cmd == "check":
        for m in tt_solver.diagnose(p):
            print(" -", m)
        cs = p.to_view().conflicts()
        print("تعارضات الجدول الحالي:", len(cs))
        return 0
    if a.cmd == "generate":
        for m in tt_solver.diagnose(p):
            print(" تشخيص:", m)
        import signal
        stop_flag = {"v": False}
        signal.signal(signal.SIGINT, lambda *_: stop_flag.__setitem__("v", True))
        r = tt_solver.generate(p, seconds=a.seconds, seed=a.seed, log=_log, keep_existing=a.keep, seed_low=a.seed_low, t_factor=a.t_factor,
                               stop=lambda: stop_flag["v"])
        print(f"النتيجة: تعارضات صلبة={r.hard_left} · تكلفة ناعمة={r.soft_cost} · {r.seconds:.1f}ث")
        for m in r.problems[:20]:
            print(" !", m)
        if a.out:
            p.save(a.out)
            print("حُفظ:", a.out)
    if a.cmd in ("generate", "asc"):
        out = a.asc if a.cmd == "generate" else (a.out or a.input.rsplit(".", 1)[0] + "_aSc.xml")
        if out:
            n = asc_export.export_asc(p, out)
            print("aSc:", n, "حصة →", out)
    if a.xlsx:
        print("Excel:", exporters.export_excel(p.to_view(), a.xlsx), "جدول")
    if a.html:
        v = p.to_view()
        with open(a.html, "w", encoding="utf-8") as fh:
            fh.write(exporters.standalone_html(v, exporters.all_items(v)))
        print("HTML:", a.html)
    return 0


if __name__ == "__main__":
    sys.exit(main())
