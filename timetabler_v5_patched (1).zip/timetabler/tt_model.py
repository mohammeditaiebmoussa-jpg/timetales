"""نموذج بيانات الجدول الزمني + قراءة/كتابة ملفات FET (.fet).

الزمن داخلياً: أيام حقيقية × حصص حقيقية. في نمط FET «Mornings_Afternoons» يُحوَّل
اليوم الخام (صباح/مساء) إلى (يوم حقيقي، حصة من 0..2H-1) عند القراءة ويُعاد عند الكتابة.
"""
from __future__ import annotations

import copy
import xml.etree.ElementTree as ET
import tt_constraints as tc_mod
from dataclasses import dataclass, field

FET_VERSION = "7.5.6"
MORNING_SUFFIX = " صباحا"
AFTERNOON_SUFFIX = " مساء"


PARALLEL_TAG = "TT_PARALLEL="


def _parse_parallel(text: str) -> int:
    """يقرأ رقم التزامن من حقل التعليقات (يحفظه البرنامج هناك لتبقى الملفات متوافقة مع FET)."""
    if text and PARALLEL_TAG in text:
        try:
            return int(text.split(PARALLEL_TAG, 1)[1].split()[0])
        except (ValueError, IndexError):
            return 0
    return 0


# --------------------------------------------------------------------- مساعدات XML
def _t(el, tag, default=""):
    if el is None:
        return default
    c = el.find(tag)
    return (c.text or default).strip() if c is not None and c.text is not None else default


def _indent(el, level=0):
    pad = "\n" + level * "\t"
    if len(el):
        if not (el.text and el.text.strip()):
            el.text = pad + "\t"
        for ch in el:
            _indent(ch, level + 1)
            if not (ch.tail and ch.tail.strip()):
                ch.tail = pad + "\t"
        if not (el[-1].tail and el[-1].tail.strip()):
            el[-1].tail = pad
    if level and not (el.tail and el.tail.strip()):
        el.tail = pad


def _sub(parent, tag, text=None):
    e = ET.SubElement(parent, tag)
    if text is not None:
        e.text = str(text)
    return e


# --------------------------------------------------------------------- الكيانات
@dataclass
class Act:
    id: int
    teachers: list = field(default_factory=list)
    subject: str = ""
    students: list = field(default_factory=list)   # أسماء مجموعات (سنة/قسم/فوج)
    duration: int = 1
    total_duration: int = 0
    group_id: int = 0          # حصص المادة الواحدة المقسّمة تشترك في هذا الرقم
    active: bool = True
    room: str = ""             # قاعة محددة (تُعدّ موردًا في التوليد)
    rooms: list = field(default_factory=list)   # قاعات مفضّلة متعددة (تُوزَّع بعد التوليد)
    parallel: int = 0          # حصص متزامنة: نفس الرقم = تُدرَّس معاً في نفس الوقت لنفس القسم (أساتذة مختلفون)


@dataclass
class Subgroup:
    name: str


@dataclass
class Group:
    name: str
    subgroups: list = field(default_factory=list)   # list[str]


@dataclass
class Year:
    name: str
    groups: list = field(default_factory=list)      # list[Group]


@dataclass
class Project:
    path: str = ""
    institution: str = "مؤسسة تعليمية"
    days: list = field(default_factory=lambda: ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس"])
    periods: list = field(default_factory=lambda: [f"حصة {i}" for i in range(1, 9)])
    halves: int = 2                 # 1 = يوم متصل ، 2 = صباح/مساء
    raw_days: list = field(default_factory=list)    # أسماء FET الخام (للحفاظ على الملفات المقروءة)
    raw_hours: list = field(default_factory=list)
    teachers: list = field(default_factory=list)
    subjects: list = field(default_factory=list)
    rooms: list = field(default_factory=list)
    years: list = field(default_factory=list)       # list[Year]
    acts: dict = field(default_factory=dict)        # id -> Act
    placements: dict = field(default_factory=dict)  # id -> (day, period)
    locked: set = field(default_factory=set)        # أرقام الحصص المثبّتة (لا تتحرك)
    room_assign: dict = field(default_factory=dict) # id -> اسم القاعة النهائية
    # قيود
    unavail: dict = field(default_factory=dict)     # ("teacher"|"students"|"room", name) -> set[(d,p)]
    teacher_max_daily: dict = field(default_factory=dict)
    teacher_max_days: dict = field(default_factory=dict)
    students_max_daily: dict = field(default_factory=dict)
    default_teacher_max_daily: int = 0
    default_students_max_daily: int = 0
    w_gaps_teacher: int = 2
    w_gaps_students: int = 3
    w_min_days: int = 10
    # إعدادات aSc
    day_shorts: list = field(default_factory=list)
    first_hour: int = 8             # بداية الحصة 1 (بالساعة)
    period_minutes: int = 60
    constraints: list = field(default_factory=list)   # list[tt_constraints.Constraint]
    # قيود غير مدعومة تُحفظ كما هي عند الكتابة
    extra_time: list = field(default_factory=list)
    extra_space: list = field(default_factory=list)

    # ------------------------------------------------------------- زمن
    @property
    def n_days(self) -> int:
        return len(self.days)

    @property
    def n_periods(self) -> int:
        return len(self.periods)

    @property
    def half_len(self) -> int:
        return self.n_periods // self.halves if self.halves > 1 else self.n_periods

    def next_act_id(self) -> int:
        return (max(self.acts) + 1) if self.acts else 1

    def next_group_id(self) -> int:
        return max([a.group_id for a in self.acts.values()] + [0]) + 1

    def next_parallel_id(self) -> int:
        return max([a.parallel for a in self.acts.values()] + [0]) + 1

    # ------------------------------------------------------------- حصص متزامنة
    def check_parallel(self, ids) -> None:
        """يتحقق أن مجموعة الحصص صالحة للتزامن (نفس المدة، أساتذة مختلفون)."""
        acts = [self.acts[i] for i in ids]
        if len({max(1, a.duration) for a in acts}) > 1:
            raise ValueError("الحصص المتزامنة يجب أن تكون بنفس المدة.")
        seen = {}
        for a in acts:
            for t in a.teachers:
                if t in seen and seen[t] != a.id:
                    raise ValueError(f"الأستاذ «{t}» موجود في حصتين متزامنتين (لا يمكنه التدريس في مكانين).")
                seen[t] = a.id
            rooms = [a.room] if a.room else []
            for r in rooms:
                key = ("room", r)
                if key in seen and seen[key] != a.id:
                    raise ValueError(f"القاعة «{r}» محجوزة لحصتين متزامنتين.")
                seen[key] = a.id

    def link_parallel(self, ids) -> int:
        """يجعل الحصص المحددة متزامنة (تُوضع في نفس الوقت ويُسمح لها بمشاركة القسم)."""
        ids = list(dict.fromkeys(i for i in ids if i in self.acts))
        pars = {self.acts[i].parallel for i in ids if self.acts[i].parallel}
        full = set(ids) | {a.id for a in self.acts.values() if a.parallel and a.parallel in pars}
        if len(full) < 2:
            raise ValueError("اختر حصتين على الأقل.")
        self.check_parallel(sorted(full))
        pid = min(pars) if pars else self.next_parallel_id()
        for i in full:
            self.acts[i].parallel = pid
        return pid

    def unlink_parallel(self, ids) -> None:
        pars = set()
        for i in ids:
            a = self.acts.get(i)
            if a and a.parallel:
                pars.add(a.parallel)
                a.parallel = 0
        for pid in pars:
            left = [a for a in self.acts.values() if a.parallel == pid]
            if len(left) == 1:
                left[0].parallel = 0

    def add_parallel_to(self, anchor_id: int, new_ids) -> None:
        """يجعل الحصص الجديدة متزامنة مع سلسلة الحصة anchor_id، حصةً بحصة بالترتيب."""
        anchor = self.acts.get(anchor_id)
        if anchor is None:
            raise ValueError(f"لا توجد حصة بالرقم {anchor_id}.")
        series = sorted((a.id for a in self.acts.values() if anchor.group_id and a.group_id == anchor.group_id)
                        or [anchor_id])
        new_ids = sorted(new_ids)
        if len(series) != len(new_ids):
            raise ValueError(f"عدد حصص التوزيع ({len(new_ids)}) يختلف عن حصص الحصة {anchor_id} ({len(series)}).")
        for x, y in zip(series, new_ids):
            if self.acts[x].duration != self.acts[y].duration:
                raise ValueError("مدد الحصص غير متطابقة مع الحصة المتزامن معها.")
        for x, y in zip(series, new_ids):
            self.link_parallel([x, y])

    # ------------------------------------------------------------- الأقسام
    def all_group_names(self) -> list:
        out = []
        for y in self.years:
            out.append(y.name)
            for g in y.groups:
                out.append(g.name)
                out.extend(g.subgroups)
        return out

    def classes(self) -> list:
        """«الأقسام» بمعنى aSc/العارض: مجموعات FET (Group) ذات المستوى الثاني."""
        return [g.name for y in self.years for g in y.groups]

    # ---- جسر الحدود الأساسية (تُخزَّن في حقول المشروع كما يقرؤها FET) مع واجهة القيود
    BASIC = (("max_hours_daily", "teacher"), ("max_hours_daily", "students"), ("max_days_week", "teacher"))

    def is_basic(self, kind: str, who: str, target: str) -> bool:
        if (kind, who) not in self.BASIC:
            return False
        return not (kind == "max_days_week" and not target)      # «كل الأساتذة» لا حقل أساسي له

    def basic_rows(self) -> list:
        rows = []
        if self.default_teacher_max_daily:
            rows.append(("max_hours_daily", "teacher", "", self.default_teacher_max_daily))
        rows += [("max_hours_daily", "teacher", n, v) for n, v in sorted(self.teacher_max_daily.items()) if v]
        if self.default_students_max_daily:
            rows.append(("max_hours_daily", "students", "", self.default_students_max_daily))
        rows += [("max_hours_daily", "students", n, v) for n, v in sorted(self.students_max_daily.items()) if v]
        rows += [("max_days_week", "teacher", n, v) for n, v in sorted(self.teacher_max_days.items()) if v]
        return rows

    def set_basic(self, kind: str, who: str, target: str, value: int) -> None:
        if kind == "max_hours_daily" and who == "teacher":
            if target:
                self.teacher_max_daily[target] = value
            else:
                self.default_teacher_max_daily = value
        elif kind == "max_hours_daily":
            if target:
                self.students_max_daily[target] = value
            else:
                self.default_students_max_daily = value
        else:
            self.teacher_max_days[target] = value

    def clear_basic(self, kind: str, who: str, target: str) -> None:
        if kind == "max_hours_daily" and who == "teacher":
            if target:
                self.teacher_max_daily.pop(target, None)
            else:
                self.default_teacher_max_daily = 0
        elif kind == "max_hours_daily":
            if target:
                self.students_max_daily.pop(target, None)
            else:
                self.default_students_max_daily = 0
        else:
            self.teacher_max_days.pop(target, None)

    def act_matches(self, a, c) -> bool:
        """هل تطابق الحصة مرشّحات القيد c (أستاذ/قسم/مادة/مدة)؟"""
        if c.f_teacher and c.f_teacher not in a.teachers:
            return False
        if c.f_subject and a.subject != c.f_subject:
            return False
        if c.f_duration and a.duration != c.f_duration:
            return False
        if c.f_students and not any(s == c.f_students or c.f_students in self.parents(s) for s in a.students):
            return False
        return True

    def acts_rooms_for(self, a) -> list:
        """قاعات الحصة بحسب قيود «قاعات لمجموعة حصص» (فارغة إن لم يوجد)."""
        for c in self.constraints:
            if c.kind == "acts_rooms" and c.active and c.weight > 0 and c.rooms and self.act_matches(a, c):
                return list(c.rooms)
        return []

    def parents(self, name: str) -> list:
        """أسماء المجموعات الأعلى (قسم ثم مستوى) لاسم فوج/قسم."""
        out = []
        for y in self.years:
            for g in y.groups:
                if name == g.name or name in g.subgroups:
                    if name != g.name:
                        out.append(g.name)
                    out.append(y.name)
                    return out
        return out

    def leaves(self, name: str) -> list:
        """الأفواج الذرّية التي يتكوّن منها اسم مجموعة (سنة/قسم/فوج)."""
        for y in self.years:
            if y.name == name:
                out = []
                for g in y.groups:
                    out.extend(g.subgroups or [g.name])
                return out or [y.name]
            for g in y.groups:
                if g.name == name:
                    return list(g.subgroups) or [g.name]
        return [name]   # فوج أو اسم غير معروف

    # ------------------------------------------------------------- إضافة حصص
    def add_activities(self, teachers, subject, students, pattern, room="", rooms=None) -> list:
        """pattern مثل [2,1,1] ينتج 3 حصص بنفس group_id."""
        gid = self.next_group_id() if len(pattern) > 1 else 0
        total = sum(pattern)
        ids = []
        for d in pattern:
            aid = self.next_act_id()
            self.acts[aid] = Act(aid, list(teachers), subject, list(students), int(d), total, gid,
                                 True, room, list(rooms or []))
            ids.append(aid)
        return ids

    # ------------------------------------------------------------- نسخ/عرض
    def clone(self) -> "Project":
        return copy.deepcopy(self)

    def to_view(self):
        """يبني كائن FetProject (للعارض والمصدّرات الجاهزة) من الحالة الحالية."""
        import fet_model as fm
        v = fm.FetProject(path=self.path, institution=self.institution, mode="Normal")
        v.days = list(self.days)
        v.hours = list(self.periods)
        v.real_days = list(self.days)
        v.real_hours = list(self.periods)
        v.teachers = list(self.teachers)
        v.subjects = list(self.subjects)
        v.classes = list(self.classes()) or list(self.all_group_names())
        v.rooms = list(self.rooms)
        for a in self.acts.values():
            v.activities[a.id] = fm.Activity(a.id, list(a.teachers), a.subject, " + ".join(a.students),
                                              a.duration, a.total_duration or a.duration, a.group_id, a.active,
                                              a.parallel)
            r = self.room_assign.get(a.id) or a.room
            if r:
                v.activity_rooms[a.id] = [r]
            elif a.rooms:
                v.activity_rooms[a.id] = list(a.rooms)
        v.placements = dict(self.placements)
        v._build_lessons()
        return v


    # ------------------------------------------------------------- تحرير
    def usage(self, kind: str, name: str) -> int:
        """عدد الحصص التي تستعمل هذا الاسم. kind: teacher|subject|room|students"""
        n = 0
        for a in self.acts.values():
            if kind == "teacher" and name in a.teachers:
                n += 1
            elif kind == "subject" and a.subject == name:
                n += 1
            elif kind == "room" and (a.room == name or name in a.rooms):
                n += 1
            elif kind == "students" and name in a.students:
                n += 1
        return n

    def rename(self, kind: str, old: str, new: str) -> None:
        if not new or old == new:
            return
        lst = {"teacher": self.teachers, "subject": self.subjects, "room": self.rooms}.get(kind)
        if lst is not None:
            lst[:] = [new if x == old else x for x in lst]
        for a in self.acts.values():
            if kind == "teacher":
                a.teachers = [new if x == old else x for x in a.teachers]
            elif kind == "subject" and a.subject == old:
                a.subject = new
            elif kind == "room":
                if a.room == old:
                    a.room = new
                a.rooms = [new if x == old else x for x in a.rooms]
            elif kind == "students":
                a.students = [new if x == old else x for x in a.students]
        ukind = {"teacher": "teacher", "room": "room", "students": "students"}.get(kind)
        if ukind:
            for k in [k for k in self.unavail if k == (ukind, old)]:
                self.unavail[(ukind, new)] = self.unavail.pop(k)
        if kind == "teacher":
            for d in (self.teacher_max_daily, self.teacher_max_days):
                if old in d:
                    d[new] = d.pop(old)
        if kind == "students":
            if old in self.students_max_daily:
                self.students_max_daily[new] = self.students_max_daily.pop(old)
            for y in self.years:
                if y.name == old:
                    y.name = new
                for g in y.groups:
                    if g.name == old:
                        g.name = new
                    g.subgroups = [new if x == old else x for x in g.subgroups]
        if kind == "room":
            for aid, r in list(self.room_assign.items()):
                if r == old:
                    self.room_assign[aid] = new

    def delete_name(self, kind: str, name: str) -> bool:
        """يحذف أستاذاً/مادة/قاعة غير مستعملة. يعيد False إن كانت مستعملة."""
        if self.usage(kind, name):
            return False
        lst = {"teacher": self.teachers, "subject": self.subjects, "room": self.rooms}[kind]
        if name in lst:
            lst.remove(name)
        self.unavail.pop((kind, name), None)
        self.teacher_max_daily.pop(name, None) if kind == "teacher" else None
        self.teacher_max_days.pop(name, None) if kind == "teacher" else None
        return True

    def delete_activity(self, aid: int) -> None:
        a = self.acts.pop(aid, None)
        if a is not None and a.parallel:
            left = [x for x in self.acts.values() if x.parallel == a.parallel]
            if len(left) == 1:
                left[0].parallel = 0
        self.placements.pop(aid, None)
        self.room_assign.pop(aid, None)
        self.locked.discard(aid)

    def clear_schedule(self) -> None:
        self.placements = {k: v for k, v in self.placements.items() if k in self.locked}
        self.room_assign.clear()

    def ensure_students(self, name: str) -> None:
        """يضيف مجموعة غير معروفة كقسم تحت سنة «الأقسام»."""
        if name in self.all_group_names():
            return
        for y in self.years:
            if y.name == "الأقسام":
                y.groups.append(Group(name, []))
                return
        self.years.append(Year("الأقسام", [Group(name, [])]))

    def import_rows(self, rows) -> int:
        """rows: قوائم [أستاذ, مادة, قسم, توزيع, قاعة]؛ الأعمدة المتعددة تُفصل بـ + أو ،"""
        import re
        n = 0
        tagged = {}
        for row in rows:
            cells = [("" if c is None else str(c)).strip() for c in row] + [""] * 6
            t, s, st, pat, room, tag = cells[:6]
            if not (t and s and st):
                continue
            teachers = [x.strip() for x in re.split(r"[+،,]", t) if x.strip()]
            studs = [x.strip() for x in re.split(r"[+،,]", st) if x.strip()]
            try:
                pattern = [int(float(x)) for x in re.split(r"[+،,\s]+", pat) if x] or [1]
            except ValueError:
                continue
            if any(x <= 0 for x in pattern):
                continue
            for x in teachers:
                if x not in self.teachers:
                    self.teachers.append(x)
            if s not in self.subjects:
                self.subjects.append(s)
            for x in studs:
                self.ensure_students(x)
            rooms = [x.strip() for x in re.split(r"[+،,]", room) if x.strip()]
            for r in rooms:
                if r not in self.rooms:
                    self.rooms.append(r)
            ids = self.add_activities(teachers, s, studs, pattern, rooms[0] if len(rooms) == 1 else "",
                                      rooms if len(rooms) > 1 else None)
            if tag:
                tagged.setdefault(tag, []).append(ids)
            n += 1
        # العمود السادس (اختياري): رمز التزامن — الصفوف بنفس الرمز تُدرَّس معاً حصةً بحصة
        self.import_parallel_errors = []
        for tag, lists in tagged.items():
            if len(lists) < 2 or len({len(x) for x in lists}) != 1:
                self.import_parallel_errors.append(f"التزامن «{tag}»: يجب صفّان على الأقل بنفس التوزيع")
                continue
            for k in range(len(lists[0])):
                try:
                    self.link_parallel([x[k] for x in lists])
                except ValueError as exc:
                    self.import_parallel_errors.append(f"التزامن «{tag}»: {exc}")
                    break
        return n

    # ------------------------------------------------------------- قراءة FET
    @classmethod
    def load(cls, path: str) -> "Project":
        root = ET.parse(path).getroot()
        if root.tag != "fet":
            raise ValueError("هذا الملف ليس ملف FET صالحاً")
        p = cls(path=path)
        p.institution = _t(root, "Institution_Name") or p.institution
        mode = _t(root, "Mode", "Normal")
        raw_days = [_t(d, "Name") for d in root.findall("Days_List/Day")]
        raw_hours = [_t(h, "Name") for h in root.findall("Hours_List/Hour")]
        real_days = [_t(d, "Name") for d in root.findall("Real_Days_List/Real_Day")]
        real_hours = [_t(h, "Name") for h in root.findall("Real_Hours_List/Real_Hour")]
        p.raw_days, p.raw_hours = raw_days, raw_hours
        if mode == "Mornings_Afternoons" and real_days and real_hours:
            p.halves, p.days, p.periods = 2, real_days, real_hours
        else:
            p.halves, p.days, p.periods = 1, raw_days, raw_hours
            p.raw_days, p.raw_hours = [], []
        hh = len(raw_hours)

        def to_real(dn, hn):
            try:
                d, h = raw_days.index(dn), raw_hours.index(hn)
            except ValueError:
                return None
            return (d // 2, (d % 2) * hh + h) if p.halves == 2 else (d, h)

        p.teachers = [_t(x, "Name") for x in root.findall("Teachers_List/Teacher")]
        p.subjects = [_t(x, "Name") for x in root.findall("Subjects_List/Subject")]
        p.rooms = [_t(x, "Name") for x in root.findall("Rooms_List/Room")]
        for y in root.findall("Students_List/Year"):
            yr = Year(_t(y, "Name"))
            for g in y.findall("Group"):
                gr = Group(_t(g, "Name"), [_t(s, "Name") for s in g.findall("Subgroup")])
                yr.groups.append(gr)
            p.years.append(yr)

        for a in root.findall("Activities_List/Activity"):
            aid = int(_t(a, "Id", "0"))
            dur = int(_t(a, "Duration", "1"))
            p.acts[aid] = Act(
                id=aid, teachers=[(x.text or "").strip() for x in a.findall("Teacher")],
                subject=_t(a, "Subject"), students=[(x.text or "").strip() for x in a.findall("Students")],
                duration=dur, total_duration=int(_t(a, "Total_Duration", str(dur))),
                group_id=int(_t(a, "Activity_Group_Id", "0")), active=_t(a, "Active", "true") == "true",
                parallel=_parse_parallel(_t(a, "Comments")))

        def na_times(c):
            out = set()
            for n in c.findall("Not_Available_Time"):
                r = to_real(_t(n, "Day"), _t(n, "Hour"))
                if r:
                    out.add(r)
            return out

        tcl = root.find("Time_Constraints_List")
        for c in (list(tcl) if tcl is not None else []):
            tag = c.tag
            if _t(c, "Active", "true") != "true":
                continue
            try:
                if tag == "ConstraintBasicCompulsoryTime":
                    continue
                elif tag == "ConstraintTeacherNotAvailableTimes":
                    p.unavail.setdefault(("teacher", _t(c, "Teacher")), set()).update(na_times(c))
                elif tag == "ConstraintStudentsSetNotAvailableTimes":
                    p.unavail.setdefault(("students", _t(c, "Students")), set()).update(na_times(c))
                elif tag in ("ConstraintTeacherMaxHoursDaily", "ConstraintTeacherMaxHoursDailyRealDays"):
                    p.teacher_max_daily[_t(c, "Teacher")] = int(_t(c, "Maximum_Hours_Daily"))
                elif tag in ("ConstraintTeachersMaxHoursDaily", "ConstraintTeachersMaxHoursDailyRealDays"):
                    p.default_teacher_max_daily = int(_t(c, "Maximum_Hours_Daily"))
                elif tag in ("ConstraintTeacherMaxDaysPerWeek", "ConstraintTeacherMaxRealDaysPerWeek"):
                    p.teacher_max_days[_t(c, "Teacher")] = int(_t(c, "Max_Days_Per_Week"))
                elif tag in ("ConstraintStudentsSetMaxHoursDaily", "ConstraintStudentsSetMaxHoursDailyRealDays"):
                    p.students_max_daily[_t(c, "Students")] = int(_t(c, "Maximum_Hours_Daily"))
                elif tag in ("ConstraintStudentsMaxHoursDaily", "ConstraintStudentsMaxHoursDailyRealDays"):
                    p.default_students_max_daily = int(_t(c, "Maximum_Hours_Daily"))
                elif tag == "ConstraintActivityPreferredStartingTime":
                    aid = int(_t(c, "Activity_Id", "0"))
                    r = to_real(_t(c, "Preferred_Day") or _t(c, "Day"), _t(c, "Preferred_Hour") or _t(c, "Hour"))
                    if r and aid in p.acts:
                        p.placements[aid] = r
                        if _t(c, "Permanently_Locked", "false") == "true":
                            p.locked.add(aid)
                else:
                    k = tc_mod.from_element(c, to_real)
                    if k is not None:
                        p.constraints.append(k)
                    else:
                        p.extra_time.append(ET.tostring(c, encoding="unicode"))
            except (ValueError, KeyError):
                p.extra_time.append(ET.tostring(c, encoding="unicode"))

        scl = root.find("Space_Constraints_List")
        for c in (list(scl) if scl is not None else []):
            if _t(c, "Active", "true") != "true":
                continue
            tag = c.tag
            if tag == "ConstraintBasicCompulsorySpace":
                continue
            if tag == "ConstraintActivityPreferredRoom":
                aid = int(_t(c, "Activity_Id", "0"))
                if aid in p.acts:
                    p.acts[aid].room = _t(c, "Room")
            elif tag == "ConstraintActivityPreferredRooms":
                aid = int(_t(c, "Activity_Id", "0"))
                if aid in p.acts:
                    p.acts[aid].rooms = [(x.text or "").strip() for x in c.findall("Preferred_Room")]
            elif tag == "ConstraintRoomNotAvailableTimes":
                p.unavail.setdefault(("room", _t(c, "Room")), set()).update(na_times(c))
            else:
                k = tc_mod.from_element(c, to_real)
                if k is not None:
                    p.constraints.append(k)
                else:
                    p.extra_space.append(ET.tostring(c, encoding="unicode"))
        return p

    # ------------------------------------------------------------- كتابة FET
    def _raw_names(self):
        if self.halves == 2:
            hh = self.half_len
            hours = self.raw_hours if len(self.raw_hours) == hh else [x for x in self.periods[:hh]]
            if len(set(hours)) != len(hours):
                hours = [f"{i + 1}" for i in range(hh)]
            if len(self.raw_days) == 2 * self.n_days:
                days = self.raw_days
            else:
                days = []
                for d in self.days:
                    days += [d + MORNING_SUFFIX, d + AFTERNOON_SUFFIX]
            return days, hours
        return list(self.days), list(self.periods)

    def _to_raw(self, d, pidx, days, hours):
        if self.halves == 2:
            hh = self.half_len
            return days[2 * d + pidx // hh], hours[pidx % hh]
        return days[d], hours[pidx]

    def save(self, path: str) -> None:
        raw_days, raw_hours = self._raw_names()
        root = ET.Element("fet", version=FET_VERSION)
        _sub(root, "Mode", "Mornings_Afternoons" if self.halves == 2 else "Normal")
        _sub(root, "Institution_Name", self.institution)
        _sub(root, "Comments", "Created by Timetabler")
        dl = _sub(root, "Days_List")
        _sub(dl, "Number_of_Days", len(raw_days))
        for n in raw_days:
            _sub(_sub(dl, "Day"), "Name", n)
        if self.halves == 2:
            rl = _sub(root, "Real_Days_List")
            _sub(rl, "Number_of_Real_Days", self.n_days)
            for n in self.days:
                _sub(_sub(rl, "Real_Day"), "Name", n)
        hl = _sub(root, "Hours_List")
        _sub(hl, "Number_of_Hours", len(raw_hours))
        for n in raw_hours:
            _sub(_sub(hl, "Hour"), "Name", n)
        if self.halves == 2:
            rl = _sub(root, "Real_Hours_List")
            _sub(rl, "Number_of_Real_Hours", self.n_periods)
            for n in self.periods:
                _sub(_sub(rl, "Real_Hour"), "Name", n)

        tl = _sub(root, "Teachers_List")
        for n in self.teachers:
            t = _sub(tl, "Teacher")
            _sub(t, "Name", n)
        sl = _sub(root, "Subjects_List")
        for n in self.subjects:
            _sub(_sub(sl, "Subject"), "Name", n)
        _sub(root, "Activity_Tags_List")
        stl = _sub(root, "Students_List")
        for y in self.years:
            ye = _sub(stl, "Year")
            _sub(ye, "Name", y.name)
            _sub(ye, "Number_of_Students", 0)
            for g in y.groups:
                ge = _sub(ye, "Group")
                _sub(ge, "Name", g.name)
                _sub(ge, "Number_of_Students", 0)
                for s in g.subgroups:
                    se = _sub(ge, "Subgroup")
                    _sub(se, "Name", s)
                    _sub(se, "Number_of_Students", 0)
        al = _sub(root, "Activities_List")
        for a in sorted(self.acts.values(), key=lambda x: x.id):
            ae = _sub(al, "Activity")
            for t in a.teachers:
                _sub(ae, "Teacher", t)
            _sub(ae, "Subject", a.subject)
            for s in a.students:
                _sub(ae, "Students", s)
            _sub(ae, "Duration", a.duration)
            _sub(ae, "Total_Duration", a.total_duration or a.duration)
            _sub(ae, "Id", a.id)
            _sub(ae, "Activity_Group_Id", a.group_id)
            _sub(ae, "Active", "true" if a.active else "false")
            _sub(ae, "Comments", f"{PARALLEL_TAG}{a.parallel}" if a.parallel else "")
        _sub(root, "Buildings_List")
        rl = _sub(root, "Rooms_List")
        for n in self.rooms:
            r = _sub(rl, "Room")
            _sub(r, "Name", n)
            _sub(r, "Building", "")
            _sub(r, "Capacity", 30000)

        suffix = "RealDays" if self.halves == 2 else ""
        tc = _sub(root, "Time_Constraints_List")
        c = _sub(tc, "ConstraintBasicCompulsoryTime")
        _sub(c, "Weight_Percentage", 100)
        _sub(c, "Active", "true")

        def emit_na(parent, tag, field_tag, name, slots):
            c = _sub(parent, tag)
            _sub(c, "Weight_Percentage", 100)
            _sub(c, field_tag, name)
            _sub(c, "Number_of_Not_Available_Times", len(slots))
            for d, pi in sorted(slots):
                dn, hn = self._to_raw(d, pi, raw_days, raw_hours)
                n = _sub(c, "Not_Available_Time")
                _sub(n, "Day", dn)
                _sub(n, "Hour", hn)
            _sub(c, "Active", "true")

        for (kind, name), slots in sorted(self.unavail.items()):
            if slots and kind == "teacher":
                emit_na(tc, "ConstraintTeacherNotAvailableTimes", "Teacher", name, slots)
            elif slots and kind == "students":
                emit_na(tc, "ConstraintStudentsSetNotAvailableTimes", "Students", name, slots)

        def emit_num(parent, tag, who_tag, who, val_tag, val):
            c = _sub(parent, tag)
            _sub(c, "Weight_Percentage", 100)
            if who_tag:
                _sub(c, who_tag, who)
            _sub(c, val_tag, val)
            _sub(c, "Active", "true")

        if self.default_teacher_max_daily:
            emit_num(tc, f"ConstraintTeachersMaxHoursDaily{suffix}", None, None, "Maximum_Hours_Daily",
                     self.default_teacher_max_daily)
        if self.default_students_max_daily:
            emit_num(tc, f"ConstraintStudentsMaxHoursDaily{suffix}", None, None, "Maximum_Hours_Daily",
                     self.default_students_max_daily)
        for n, v in sorted(self.teacher_max_daily.items()):
            emit_num(tc, f"ConstraintTeacherMaxHoursDaily{suffix}", "Teacher", n, "Maximum_Hours_Daily", v)
        for n, v in sorted(self.teacher_max_days.items()):
            tag = "ConstraintTeacherMaxRealDaysPerWeek" if self.halves == 2 else "ConstraintTeacherMaxDaysPerWeek"
            emit_num(tc, tag, "Teacher", n, "Max_Days_Per_Week", v)
        for n, v in sorted(self.students_max_daily.items()):
            emit_num(tc, f"ConstraintStudentsSetMaxHoursDaily{suffix}", "Students", n, "Maximum_Hours_Daily", v)

        for aid in sorted(self.placements):
            if aid not in self.acts:
                continue
            d, pi = self.placements[aid]
            dn, hn = self._to_raw(d, pi, raw_days, raw_hours)
            c = _sub(tc, "ConstraintActivityPreferredStartingTime")
            _sub(c, "Weight_Percentage", 100)
            _sub(c, "Activity_Id", aid)
            _sub(c, "Preferred_Day", dn)
            _sub(c, "Preferred_Hour", hn)
            _sub(c, "Permanently_Locked", "true" if aid in self.locked else "false")
            _sub(c, "Active", "true")
        for k in self.constraints:
            if k.kind == "acts_rooms":
                continue
            sec, el = tc_mod.to_element(k, lambda d, p: self._to_raw(d, p, raw_days, raw_hours), real=(self.halves == 2))
            if sec == "time":
                tc.append(el)
        for x in self.extra_time:
            try:
                tc.append(ET.fromstring(x))
            except ET.ParseError:
                pass

        sc = _sub(root, "Space_Constraints_List")
        c = _sub(sc, "ConstraintBasicCompulsorySpace")
        _sub(c, "Weight_Percentage", 100)
        _sub(c, "Active", "true")
        for (kind, name), slots in sorted(self.unavail.items()):
            if slots and kind == "room":
                emit_na(sc, "ConstraintRoomNotAvailableTimes", "Room", name, slots)
        for a in sorted(self.acts.values(), key=lambda x: x.id):
            room = self.room_assign.get(a.id) or a.room
            if room:
                c = _sub(sc, "ConstraintActivityPreferredRoom")
                _sub(c, "Weight_Percentage", 100)
                _sub(c, "Activity_Id", a.id)
                _sub(c, "Room", room)
                _sub(c, "Permanently_Locked", "false")
                _sub(c, "Active", "true")
            else:
                rooms = a.rooms or self.acts_rooms_for(a)
                if len(rooms) == 1:
                    c = _sub(sc, "ConstraintActivityPreferredRoom")
                    _sub(c, "Weight_Percentage", 100)
                    _sub(c, "Activity_Id", a.id)
                    _sub(c, "Room", rooms[0])
                    _sub(c, "Permanently_Locked", "false")
                    _sub(c, "Active", "true")
                elif rooms:
                    c = _sub(sc, "ConstraintActivityPreferredRooms")
                    _sub(c, "Weight_Percentage", 100)
                    _sub(c, "Activity_Id", a.id)
                    _sub(c, "Number_of_Preferred_Rooms", len(rooms))
                    for r in rooms:
                        _sub(c, "Preferred_Room", r)
                    _sub(c, "Active", "true")
        for k in self.constraints:
            if k.kind not in tc_mod.SPACE or k.kind == "acts_rooms":
                continue
            sc.append(tc_mod.to_element(k, None)[1])
        for x in self.extra_space:
            try:
                sc.append(ET.fromstring(x))
            except ET.ParseError:
                pass

        _indent(root)
        ET.ElementTree(root).write(path, encoding="UTF-8", xml_declaration=True)
