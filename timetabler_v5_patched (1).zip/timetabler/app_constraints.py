"""واجهة القيود (زمانية ومكانية) بتصنيف FET — محرّر مضمّن في التبويب بلا نوافذ منبثقة.

يمين: شجرة التصنيفات وأنواع القيود. وسط: جدول القيود الموجودة. أسفل: محرّر القيد المحدد/الجديد.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk

import tt_constraints as tcm

OK_BG, NO_BG, OFF_BG = "#C6EFCE", "#F4B6B6", "#EEEEEE"
ANY = "(أي)"
ALL = "(الجميع)"
SUPPORTED_NOTE = {True: "✔", False: "ملف فقط"}


def act_label(p, a) -> str:
    par = f" | ⇄{a.parallel}" if getattr(a, "parallel", 0) else ""
    return f"{a.id} | {a.subject} | {' + '.join(a.students)} | {' + '.join(a.teachers)} | {a.duration}س{par}"


class SlotGrid(tk.Frame):
    """شبكة أيام × حصص: انقر خانة لتبديلها، وانقر اسم اليوم/الحصة لتبديل العمود/الصف."""

    def __init__(self, master, project, slots=()):
        super().__init__(master)
        self.p = project
        self.slots = {tuple(s) for s in slots}
        self.cells = {}
        nd, npd = len(project.days), len(project.periods)
        corner = tk.Label(self, text="", relief="solid", bd=1, bg="#305496")
        corner.grid(row=0, column=nd, sticky="nsew")
        for d, dn in enumerate(project.days):
            lb = tk.Label(self, text=dn, bg="#305496", fg="white", relief="solid", bd=1, width=9)
            lb.grid(row=0, column=nd - 1 - d, sticky="nsew")
            lb.bind("<Button-1>", lambda _e, d=d: self.toggle_many({(d, q) for q in range(npd)}))
        for q, pn in enumerate(project.periods):
            lb = tk.Label(self, text=pn, bg="#D9E1F2", relief="solid", bd=1)
            lb.grid(row=1 + q, column=nd, sticky="nsew")
            lb.bind("<Button-1>", lambda _e, q=q: self.toggle_many({(d, q) for d in range(nd)}))
            for d in range(nd):
                cell = tk.Label(self, text="", relief="solid", bd=1, bg=OK_BG if (d, q) in self.slots else OFF_BG)
                cell.grid(row=1 + q, column=nd - 1 - d, sticky="nsew", ipady=2)
                cell.bind("<Button-1>", lambda _e, d=d, q=q: self.toggle_many({(d, q)}))
                self.cells[(d, q)] = cell

    def toggle_many(self, cells):
        if cells <= self.slots:
            self.slots -= cells
        else:
            self.slots |= cells
        for c in cells:
            if c in self.cells:
                self.cells[c].configure(bg=OK_BG if c in self.slots else OFF_BG)

    def get(self) -> list:
        return sorted(self.slots)


class ActPicker(tk.Frame):
    """اختيار حصة أو أكثر من قائمة قابلة للبحث."""

    def __init__(self, master, project, multi=False, initial=(), height=8, width=46):
        super().__init__(master)
        self.p, self.multi = project, multi
        self.ids = list(initial)
        self.visible = []
        self.filter = tk.StringVar()
        ent = ttk.Entry(self, textvariable=self.filter, justify="right")
        ent.pack(fill="x")
        self.filter.trace_add("write", lambda *_a: self.fill())
        box = tk.Frame(self)
        box.pack(fill="both", expand=True)
        sb = ttk.Scrollbar(box)
        sb.pack(side="left", fill="y")
        self.lb = tk.Listbox(box, selectmode="extended" if multi else "browse", height=height, width=width,
                             exportselection=False, yscrollcommand=sb.set)
        self.lb.pack(side="right", fill="both", expand=True)
        sb.config(command=self.lb.yview)
        self.lb.bind("<<ListboxSelect>>", lambda _e: self.sync())
        self.info = tk.Label(self, text="", anchor="e")
        self.info.pack(fill="x")
        self.fill()

    def fill(self):
        q = self.filter.get().strip()
        self.lb.delete(0, "end")
        self.visible = []
        for a in sorted(self.p.acts.values(), key=lambda x: x.id):
            lab = act_label(self.p, a)
            if q and q not in lab:
                continue
            self.visible.append(a.id)
            self.lb.insert("end", lab)
            if a.id in self.ids:
                self.lb.selection_set(len(self.visible) - 1)
        self._info()

    def sync(self):
        chosen = [self.visible[i] for i in self.lb.curselection()]
        if self.multi:
            self.ids = [i for i in self.ids if i not in self.visible] + chosen
        else:
            self.ids = chosen[:1] or self.ids
        self._info()

    def _info(self):
        if self.multi:
            self.info.configure(text=f"المحدد: {len(self.ids)} حصة")
        elif self.ids and self.ids[0] in self.p.acts:
            self.info.configure(text="المحدد: " + act_label(self.p, self.p.acts[self.ids[0]]))
        else:
            self.info.configure(text="لم تُختر حصة")


def _row(parent, label):
    """صف: تسمية يميناً وحقل. يعيد إطار الصف ليُنشأ الحقل بداخله (ويبقى ظاهراً دائماً)."""
    f = tk.Frame(parent)
    f.pack(fill="x", pady=2)
    tk.Label(f, text=label, width=20, anchor="e").pack(side="right")
    return f


class ConstraintEditor(tk.LabelFrame):
    def __init__(self, master, app, on_saved):
        super().__init__(master, text="محرّر القيد")
        self.app, self.on_saved = app, on_saved
        self.ref = None           # ("c", i) | ("b", (kind, who, target)) | None
        self.kind, self.who = "", ""
        self.w = {}
        self.head = tk.Label(self, text="اختر نوع قيد من الشجرة لإضافته، أو حدّد قيداً من الجدول لتعديله.", anchor="e")
        self.head.pack(fill="x", padx=6, pady=4)
        self.body = tk.Frame(self)
        self.body.pack(fill="both", expand=True, padx=6)
        bar = tk.Frame(self)
        bar.pack(fill="x", padx=6, pady=6)
        self.weight = tk.IntVar(value=100)
        self.active = tk.BooleanVar(value=True)
        self.btn_save = ttk.Button(bar, text="💾 حفظ القيد", command=self.save)
        self.btn_save.pack(side="right", padx=3)
        ttk.Button(bar, text="إلغاء", command=self.clear).pack(side="right", padx=3)
        self.chk = ttk.Checkbutton(bar, text="مفعّل", variable=self.active)
        self.chk.pack(side="left", padx=8)
        self.spin = ttk.Spinbox(bar, from_=0, to=100, textvariable=self.weight, width=5)
        self.spin.pack(side="left")
        tk.Label(bar, text="الوزن % (100 = إجباري، أقل = تفضيل)").pack(side="left", padx=4)

    # ---------------------------------------------------------------- بناء
    def clear(self):
        self.ref, self.kind, self.who = None, "", ""
        for ch in self.body.winfo_children():
            ch.destroy()
        self.w = {}
        self.head.configure(text="اختر نوع قيد من الشجرة لإضافته، أو حدّد قيداً من الجدول لتعديله.")

    def start_new(self, kind, who):
        self.ref = None
        self.weight.set(100)
        self.active.set(True)
        self._build(kind, who, None)

    def start_edit(self, ref, c):
        self.ref = ref
        self.weight.set(c.weight)
        self.active.set(c.active)
        self._build(c.kind, c.who, c)

    def _names(self, kind_names):
        p = self.app.project
        return {"teacher": p.teachers, "students": p.all_group_names(), "subject": p.subjects}[kind_names]

    def _build(self, kind, who, c):
        for ch in self.body.winfo_children():
            ch.destroy()
        self.w = {}
        self.kind, self.who = kind, who
        p = self.app.project
        cat = tcm.CAT_TITLE.get(tcm.category_of(tcm.Constraint(kind, who)), "")
        self.head.configure(text=f"{'تعديل' if self.ref else 'إضافة'}: {tcm.kind_title(kind)}   —   {cat}")
        basic = self.ref is not None and self.ref[0] == "b"
        for w in (self.spin, self.chk):
            try:
                w.state(["disabled"] if basic else ["!disabled"])
            except (AttributeError, tk.TclError):
                pass
        if kind in tcm.ENTITY:
            who_names = "teacher" if who == "teacher" else "students"
            f0 = _row(self.body, "العنصر")
            self.w["target"] = ttk.Combobox(f0, width=34, justify="right", values=[ALL] + self._names(who_names))
            self.w["target"].pack(side="right")
            self.w["target"].set((c.target if c and c.target else ALL))
            self.w["value"] = tk.IntVar(value=c.value if c else 0)
            f = _row(self.body, tcm.ENTITY[kind][5])
            ttk.Spinbox(f, from_=0, to=40, textvariable=self.w["value"], width=7).pack(side="right")
            self._entity_hint(kind)
        elif kind in tcm.ACTIVITY:
            n = tcm.ACTIVITY[kind][2]
            if n == 0:
                self.w["acts"] = ActPicker(self.body, p, True, c.ids if c else (), height=7)
                self.w["acts"].pack(fill="both", expand=True)
                if kind in ("min_days", "max_days", "min_gaps"):
                    f = _row(self.body, {"min_days": "أدنى عدد أيام", "max_days": "أقصى عدد أيام",
                                         "min_gaps": "أدنى فراغ (ساعات)"}[kind])
                    self.w["value"] = tk.IntVar(value=c.value if c else 1)
                    ttk.Spinbox(f, from_=0, to=10, textvariable=self.w["value"], width=7).pack(side="right")
                if kind == "min_days":
                    f = _row(self.body, "")
                    self.w["flag"] = tk.BooleanVar(value=c.flag if c else False)
                    ttk.Checkbutton(f, text="يُسمح بنفس اليوم إن كانتا متتاليتين", variable=self.w["flag"]).pack(side="right")
            elif n in (2, 3):
                names = ["الأولى", "الثانية", "الثالثة"][:n]
                row = tk.Frame(self.body)
                row.pack(fill="both", expand=True)
                self.w["pickers"] = []
                for i, nm in enumerate(names):
                    col = tk.LabelFrame(row, text=f"الحصة {nm}")
                    col.pack(side="right", fill="both", expand=True, padx=2)
                    ap = ActPicker(col, p, False, [c.ids[i]] if c and len(c.ids) > i else (), height=6, width=34)
                    ap.pack(fill="both", expand=True)
                    self.w["pickers"].append(ap)
            else:
                self.w["acts"] = ActPicker(self.body, p, False, c.ids if c else (), height=6)
                self.w["acts"].pack(fill="both", expand=True)
                if kind in ("pref_times", "pref_slots"):
                    tk.Label(self.body, text="انقر الخانات المسموحة (أخضر):", anchor="e").pack(fill="x")
                    self.w["grid"] = SlotGrid(self.body, p, c.slots if c else ())
                    self.w["grid"].pack(anchor="e", pady=2)
        elif kind in tcm.FILTERED or kind == "acts_rooms":
            for key, label, vals, cur in (("f_teacher", "الأستاذ", p.teachers, c.f_teacher if c else ""),
                                          ("f_students", "القسم/الفوج", p.all_group_names(), c.f_students if c else ""),
                                          ("f_subject", "المادة", p.subjects, c.f_subject if c else "")):
                f = _row(self.body, label)
                cb = ttk.Combobox(f, width=34, justify="right", values=[ANY] + list(vals))
                cb.pack(side="right")
                cb.set(cur or ANY)
                self.w[key] = cb
            f = _row(self.body, "مدة الحصة (0 = أي)")
            self.w["f_duration"] = tk.IntVar(value=c.f_duration if c else 0)
            ttk.Spinbox(f, from_=0, to=8, textvariable=self.w["f_duration"], width=7).pack(side="right")
            if kind == "acts_rooms":
                self._rooms_box(c)
            else:
                tk.Label(self.body, text="الخانات المسموحة (أخضر):", anchor="e").pack(fill="x")
                self.w["grid"] = SlotGrid(self.body, p, c.slots if c else ())
                self.w["grid"].pack(anchor="e", pady=2)
        elif kind in tcm.GLOBAL:
            tk.Label(self.body, text="انقر الخانات التي لا تُوضع فيها أي حصة (أخضر = استراحة):", anchor="e").pack(fill="x")
            self.w["grid"] = SlotGrid(self.body, p, c.slots if c else ())
            self.w["grid"].pack(anchor="e", pady=2)
        else:
            f = _row(self.body, {"home_students": "القسم/الفوج", "home_teacher": "الأستاذ", "subject_rooms": "المادة"}[kind])
            cb = ttk.Combobox(f, width=34, justify="right", values=self._names(who))
            cb.pack(side="right")
            cb.set(c.target if c else "")
            self.w["target"] = cb
            self._rooms_box(c)
        self._retheme()

    def _entity_hint(self, kind):
        hints = {"max_hours_daily": "يُحفظ مع الحدود الأساسية (يظهر أيضاً في تبويب «التوفّر والحدود»).",
                 "max_gaps_week": "الفراغ = ساعة فارغة بين حصتين في نفس نصف اليوم.",
                 "min_hours_daily": "في نمط صباح/مساء يُطبَّق على كل نصف يوم فيه حصص.",
                 "early_second": "عدد المرات التي يبدأ فيها اليوم من الحصة الثانية بدل الأولى."}
        if kind in hints:
            tk.Label(self.body, text=hints[kind], fg="#555", anchor="e").pack(fill="x")

    def _rooms_box(self, c):
        p = self.app.project
        f = _row(self.body, "القاعات")
        self.w["rooms"] = tk.Listbox(f, selectmode="extended", height=6, width=34, exportselection=False)
        self.w["rooms"].pack(side="right")
        for r in p.rooms:
            self.w["rooms"].insert("end", r)
        if c:
            for r in c.rooms:
                if r in p.rooms:
                    self.w["rooms"].selection_set(p.rooms.index(r))

    def _retheme(self):
        th = getattr(self.app, "theme", None)
        try:
            if th is not None and th.dark:
                th.walk(self)
        except Exception:  # noqa: BLE001
            pass

    # ---------------------------------------------------------------- حفظ
    def build_constraint(self):
        """(Constraint|None, رسالة خطأ|None)."""
        p, k = self.app.project, self.kind
        if not k:
            return None, "اختر نوع القيد أولاً."
        try:
            base = dict(weight=max(0, min(100, int(self.weight.get()))), active=bool(self.active.get()))
        except (ValueError, tk.TclError):
            return None, "الوزن يجب أن يكون رقماً بين 0 و100."
        if k in tcm.ENTITY:
            t = self.w["target"].get().strip()
            t = "" if t in ("", ALL) else t
            try:
                v = int(self.w["value"].get())
            except (ValueError, tk.TclError):
                return None, "القيمة يجب أن تكون رقماً."
            if v < 0:
                return None, "القيمة يجب ألا تكون سالبة."
            return tcm.Constraint(k, self.who, t, v, True, **base), None
        if k in tcm.ACTIVITY:
            n = tcm.ACTIVITY[k][2]
            if n == 0:
                ids = list(dict.fromkeys(self.w["acts"].ids))
                if len(ids) < 2:
                    return None, "اختر حصتين على الأقل."
                c = tcm.Constraint(k, "acts", ids=ids, **base)
                if "value" in self.w:
                    c.value = int(self.w["value"].get())
                if "flag" in self.w:
                    c.flag = bool(self.w["flag"].get())
                return c, None
            if n in (2, 3):
                ids = [pk.ids[0] if pk.ids else 0 for pk in self.w["pickers"]]
                if 0 in ids or len(set(ids)) != n:
                    return None, f"اختر {n} حصص مختلفة (واحدة في كل عمود)."
                return tcm.Constraint(k, "acts", ids=ids, **base), None
            ids = self.w["acts"].ids
            if not ids:
                return None, "اختر الحصة."
            slots = self.w["grid"].get() if "grid" in self.w else []
            if "grid" in self.w and not slots:
                return None, "حدّد خانة واحدة على الأقل."
            return tcm.Constraint(k, "acts", ids=[ids[0]], slots=slots, **base), None
        if k in tcm.FILTERED or k == "acts_rooms":
            def val(key):
                v = self.w[key].get().strip()
                return "" if v in ("", ANY) else v
            try:
                dur = int(self.w["f_duration"].get())
            except (ValueError, tk.TclError):
                return None, "المدة يجب أن تكون رقماً."
            c = tcm.Constraint(k, "acts", f_teacher=val("f_teacher"), f_students=val("f_students"),
                               f_subject=val("f_subject"), f_duration=dur, **base)
            if not (c.f_teacher or c.f_students or c.f_subject or c.f_duration):
                return None, "حدّد مرشّحاً واحداً على الأقل (أستاذ/قسم/مادة/مدة)."
            if k == "acts_rooms":
                c.rooms = [p.rooms[i] for i in self.w["rooms"].curselection()]
                if not c.rooms:
                    return None, "اختر قاعة واحدة على الأقل."
            else:
                c.slots = self.w["grid"].get()
                if not c.slots:
                    return None, "حدّد خانة واحدة على الأقل."
            return c, None
        if k in tcm.GLOBAL:
            slots = self.w["grid"].get()
            if not slots:
                return None, "حدّد خانة واحدة على الأقل."
            return tcm.Constraint(k, "", slots=slots, **base), None
        t = self.w["target"].get().strip()
        rooms = [p.rooms[i] for i in self.w["rooms"].curselection()]
        if not t or not rooms:
            return None, "اختر العنصر وقاعة واحدة على الأقل."
        if k != "subject_rooms" and len(rooms) != 1:
            return None, "اختر قاعة واحدة فقط (لقاعات متعددة استعمل «قاعات لمجموعة حصص»)."
        return tcm.Constraint(k, self.who, t, rooms=rooms, **base), None

    def save(self):
        c, err = self.build_constraint()
        if err:
            messagebox.showwarning("بيانات ناقصة", err)
            return
        p = self.app.project
        if c.kind in tcm.ENTITY and p.is_basic(c.kind, c.who, c.target):
            if c.value <= 0:
                messagebox.showwarning("قيمة غير صالحة", "القيمة يجب أن تكون 1 أو أكثر (أو احذف القيد).")
                return
            if self.ref and self.ref[0] == "b":
                p.clear_basic(*self.ref[1])
            elif self.ref and self.ref[0] == "c":
                del p.constraints[self.ref[1]]
            p.set_basic(c.kind, c.who, c.target, c.value)
        elif self.ref and self.ref[0] == "c":
            p.constraints[self.ref[1]] = c
        else:
            if self.ref and self.ref[0] == "b":
                p.clear_basic(*self.ref[1])
            p.constraints.append(c)
        self.clear()
        self.on_saved()


# ===================================================================== التبويب
class ConstraintsHub(tk.Frame):
    COLS = [("on", "مفعّل", 60), ("w", "الوزن", 55), ("desc", "التفاصيل", 360), ("title", "القيد", 280),
            ("cat", "التصنيف", 210), ("sup", "المولّد", 70)]

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.filter_cat = None
        self.rows = {}            # iid -> (ref, Constraint|None)
        # يمين: الشجرة
        right = tk.Frame(self)
        right.pack(side="right", fill="y", padx=6, pady=6)
        tk.Label(right, text="تصنيف القيود (مثل FET)\nاختر نوعاً لإضافته", anchor="e", justify="right").pack(fill="x")
        box = tk.Frame(right)
        box.pack(fill="both", expand=True)
        sb = ttk.Scrollbar(box)
        sb.pack(side="left", fill="y")
        self.tree = ttk.Treeview(box, show="tree", selectmode="browse", yscrollcommand=sb.set)
        self.tree.pack(side="right", fill="both", expand=True)
        sb.config(command=self.tree.yview)
        self.tree.column("#0", width=330)
        self._fill_tree()
        self.tree.bind("<<TreeviewSelect>>", lambda _e: self.on_tree())
        # يسار: جدول + محرّر
        main = tk.Frame(self)
        main.pack(side="left", fill="both", expand=True, padx=6, pady=6)
        bar = tk.Frame(main)
        bar.pack(fill="x")
        for text, cmd in [("تفعيل/تعطيل", self.toggle), ("حذف", self.delete), ("تعديل", self.edit), ("عرض الكل", self.show_all)]:
            ttk.Button(bar, text=text, command=cmd).pack(side="right", padx=2, pady=2)
        self.info = tk.Label(bar, text="", fg="#555")
        self.info.pack(side="left")
        tbox = tk.Frame(main)
        tbox.pack(fill="both", expand=False)
        self.table = ttk.Treeview(tbox, columns=[c[0] for c in self.COLS], show="headings", selectmode="browse", height=8)
        for key, text, w in self.COLS:
            self.table.heading(key, text=text)
            self.table.column(key, width=w, anchor="e")
        tsb = ttk.Scrollbar(tbox, command=self.table.yview)
        self.table.configure(yscrollcommand=tsb.set)
        tsb.pack(side="left", fill="y")
        self.table.pack(side="right", fill="both", expand=True)
        self.table.bind("<Double-1>", lambda _e: self.edit())
        self.table.bind("<<TreeviewSelect>>", lambda _e: None)
        self.editor = ConstraintEditor(main, app, self.saved)
        self.editor.pack(fill="both", expand=True, pady=6)

    # ---------------------------------------------------------------- الشجرة
    def _fill_tree(self):
        for key, title in tcm.CATEGORIES:
            node = self.tree.insert("", "end", iid=f"cat:{key}", text=title, open=(key == "time_students"))
            for kind, who, t in tcm.types_in(key):
                self.tree.insert(node, "end", iid=f"type:{key}:{kind}:{who}", text="＋ " + t)

    def on_tree(self):
        s = self.tree.selection()
        if not s:
            return
        iid = s[0]
        if iid.startswith("cat:"):
            self.filter_cat = iid[4:]
            self.refresh()
        elif iid.startswith("type:"):
            _t, cat, kind, who = iid.split(":", 3)
            self.filter_cat = cat
            self.refresh()
            self.editor.start_new(kind, who)

    def show_all(self):
        self.filter_cat = None
        self.refresh()

    # ---------------------------------------------------------------- الجدول
    @staticmethod
    def _extra_cat(tag: str, space: bool) -> str:
        if space:
            return ("space_students" if "Students" in tag else "space_teachers" if "Teacher" in tag
                    else "space_subjects" if "Subject" in tag else "space_acts")
        return ("time_students" if "Students" in tag else "time_teachers" if "Teacher" in tag
                else "time_acts" if "Activit" in tag else "time_global")

    def _supported_kind(self, c) -> bool:
        return True

    def refresh(self):
        p = self.app.project
        self.table.delete(*self.table.get_children())
        self.rows = {}
        shown = 0

        def add(iid, ref, c, vals, cat):
            nonlocal shown
            if self.filter_cat and cat != self.filter_cat:
                return
            self.rows[iid] = (ref, c)
            self.table.insert("", "end", iid=iid, values=vals)
            shown += 1
        for i, (kind, who, target, value) in enumerate(p.basic_rows()):
            c = tcm.Constraint(kind, who, target, value, True)
            add(f"b{i}", ("b", (kind, who, target)), c,
                ("✔", 100, tcm.describe(c, p), tcm.kind_title(kind), tcm.CAT_TITLE[tcm.category_of(c)], "✔"),
                tcm.category_of(c))
        for i, c in enumerate(p.constraints):
            cat = tcm.category_of(c)
            add(f"c{i}", ("c", i), c, ("✔" if c.active else "—", c.weight, tcm.describe(c, p), tcm.kind_title(c.kind),
                                        tcm.CAT_TITLE[cat], "✔"), cat)
        for i, x in enumerate(p.extra_time):
            tag = tcm.tag_of_raw(x)
            cat = self._extra_cat(tag, False)
            add(f"t{i}", ("t", i), None, ("✔", "؟", "قيد من ملف FET لا يدعمه المولّد (يُحفظ كما هو)",
                                          tag.replace("Constraint", "", 1), tcm.CAT_TITLE[cat], "ملف فقط"), cat)
        for i, x in enumerate(p.extra_space):
            tag = tcm.tag_of_raw(x)
            cat = self._extra_cat(tag, True)
            add(f"s{i}", ("s", i), None, ("✔", "؟", "قيد من ملف FET لا يدعمه المولّد (يُحفظ كما هو)",
                                          tag.replace("Constraint", "", 1), tcm.CAT_TITLE[cat], "ملف فقط"), cat)
        label = tcm.CAT_TITLE.get(self.filter_cat, "كل التصنيفات")
        self.info.configure(text=f"{label}: {shown} قيد")

    def _sel(self):
        s = self.table.selection()
        return self.rows.get(s[0]) if s else None

    # ---------------------------------------------------------------- أفعال
    def saved(self):
        self.app.set_dirty()
        self.app.reload_all()

    def edit(self):
        it = self._sel()
        if not it:
            return
        ref, c = it
        if c is None:
            messagebox.showinfo("غير مدعوم في المولّد",
                                "هذا القيد من ملف FET ولا يدعمه المولّد؛ يبقى محفوظاً في الملف كما هو.\n"
                                "يمكنك حذفه فقط.")
            return
        self.editor.start_edit(ref, c)

    def delete(self):
        it = self._sel()
        if not it:
            return
        ref, _c = it
        p = self.app.project
        if ref[0] == "c":
            del p.constraints[ref[1]]
        elif ref[0] == "b":
            p.clear_basic(*ref[1])
        elif ref[0] == "t":
            del p.extra_time[ref[1]]
        else:
            del p.extra_space[ref[1]]
        self.editor.clear()
        self.saved()

    def toggle(self):
        it = self._sel()
        if not it or it[0][0] != "c":
            return
        c = self.app.project.constraints[it[0][1]]
        c.active = not c.active
        self.saved()
