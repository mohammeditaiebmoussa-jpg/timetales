"""منطق التعديل اليدوي للجدول ولوحة المشاكل — بلا واجهة (قابل للاختبار).

- slot_map(project, aid): لكل خانة (يوم، حصة) أسباب منع وضع الحصة فيها (قائمة فارغة = مسموحة).
- swap_reasons / apply_move / apply_swap: نقل حصة أو تبديل حصتين مع التحقق من القيود الصلبة.
- find_problems(project): كل المشاكل الصلبة في الجدول الحالي مع إحداثياتها (للانتقال إليها بالنقر).
الحصص المتزامنة (تدريس مشترك) تتحرك دائماً معاً كوحدة واحدة.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

import tt_constraints as tcm
import tt_solver

KIND_ORDER = {"clash": 0, "unavail": 1, "limit": 2, "rule": 3, "room": 4, "unplaced": 5}
KIND_TITLE = {"clash": "تعارض", "unavail": "عدم توفّر", "limit": "حدّ", "rule": "قيد", "room": "قاعة",
              "unplaced": "غير موضوعة"}


@dataclass
class Problem:
    kind: str                  # clash | unavail | limit | rule | room | unplaced
    text: str
    ids: list = field(default_factory=list)
    day: int = -1
    period: int = -1
    entity: tuple = None       # (teacher|class|room, الاسم) للانتقال إلى جدوله


# ------------------------------------------------------------------ وحدات الحصص
def bundle_ids(project, aid) -> list:
    """الحصص التي تتحرك معاً: الحصة نفسها، أو كل حصص مجموعة التزامن (نفس المدة)."""
    a = project.acts[aid]
    if not a.parallel:
        return [aid]
    d = max(1, a.duration)
    return sorted(x.id for x in project.acts.values()
                  if x.active and x.parallel == a.parallel and max(1, x.duration) == d)


def bundle_key(a):
    return ("p", a.parallel, max(1, a.duration)) if a.parallel else ("a", a.id)


def locked_in(project, aid) -> list:
    return [i for i in bundle_ids(project, aid) if i in project.locked]


def act_resources(project, a, ctx):
    teachers = list(a.teachers)
    leaves = list(dict.fromkeys(lf for s in a.students for lf in project.leaves(s)))
    eff = tt_solver.effective_rooms(project, a, ctx)
    room = project.room_assign.get(a.id) or (eff[0] if len(eff) == 1 else "")
    return teachers, leaves, room


def class_entity(project, name: str) -> str:
    """اسم «القسم» في العارض الذي يحتوي هذا الفوج."""
    classes = set(project.classes() or project.all_group_names())
    if name in classes:
        return name
    for par in project.parents(name):
        if par in classes:
            return par
    return name


def _unavail(project):
    t, s, r = {}, {}, {}
    for (k, name), slots in project.unavail.items():
        if k == "teacher":
            t.setdefault(name, set()).update(slots)
        elif k == "room":
            r.setdefault(name, set()).update(slots)
        elif k == "students":
            for lf in project.leaves(name):
                s.setdefault(lf, set()).update(slots)
    return {"t": t, "s": s, "r": r}


def _leaf_limits(project) -> dict:
    out = {}
    for name, v in project.students_max_daily.items():
        for lf in project.leaves(name):
            out[lf] = min(out[lf], v) if out.get(lf) else v
    return out


# ------------------------------------------------------------------ فهرس الإشغال
class Board:
    """إشغال الأساتذة والأفواج والقاعات للحصص الموضوعة (ما عدا exclude)."""

    def __init__(self, project, exclude=()):
        self.p = project
        self.ctx = tt_solver.room_context(project)
        self.busy = {}      # (kind, name, d, h) -> [act ids]   kind: teacher | leaf | room
        self.hours = {}     # (kind, name, d) -> {bundle_key: dur}
        self.days = {}      # teacher -> {days}
        self.leaf_lim = _leaf_limits(project)
        ex = set(exclude)
        for a in project.acts.values():
            if not a.active or a.id in ex:
                continue
            pos = project.placements.get(a.id)
            if pos:
                self.add(a, pos)

    def add(self, a, pos) -> None:
        d, p = pos
        dur = max(1, a.duration)
        t, leaves, room = act_resources(self.p, a, self.ctx)
        bk = bundle_key(a)
        for k in range(dur):
            for x in t:
                self.busy.setdefault(("teacher", x, d, p + k), []).append(a.id)
            for x in leaves:
                self.busy.setdefault(("leaf", x, d, p + k), []).append(a.id)
            if room:
                self.busy.setdefault(("room", room, d, p + k), []).append(a.id)
        for x in t:
            self.hours.setdefault(("teacher", x, d), {})[bk] = dur
            self.days.setdefault(x, set()).add(d)
        for x in leaves:
            self.hours.setdefault(("leaf", x, d), {})[bk] = dur


def reasons(project, board, ids, d, p, una=None) -> list:
    """أسباب منع وضع وحدة الحصص ids بدءاً من (d, p). قائمة فارغة = مسموح."""
    una = una or _unavail(project)
    acts = [project.acts[i] for i in ids]
    dur = max(1, acts[0].duration)
    P = project.n_periods
    if p + dur > P:
        return ["تتجاوز نهاية اليوم"]
    if project.halves > 1 and p // project.half_len != (p + dur - 1) // project.half_len:
        return ["لا يمكن أن تعبر الفاصل بين الصباح والمساء"]
    out, seen = [], set()

    def add(msg):
        if msg not in seen:
            seen.add(msg)
            out.append(msg)

    T, L = [], []
    for a in acts:
        t, leaves, room = act_resources(project, a, board.ctx)
        T += t
        L += leaves
        for k in range(dur):
            h = p + k
            for x in t:
                if (d, h) in una["t"].get(x, ()):
                    add(f"الأستاذ «{x}» غير متوفر")
                o = board.busy.get(("teacher", x, d, h))
                if o:
                    add(f"الأستاذ «{x}» مشغول بالحصة {o[0]}")
            for x in leaves:
                if (d, h) in una["s"].get(x, ()):
                    add(f"القسم «{x}» غير متوفر")
                o = board.busy.get(("leaf", x, d, h))
                if o:
                    add(f"القسم «{x}» مشغول بالحصة {o[0]}")
            if room:
                if (d, h) in una["r"].get(room, ()):
                    add(f"القاعة «{room}» غير متوفرة")
                o = board.busy.get(("room", room, d, h))
                if o:
                    add(f"القاعة «{room}» مشغولة بالحصة {o[0]}")
    for x in dict.fromkeys(T):
        lim = project.teacher_max_daily.get(x) or project.default_teacher_max_daily
        if lim and sum(board.hours.get(("teacher", x, d), {}).values()) + dur > lim:
            add(f"الأستاذ «{x}» يتجاوز {lim} ساعات في اليوم")
        md = project.teacher_max_days.get(x)
        have = board.days.get(x, set())
        if md and d not in have and len(have) >= md:
            add(f"الأستاذ «{x}» يتجاوز أقصى أيام العمل ({md})")
    for x in dict.fromkeys(L):
        lim = board.leaf_lim.get(x) or project.default_students_max_daily
        if lim and sum(board.hours.get(("leaf", x, d), {}).values()) + dur > lim:
            add(f"القسم «{x}» يتجاوز {lim} ساعات في اليوم")
    return out


def slot_map(project, aid) -> dict:
    """{(day, period): [أسباب المنع]} لكل خانات الأسبوع، لتلوين الممنوع عند السحب."""
    ids = bundle_ids(project, aid)
    board = Board(project, exclude=set(ids))
    una = _unavail(project)
    return {(d, p): reasons(project, board, ids, d, p, una)
            for d in range(project.n_days) for p in range(project.n_periods)}


def swap_reasons(project, aid_a, aid_b) -> list:
    A, B = bundle_ids(project, aid_a), bundle_ids(project, aid_b)
    if set(A) & set(B):
        return ["نفس الحصة"]
    pa, pb = project.placements.get(A[0]), project.placements.get(B[0])
    if not pa or not pb:
        return ["إحدى الحصتين غير موضوعة"]
    board = Board(project, exclude=set(A) | set(B))
    una = _unavail(project)
    out = [f"(حصة {A[0]}) " + m for m in reasons(project, board, A, pb[0], pb[1], una)]
    out += [f"(حصة {B[0]}) " + m for m in reasons(project, board, B, pa[0], pa[1], una)]
    if not out:
        da, db = max(1, project.acts[A[0]].duration), max(1, project.acts[B[0]].duration)
        sa = {(pb[0], pb[1] + k) for k in range(da)}
        sb = {(pa[0], pa[1] + k) for k in range(db)}
        if sa & sb:
            ctx = board.ctx

            def res(ids):
                t, lv, rm = set(), set(), set()
                for i in ids:
                    x, y, z = act_resources(project, project.acts[i], ctx)
                    t |= set(x)
                    lv |= set(y)
                    if z:
                        rm.add(z)
                return t, lv, rm
            ra, rb = res(A), res(B)
            if any(ra[i] & rb[i] for i in range(3)):
                out.append("تتعارض الحصتان بعد التبديل (مورد مشترك)")
    return out


# ------------------------------------------------------------------ تنفيذ
def refresh_rooms(project) -> list:
    """يعيد توزيع القاعات المتعددة الخيارات بعد أي تعديل؛ يعيد رسائل النقص."""
    if not project.placements:
        return []
    assign, miss = tt_solver.assign_rooms(project, project.placements)
    project.room_assign = dict(assign)
    return miss


def apply_move(project, aid, d, p, lock=False) -> None:
    for i in bundle_ids(project, aid):
        project.placements[i] = (d, p)
        if lock:
            project.locked.add(i)
    refresh_rooms(project)


def apply_swap(project, aid_a, aid_b, lock=False) -> None:
    A, B = bundle_ids(project, aid_a), bundle_ids(project, aid_b)
    pa, pb = project.placements[A[0]], project.placements[B[0]]
    for i in A:
        project.placements[i] = pb
        if lock:
            project.locked.add(i)
    for i in B:
        project.placements[i] = pa
        if lock:
            project.locked.add(i)
    refresh_rooms(project)


# ------------------------------------------------------------------ لوحة المشاكل
def _fmt(project, d, h) -> str:
    return f"{project.days[d]} — {project.periods[h]}"


def find_problems(project, with_rules: bool = True) -> list:
    """كل المشاكل الصلبة في الجدول الحالي، مرتبة؛ لكل مشكلة إحداثيات وعنصر للانتقال إليه."""
    if not project.placements:
        return []
    out = []
    P = project.n_periods
    ctx = tt_solver.room_context(project)
    una = _unavail(project)
    busy = {}     # (kind, name, d, h) -> {bundle_key: [aids]}
    hours, days = {}, {}
    placed = []
    for a in sorted(project.acts.values(), key=lambda x: x.id):
        if not a.active:
            continue
        pos = project.placements.get(a.id)
        who = f"{a.subject} — {'، '.join(a.teachers)} — {'، '.join(a.students)}"
        if not pos:
            out.append(Problem("unplaced", f"الحصة {a.id} ({who}) غير موضوعة", [a.id]))
            continue
        d, p = pos
        dur = max(1, a.duration)
        t, leaves, room = act_resources(project, a, ctx)
        ent = ("teacher", t[0]) if t else (("class", class_entity(project, leaves[0])) if leaves else None)
        if p + dur > P or (project.halves > 1 and p // project.half_len != (p + dur - 1) // project.half_len):
            out.append(Problem("limit", f"الحصة {a.id} ({who}) تتجاوز نهاية اليوم/نصف اليوم: {_fmt(project, d, p)}",
                               [a.id], d, p, ent))
        placed.append(a)
        bk = bundle_key(a)
        for k in range(dur):
            h = p + k
            for x in t:
                busy.setdefault(("teacher", x, d, h), {}).setdefault(bk, []).append(a.id)
                if (d, h) in una["t"].get(x, ()):
                    out.append(Problem("unavail", f"الأستاذ «{x}» في وقت غير متوفر: {_fmt(project, d, h)} (حصة {a.id})",
                                       [a.id], d, h, ("teacher", x)))
            for x in leaves:
                busy.setdefault(("leaf", x, d, h), {}).setdefault(bk, []).append(a.id)
                if (d, h) in una["s"].get(x, ()):
                    out.append(Problem("unavail", f"القسم «{x}» في وقت غير متوفر: {_fmt(project, d, h)} (حصة {a.id})",
                                       [a.id], d, h, ("class", class_entity(project, x))))
            if room:
                busy.setdefault(("room", room, d, h), {}).setdefault(bk, []).append(a.id)
                if (d, h) in una["r"].get(room, ()):
                    out.append(Problem("unavail", f"القاعة «{room}» في وقت غير متوفر: {_fmt(project, d, h)} (حصة {a.id})",
                                       [a.id], d, h, ("room", room)))
        for x in t:
            hours.setdefault(("teacher", x, d), {})[bk] = dur
            days.setdefault(x, set()).add(d)
        for x in leaves:
            hours.setdefault(("leaf", x, d), {})[bk] = dur

    names = {"teacher": "أستاذ", "leaf": "قسم/فوج", "room": "قاعة"}
    for (kind, name, d, h), groups in sorted(busy.items(), key=lambda kv: (kv[0][0], str(kv[0][1]), kv[0][2], kv[0][3])):
        if len(groups) > 1:
            ids = sorted({i for v in groups.values() for i in v})
            ent = ("teacher", name) if kind == "teacher" else (
                ("class", class_entity(project, name)) if kind == "leaf" else ("room", name))
            out.append(Problem("clash", f"تعارض {names[kind]} «{name}»: {_fmt(project, d, h)} (حصص {'، '.join(map(str, ids))})",
                               ids, d, h, ent))

    def acts_of(kind, name, day=None):
        r = []
        for a in placed:
            t, leaves, _ = act_resources(project, a, ctx)
            if (name in t if kind == "teacher" else name in leaves) and (day is None or project.placements[a.id][0] == day):
                r.append(a.id)
        return r

    leaf_lim = _leaf_limits(project)
    for (kind, name, d), v in sorted(hours.items(), key=lambda kv: (kv[0][0], str(kv[0][1]), kv[0][2])):
        total = sum(v.values())
        if kind == "teacher":
            lim = project.teacher_max_daily.get(name) or project.default_teacher_max_daily
            ent = ("teacher", name)
        else:
            lim = leaf_lim.get(name) or project.default_students_max_daily
            ent = ("class", class_entity(project, name))
        if lim and total > lim:
            ids = acts_of(kind, name, d)
            out.append(Problem("limit", f"«{name}»: {total} ساعات يوم {project.days[d]} (الحد {lim})", ids, d,
                               project.placements[ids[0]][1] if ids else -1, ent))
    for x, ds in sorted(days.items()):
        md = project.teacher_max_days.get(x)
        if md and len(ds) > md:
            ids = acts_of("teacher", x)
            out.append(Problem("limit", f"الأستاذ «{x}» يعمل {len(ds)} أيام (الحد {md})", ids, entity=("teacher", x)))

    miss = []
    try:
        miss = tt_solver.assign_rooms(project, project.placements)[1]
    except Exception:  # noqa: BLE001
        pass
    for m in miss:
        ids = [int(x) for x in re.findall(r"حصة (\d+)", m)]
        out.append(Problem("room", m, ids))

    if with_rules:
        out += _rule_problems(project)
    out.sort(key=lambda pr: (KIND_ORDER.get(pr.kind, 9), pr.day, pr.period, pr.text))
    return out


def _rule_problems(project) -> list:
    """مخالفات القيود المتقدمة الإجبارية (فراغات، تتابع، متتاليتان…) عبر حالة المولّد."""
    out = []
    try:
        s = tt_solver.Solver(project)
        s._reset_state()
        for i, aid in enumerate(s.aid):
            pos = project.placements.get(aid)
            if pos and s.dom[i] is not None:
                s._add(i, pos[0] * s.P + pos[1])
        for r in s.advc:
            if s.advh[r] > 0:
                name = s.rnames[r]
                if r < s.T:
                    ent = ("teacher", name)
                    ids = [aid for aid in project.placements if name in project.acts[aid].teachers]
                else:
                    ent = ("class", class_entity(project, name))
                    ids = [aid for aid in project.placements
                           if name in [lf for st in project.acts[aid].students for lf in project.leaves(st)]]
                for kind, v, w in s._adv_cost(r, s.mask[r], True)[3]:
                    if w >= 100:
                        out.append(Problem("rule", f"«{name}»: مخالفة قيد «{tcm.kind_title(kind)}» ({v})", sorted(ids), entity=ent))
        for msg in s._prule_totals(True)[2]:
            if msg.startswith("إجباري"):
                ids = [int(x) for x in re.findall(r"\d+", msg.split("الحصص", 1)[-1])]
                ent = None
                if ids and ids[0] in project.acts:
                    a = project.acts[ids[0]]
                    ent = ("teacher", a.teachers[0]) if a.teachers else None
                pos = project.placements.get(ids[0]) if ids else None
                out.append(Problem("rule", msg.replace("إجباري: ", "", 1), ids,
                                   pos[0] if pos else -1, pos[1] if pos else -1, ent))
    except Exception:  # noqa: BLE001
        pass
    return out

