"""قيود زمانية ومكانية على غرار FET: كتالوج + قراءة/كتابة .fet.

التصنيف مثل FET:
  زمانية: للطلاب، للأساتذة، للحصص، عامة   —   مكانية: للطلاب، للأساتذة، للمواد، للحصص
كل قيد له وزن 0..100 (100 = إجباري). القيد الأقل من 100 عقوبة ناعمة يحاول المولّد تقليلها.
أسماء الوسوم والحقول مطابقة لـ FET 7.5.x (تحقّقتُ منها في fet-cl.exe).
القيود التي يقرؤها البرنامج من ملف FET ولا يدعمها المولّد تبقى محفوظة في الملف وتظهر في القائمة بعلامة «غير مدعوم».
"""
from __future__ import annotations

import os
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field


@dataclass
class Constraint:
    kind: str
    who: str = ""                 # teacher | students | subject | acts
    target: str = ""              # اسم الأستاذ/القسم/المادة؛ فارغ = الجميع
    value: int = 0
    flag: bool = False
    ids: list = field(default_factory=list)      # أرقام حصص
    slots: list = field(default_factory=list)    # [(day, period)]
    rooms: list = field(default_factory=list)
    weight: int = 100
    active: bool = True
    # مرشّحات القيود على «مجموعة حصص» (فارغ = أي)
    f_teacher: str = ""
    f_students: str = ""
    f_subject: str = ""
    f_duration: int = 0


# ------------------------------------------------------------------ قيود الأساتذة/الأقسام
# kind -> (العنوان، (غير مستعمل)، يطبَّق على T/S، وسم FET، حقل القيمة، عنوان القيمة)
ENTITY = {
    "max_hours_daily": ("أقصى ساعات في اليوم", "time", "TS", "MaxHoursDaily", "Maximum_Hours_Daily", "ساعات"),
    "max_hours_cont":  ("أقصى ساعات متتالية", "time", "TS", "MaxHoursContinuously", "Maximum_Hours_Continuously", "ساعات"),
    "min_hours_daily": ("أدنى ساعات في اليوم (إن عمل)", "time", "TS", "MinHoursDaily", "Minimum_Hours_Daily", "ساعات"),
    "max_gaps_week":   ("أقصى عدد فراغات أسبوعياً", "time", "TS", "MaxGapsPerWeek", "Max_Gaps", "فراغات"),
    "max_gaps_day":    ("أقصى عدد فراغات يومياً", "time", "TS", "MaxGapsPerDay", "Max_Gaps", "فراغات"),
    "max_span_day":    ("أقصى امتداد يومي (أول حصة ← آخر حصة)", "time", "TS", "MaxSpanPerDay", "Max_Span", "حصص"),
    "max_days_week":   ("أقصى أيام عمل/دراسة أسبوعياً", "time", "TS", "MaxDaysPerWeek", "Max_Days_Per_Week", "أيام"),
    "min_days_week":   ("أدنى أيام عمل أسبوعياً", "time", "T", "MinDaysPerWeek", "Minimum_Days_Per_Week", "أيام"),
    "max_mornings":    ("أقصى عدد صباحات أسبوعياً", "time", "TS", "MaxMorningsPerWeek", "Max_Mornings_Per_Week", "صباحات"),
    "max_afternoons":  ("أقصى عدد مساءات أسبوعياً", "time", "TS", "MaxAfternoonsPerWeek", "Max_Afternoons_Per_Week", "مساءات"),
    "min_mornings":    ("أدنى عدد صباحات أسبوعياً", "time", "TS", "MinMorningsPerWeek", "Min_Mornings_Per_Week", "صباحات"),
    "min_afternoons":  ("أدنى عدد مساءات أسبوعياً", "time", "TS", "MinAfternoonsPerWeek", "Min_Afternoons_Per_Week", "مساءات"),
    "early_second":    ("أقصى مرات البدء من الحصة الثانية", "time", "S", "EarlyMaxBeginningsAtSecondHour",
                        "Max_Beginnings_At_Second_Hour", "مرات"),
}
# في نمط صباح/مساء يكتب FET أيام الأسبوع الحقيقية بوسوم خاصة
REAL_DAY_TAG = {"max_hours_daily": "MaxHoursDailyRealDays", "max_days_week": "MaxRealDaysPerWeek",
                "min_days_week": "MinRealDaysPerWeek"}

# ------------------------------------------------------------------ قيود الحصص
# kind -> (العنوان، وسم FET، الشكل): 0=قائمة حصص، 1=حصة، 2=زوج، 3=ثلاث
ACTIVITY = {
    "same_time":         ("حصص تبدأ في نفس الوقت (نفس اليوم ونفس الحصة)", "ActivitiesSameStartingTime", 0),
    "same_hour":         ("حصص تبدأ في نفس الحصة (أيام مختلفة)", "ActivitiesSameStartingHour", 0),
    "same_day":          ("حصص في نفس اليوم", "ActivitiesSameStartingDay", 0),
    "not_overlap":       ("حصص لا تتداخل", "ActivitiesNotOverlapping", 0),
    "min_days":          ("أدنى عدد أيام بين الحصص", "MinDaysBetweenActivities", 0),
    "max_days":          ("أقصى عدد أيام بين الحصص", "MaxDaysBetweenActivities", 0),
    "min_gaps":          ("أدنى فراغ (بالساعات) بين الحصص في اليوم", "MinGapsBetweenActivities", 0),
    "consecutive":       ("حصتان متتاليتان (الأولى ثم الثانية مباشرة)", "TwoActivitiesConsecutive", 2),
    "ordered":           ("حصتان بترتيب (الأولى قبل الثانية في اليوم نفسه)", "TwoActivitiesOrdered", 2),
    "ordered_same_day":  ("حصتان بترتيب إن اجتمعتا في يوم واحد", "TwoActivitiesOrderedIfSameDay", 2),
    "grouped":           ("حصتان متجاورتان (بأي ترتيب)", "TwoActivitiesGrouped", 2),
    "grouped3":          ("ثلاث حصص متجاورة (بأي ترتيب)", "ThreeActivitiesGrouped", 3),
    "pref_times":        ("أوقات بدء مفضّلة لحصة", "ActivityPreferredStartingTimes", 1),
    "pref_slots":        ("خانات زمنية مفضّلة لحصة (كل ساعاتها داخلها)", "ActivityPreferredTimeSlots", 1),
    "ends_students_day": ("الحصة آخر حصة في يوم طلابها", "ActivityEndsStudentsDay", 1),
    "begins_students_day": ("الحصة أول حصة في يوم طلابها", "ActivityBeginsStudentsDay", 1),
    "ends_teachers_day": ("الحصة آخر حصة في يوم أساتذتها", "ActivityEndsTeachersDay", 1),
    "begins_teachers_day": ("الحصة أول حصة في يوم أساتذتها", "ActivityBeginsTeachersDay", 1),
}
# قيود على مجموعة حصص تُحدَّد بمرشّحات (أستاذ/قسم/مادة/مدة)
FILTERED = {
    "acts_pref_times": ("أوقات بدء مفضّلة لمجموعة حصص (بمرشّحات)", "ActivitiesPreferredStartingTimes"),
    "acts_pref_slots": ("خانات زمنية مفضّلة لمجموعة حصص (بمرشّحات)", "ActivitiesPreferredTimeSlots"),
}
GLOBAL = {
    "break_times": ("فترات استراحة (لا حصص لأحد فيها)", "BreakTimes"),
}
# ------------------------------------------------------------------ مكانية
# kind -> (العنوان، وسم FET بصيغة المفرد، وسم الجمع)
SPACE = {
    "home_students": ("قاعة ثابتة لقسم/فوج", "StudentsSetHomeRoom", "StudentsSetHomeRooms"),
    "home_teacher":  ("قاعة ثابتة لأستاذ", "TeacherHomeRoom", "TeacherHomeRooms"),
    "subject_rooms": ("قاعات مفضّلة لمادة", "SubjectPreferredRoom", "SubjectPreferredRooms"),
    "acts_rooms":    ("قاعات لمجموعة حصص (بمرشّحات)", "", ""),
}

# ------------------------------------------------------------------ تصنيف FET
CATEGORIES = [
    ("time_students", "زمانية — خاصة بالطلاب (الأقسام والأفواج)"),
    ("time_teachers", "زمانية — خاصة بالأساتذة"),
    ("time_acts", "زمانية — خاصة بالحصص"),
    ("time_global", "زمانية — عامة"),
    ("space_students", "مكانية — خاصة بالطلاب والأقسام"),
    ("space_teachers", "مكانية — خاصة بالأساتذة"),
    ("space_subjects", "مكانية — خاصة بالمواد"),
    ("space_acts", "مكانية — خاصة بالحصص"),
]
CAT_TITLE = dict(CATEGORIES)


def category_of(c: "Constraint") -> str:
    k = c.kind
    if k in ENTITY:
        return "time_students" if c.who == "students" else "time_teachers"
    if k in ACTIVITY or k in FILTERED:
        return "time_acts"
    if k in GLOBAL:
        return "time_global"
    return {"home_students": "space_students", "home_teacher": "space_teachers",
            "subject_rooms": "space_subjects", "acts_rooms": "space_acts"}.get(k, "time_global")


def types_in(cat: str) -> list:
    """[(kind, who, العنوان)] لأنواع القيود المتاحة في تصنيف."""
    out = []
    if cat in ("time_students", "time_teachers"):
        who, flag = ("students", "S") if cat == "time_students" else ("teacher", "T")
        out = [(k, who, v[0]) for k, v in ENTITY.items() if flag in v[2]]
    elif cat == "time_acts":
        out = [(k, "acts", v[0]) for k, v in ACTIVITY.items()] + [(k, "acts", v[0]) for k, v in FILTERED.items()]
    elif cat == "time_global":
        out = [(k, "", v[0]) for k, v in GLOBAL.items()]
    else:
        key = {"space_students": "home_students", "space_teachers": "home_teacher",
               "space_subjects": "subject_rooms", "space_acts": "acts_rooms"}[cat]
        who = {"home_students": "students", "home_teacher": "teacher", "subject_rooms": "subject", "acts_rooms": "acts"}[key]
        out = [(key, who, SPACE[key][0])]
    return out


def catalog_titles() -> list:
    """[(kind, العنوان، 'time'|'space')] — للتوافق مع الشيفرة القديمة."""
    out = [(k, v[0], "time") for k, v in ENTITY.items()]
    out += [(k, v[0], "time") for k, v in ACTIVITY.items()]
    out += [(k, v[0], "time") for k, v in FILTERED.items()]
    out += [(k, v[0], "time") for k, v in GLOBAL.items()]
    out += [(k, v[0], "space") for k, v in SPACE.items()]
    return out


def kind_title(kind: str) -> str:
    for k, t, _c in catalog_titles():
        if k == kind:
            return t
    return kind


def allowed_who(kind: str) -> list:
    if kind in ENTITY:
        w = ENTITY[kind][2]
        return (["teacher"] if "T" in w else []) + (["students"] if "S" in w else [])
    return []


def describe(c: Constraint, project=None) -> str:
    """وصف مختصر للقيد لعرضه في الجدول."""
    k = c.kind
    if k in ENTITY:
        who = "كل الأساتذة" if (c.who == "teacher" and not c.target) else (
            "كل الأقسام" if (c.who == "students" and not c.target) else c.target)
        return f"{who}: {c.value} {ENTITY[k][5]}"
    if k in ACTIVITY:
        n = ACTIVITY[k][2]
        if k == "min_days":
            return f"حصص {c.ids}: ≥ {c.value} يوم" + (" (أو متتاليتان)" if c.flag else "")
        if k == "max_days":
            return f"حصص {c.ids}: ≤ {c.value} يوم"
        if k == "min_gaps":
            return f"حصص {c.ids}: فراغ ≥ {c.value} ساعة"
        if n == 1 and c.slots and project is not None:
            s = "، ".join(f"{project.days[d]} {project.periods[p]}" for d, p in sorted(c.slots)[:4])
            return f"حصة {c.ids}: {s}{'…' if len(c.slots) > 4 else ''}"
        return f"حصص {c.ids}"
    if k in FILTERED or k == "acts_rooms":
        flt = [x for x in (c.f_teacher, c.f_students, c.f_subject, f"{c.f_duration}س" if c.f_duration else "") if x]
        what = " / ".join(flt) or "كل الحصص"
        if k == "acts_rooms":
            return f"{what} ← {' / '.join(c.rooms)}"
        if project is not None and c.slots:
            s = "، ".join(f"{project.days[d]} {project.periods[p]}" for d, p in sorted(c.slots)[:3])
            return f"{what} ← {s}{'…' if len(c.slots) > 3 else ''}"
        return what
    if k in GLOBAL:
        if project is not None:
            s = "، ".join(f"{project.days[d]} {project.periods[p]}" for d, p in sorted(c.slots)[:4])
            return s + ("…" if len(c.slots) > 4 else "")
        return f"{len(c.slots)} خانة"
    if k in SPACE:
        return f"{c.target}: {' / '.join(c.rooms)}"
    return ""


# ------------------------------------------------------------------ وسوم FET المعروفة
def _load_known_tags() -> set:
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fet_tags.txt")
    try:
        with open(p, encoding="utf-8") as fh:
            return {x.strip() for x in fh if x.strip()}
    except OSError:
        return set()


KNOWN_FET_TAGS = _load_known_tags()


def tag_of_raw(xml: str) -> str:
    try:
        return ET.fromstring(xml).tag
    except ET.ParseError:
        return "؟"


# ------------------------------------------------------------------ XML
def _sub(parent, tag, text=None):
    e = ET.SubElement(parent, tag)
    if text is not None:
        e.text = str(text)
    return e


def _t(el, tag, default=""):
    c = el.find(tag)
    return (c.text or default).strip() if c is not None and c.text is not None else default


def _scope_tag(kind: str, who: str, target: str, real: bool):
    base = REAL_DAY_TAG[kind] if (real and kind in REAL_DAY_TAG) else ENTITY[kind][3]
    if who == "teacher":
        return ("ConstraintTeacher" if target else "ConstraintTeachers") + base, ("Teacher" if target else None)
    return ("ConstraintStudentsSet" if target else "ConstraintStudents") + base, ("Students" if target else None)


def _slots_el(parent, wrapper, slots, to_raw, count_tag=None, day="Preferred_Day", hour="Preferred_Hour"):
    if wrapper == "Preferred_Starting_Time":          # صيغة FET الفعلية لأوقات البدء
        day, hour = "Preferred_Starting_Day", "Preferred_Starting_Hour"
    elif wrapper == "Preferred_Time_Slot":
        day, hour = "Preferred_Day", "Preferred_Hour"
    if count_tag:
        _sub(parent, count_tag, len(slots))
    for d, p in sorted(slots):
        dn, hn = to_raw(d, p)
        s = _sub(parent, wrapper)
        _sub(s, day, dn)
        _sub(s, hour, hn)


def to_element(c: Constraint, to_raw, real: bool = False) -> tuple:
    """يعيد (section, Element) حيث section = 'time' أو 'space'."""
    k = c.kind
    if k in ENTITY:
        tag, ttag = _scope_tag(k, c.who, c.target, real)
        e = ET.Element(tag)
        _sub(e, "Weight_Percentage", c.weight)
        if ttag:
            _sub(e, ttag, c.target)
        _sub(e, ENTITY[k][4], c.value)
        if k == "min_hours_daily":
            _sub(e, "Allow_Empty_Days", "true")
        _sub(e, "Active", "true" if c.active else "false")
        _sub(e, "Comments", "")
        return "time", e
    if k in ACTIVITY:
        e = ET.Element("Constraint" + ACTIVITY[k][1])
        _sub(e, "Weight_Percentage", c.weight)
        n = ACTIVITY[k][2]
        if n == 0:
            if k == "min_days":
                _sub(e, "Consecutive_If_Same_Day", "true" if c.flag else "false")
            _sub(e, "Number_of_Activities", len(c.ids))
            for i in c.ids:
                _sub(e, "Activity_Id", i)
            if k == "min_days":
                _sub(e, "MinDays", c.value)
            elif k == "max_days":
                _sub(e, "MaxDays", c.value)
            elif k == "min_gaps":
                _sub(e, "MinGaps", c.value)
        elif n == 2:
            _sub(e, "First_Activity_Id", c.ids[0])
            _sub(e, "Second_Activity_Id", c.ids[1])
        elif n == 3:
            _sub(e, "First_Activity_Id", c.ids[0])
            _sub(e, "Second_Activity_Id", c.ids[1])
            _sub(e, "Third_Activity_Id", c.ids[2])
        else:
            _sub(e, "Activity_Id", c.ids[0])
            if k == "pref_times":
                _slots_el(e, "Preferred_Starting_Time", c.slots, to_raw, "Number_of_Preferred_Starting_Times")
            elif k == "pref_slots":
                _slots_el(e, "Preferred_Time_Slot", c.slots, to_raw, "Number_of_Preferred_Time_Slots", "Day", "Hour")
        _sub(e, "Active", "true" if c.active else "false")
        _sub(e, "Comments", "")
        return "time", e
    if k in FILTERED:
        e = ET.Element("Constraint" + FILTERED[k][1])
        _sub(e, "Weight_Percentage", c.weight)
        _sub(e, "Teacher_Name", c.f_teacher)
        _sub(e, "Students_Name", c.f_students)
        _sub(e, "Subject_Name", c.f_subject)
        _sub(e, "Activity_Tag_Name", "")
        _sub(e, "Duration", c.f_duration if c.f_duration else "")
        if k == "acts_pref_times":
            _slots_el(e, "Preferred_Starting_Time", c.slots, to_raw, "Number_of_Preferred_Starting_Times")
        else:
            _slots_el(e, "Preferred_Time_Slot", c.slots, to_raw, "Number_of_Preferred_Time_Slots", "Day", "Hour")
        _sub(e, "Active", "true" if c.active else "false")
        _sub(e, "Comments", "")
        return "time", e
    if k in GLOBAL:
        e = ET.Element("ConstraintBreakTimes")
        _sub(e, "Weight_Percentage", c.weight)
        _slots_el(e, "Break_Time", c.slots, to_raw, "Number_of_Break_Times", "Day", "Hour")
        _sub(e, "Active", "true" if c.active else "false")
        _sub(e, "Comments", "")
        return "time", e
    single, plural = SPACE[k][1], SPACE[k][2]
    many = len(c.rooms) > 1
    e = ET.Element("Constraint" + (plural if many else single))
    _sub(e, "Weight_Percentage", c.weight)
    _sub(e, {"home_students": "Students", "home_teacher": "Teacher", "subject_rooms": "Subject"}[k], c.target)
    if many:
        _sub(e, "Number_of_Preferred_Rooms", len(c.rooms))
        for r in c.rooms:
            _sub(e, "Preferred_Room", r)
    else:
        _sub(e, "Room", c.rooms[0] if c.rooms else "")
    _sub(e, "Active", "true" if c.active else "false")
    _sub(e, "Comments", "")
    return "space", e


def _weight(el) -> int:
    try:
        return max(0, min(100, int(round(float(_t(el, "Weight_Percentage", "100"))))))
    except ValueError:
        return 100


def _build_tag_index():
    idx = {}
    for kind, v in ENTITY.items():
        for who in ("teacher", "students"):
            if (who == "teacher" and "T" not in v[2]) or (who == "students" and "S" not in v[2]):
                continue
            prefixes = ("ConstraintTeacher", "ConstraintTeachers") if who == "teacher" else \
                ("ConstraintStudentsSet", "ConstraintStudents")
            for base in {v[3], REAL_DAY_TAG.get(kind, v[3])}:
                for pref in prefixes:
                    idx[pref + base] = (kind, who, pref in ("ConstraintTeacher", "ConstraintStudentsSet"))
    return idx


_TAG_INDEX = _build_tag_index()
_ACT_INDEX = {"Constraint" + v[1]: k for k, v in ACTIVITY.items()}
_FILT_INDEX = {"Constraint" + v[1]: k for k, v in FILTERED.items()}
_SPACE_INDEX = {}
for _k, _v in SPACE.items():
    if _v[1]:
        _SPACE_INDEX["Constraint" + _v[1]] = _k
        _SPACE_INDEX["Constraint" + _v[2]] = _k
_SPACE_TARGET = {"home_students": "Students", "home_teacher": "Teacher", "subject_rooms": "Subject"}
_SPACE_WHO = {"home_students": "students", "home_teacher": "teacher", "subject_rooms": "subject"}


def _read_slots(el, wrapper, to_real, day="Preferred_Day", hour="Preferred_Hour"):
    out = []
    for s in el.findall(wrapper):
        # FET يكتب Preferred_Time_Slot بوسمَي Day/Hour، وPreferred_Starting_Time بـ Preferred_Day/Preferred_Hour
        r = to_real(_t(s, day) or _t(s, "Preferred_Starting_Day") or _t(s, "Preferred_Day") or _t(s, "Day"),
                    _t(s, hour) or _t(s, "Preferred_Starting_Hour") or _t(s, "Preferred_Hour") or _t(s, "Hour"))
        if r:
            out.append(r)
    return out


def from_element(el, to_real):
    """يحوّل عنصر FET إلى Constraint أو None إن لم يكن مدعوماً."""
    tag = el.tag
    active = _t(el, "Active", "true") == "true"
    try:
        if tag in _TAG_INDEX:
            kind, who, single = _TAG_INDEX[tag]
            target = _t(el, "Teacher" if who == "teacher" else "Students") if single else ""
            if single and not target:
                return None
            return Constraint(kind, who, target, int(_t(el, ENTITY[kind][4], "0")), True, weight=_weight(el), active=active)
        if tag in _ACT_INDEX:
            kind = _ACT_INDEX[tag]
            n = ACTIVITY[kind][2]
            c = Constraint(kind, "acts", weight=_weight(el), active=active)
            if n == 0:
                c.ids = [int(x.text) for x in el.findall("Activity_Id")]
                if kind == "min_days":
                    c.value = int(_t(el, "MinDays", "1"))
                    c.flag = _t(el, "Consecutive_If_Same_Day", "false") == "true"
                elif kind == "max_days":
                    c.value = int(_t(el, "MaxDays", "1"))
                elif kind == "min_gaps":
                    c.value = int(_t(el, "MinGaps", "1"))
            elif n == 2:
                c.ids = [int(_t(el, "First_Activity_Id")), int(_t(el, "Second_Activity_Id"))]
            elif n == 3:
                c.ids = [int(_t(el, x)) for x in ("First_Activity_Id", "Second_Activity_Id", "Third_Activity_Id")]
            else:
                c.ids = [int(_t(el, "Activity_Id"))]
                if kind == "pref_times":
                    c.slots = _read_slots(el, "Preferred_Starting_Time", to_real)
                elif kind == "pref_slots":
                    c.slots = _read_slots(el, "Preferred_Time_Slot", to_real)
            return c
        if tag in _FILT_INDEX:
            kind = _FILT_INDEX[tag]
            if _t(el, "Activity_Tag_Name"):
                return None          # الوسوم غير مدعومة في هذا البرنامج
            c = Constraint(kind, "acts", weight=_weight(el), active=active, f_teacher=_t(el, "Teacher_Name"),
                           f_students=_t(el, "Students_Name"), f_subject=_t(el, "Subject_Name"))
            d = _t(el, "Duration")
            c.f_duration = int(d) if d.isdigit() else 0
            c.slots = _read_slots(el, "Preferred_Starting_Time" if kind == "acts_pref_times" else "Preferred_Time_Slot", to_real)
            return c
        if tag == "ConstraintBreakTimes":
            return Constraint("break_times", "", slots=_read_slots(el, "Break_Time", to_real, "Day", "Hour"),
                              weight=_weight(el), active=active)
        if tag == "ConstraintSubjectPreferredRoom":
            return Constraint("subject_rooms", "subject", _t(el, "Subject"), rooms=[_t(el, "Room")],
                              weight=_weight(el), active=active)
        if tag in _SPACE_INDEX:
            kind = _SPACE_INDEX[tag]
            c = Constraint(kind, _SPACE_WHO[kind], _t(el, _SPACE_TARGET[kind]), weight=_weight(el), active=active)
            if el.find("Preferred_Room") is not None:
                c.rooms = [(x.text or "").strip() for x in el.findall("Preferred_Room")]
            else:
                c.rooms = [_t(el, "Room")]
            return c
    except (ValueError, TypeError, IndexError):
        return None
    return None
