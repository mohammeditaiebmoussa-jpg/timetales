@echo off
setlocal
cd /d "%~dp0"
set PY=py
where py >nul 2>nul
if errorlevel 1 (
  set PY=python
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python was not found. Install Python 3.8+ from python.org and tick "Add python.exe to PATH".
    pause
    exit /b 1
  )
)
echo [1/3] Installing tools...
%PY% -m pip install pyinstaller openpyxl
if errorlevel 1 goto err
echo [2/3] Building...
%PY% -m PyInstaller --noconfirm --clean --windowed --name Timetabler --hidden-import make_demo --hidden-import openpyxl --hidden-import tkinter.simpledialog app_tk.py
if errorlevel 1 goto err
echo [3/3] Done.
echo Program: %CD%\dist\Timetabler\Timetabler.exe
echo For Setup.exe: install Inno Setup, open installer.iss, press F9.
pause
exit /b 0
:err
echo.
echo ERROR - see the messages above. Send me a screenshot.
pause
exit /b 1
