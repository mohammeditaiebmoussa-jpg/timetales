"""قراءة ملفات FET (.fet) واستخراج الجدول الزمني منها.

يدعم النمطين Normal و Mornings_Afternoons. لا يحتاج إلى أي مكتبة خارجية.
"""
from __future__ import annotations

import xml.etree.ElementTree as ET
import zlib
from collections import defaultdict
from dataclasses import dataclass, field

# ألوان هادئة للمواد (يُختار اللون من اسم المادة بشكل ثابت)
PALETTE = [
    "#FDE2E4", "#E2ECE9", "#DFE7FD", "#FFF1C1", "#E8DFF5", "#D4F0F0",
    "#FFE5D0", "#E3F2C1", "#F9D5E5", "#D6E6F2", "#F6E6B4", "#D5ECD4",
    "#EAD7F2", "#FFD6C9", "#CDE7E5", "#F3E1B7",
]


def subject_color(subject: str) -> str:
    return PALETTE[zlib.crc32(subject.encode("utf-8")) % len(PALETTE)]


def _parse_parallel(text: str) -> int:
    tag = "TT_PARALLEL="
    if text and tag in text:
        try:
            return int(text.split(tag, 1)[1].split()[0])
        except (ValueError, IndexError):
            return 0
    return 0


def _txt(el: ET.Element | None, tag: str, default: str = "") -> str:
    if el is None:
        return default
    child = el.find(tag)
    return (child.text or default) if child is not None else default


@dataclass
class Activity:
    id: int
    teachers: list[str]
    subject: str
    students: str
    duration: int
    total_duration: int
    group_id: int
    active: bool = True
    parallel: int = 0     # حصص متزامنة (نفس القسم، أساتذة مختلفون، نفس الوقت)


@dataclass
class Lesson:
    """حصة موضوعة في الجدول، بإحداثيات الأيام/الساعات «الحقيقية» (المعروضة)."""
    activity: Activity
    day: int          # فهرس اليوم الحقيقي (0..)
    hour: int         # فهرس الساعة الحقيقية الأولى
    span: int         # عدد الساعات المتتالية
    rooms: list[str]  # الغرف المفضّلة/المحددة (قد تكون فارغة)
    also: list = field(default_factory=list)   # حصص متزامنة تُعرض في نفس الخانة (عرض الأقسام)

    @property
    def room_text(self) -> str:
        return " / ".join(self.rooms)


@dataclass
class Conflict:
    kind: str      # teacher | class | room
    name: str
    day: int
    hour: int
    activity_ids: list[int]


@dataclass
class FetProject:
    path: str = ""
    institution: str = ""
    mode: str = "Normal"
    days: list[str] = field(default_factory=list)          # أيام FET الخام
    hours: list[str] = field(default_factory=list)         # ساعات FET الخام
    real_days: list[str] = field(default_factory=list)     # الأيام المعروضة
    real_hours: list[str] = field(default_factory=list)    # الساعات المعروضة
    teachers: list[str] = field(default_factory=list)
    classes: list[str] = field(default_factory=list)
    subjects: list[str] = field(default_factory=list)
    rooms: list[str] = field(default_factory=list)
    activities: dict[int, Activity] = field(default_factory=dict)
    placements: dict[int, tuple[int, int]] = field(default_factory=dict)   # id -> (day, hour) خام
    activity_rooms: dict[int, list[str]] = field(default_factory=dict)
    lessons: list[Lesson] = field(default_factory=list)
    unplaced: list[int] = field(default_factory=list)

    # ------------------------------------------------------------------ تحميل
    @classmethod
    def load(cls, path: str) -> "FetProject":
        root = ET.parse(path).getroot()
        if root.tag != "fet":
            raise ValueError("هذا الملف ليس ملف FET صالحاً")
        p = cls(path=path)
        p.institution = _txt(root, "Institution_Name").strip()
        p.mode = _txt(root, "Mode", "Normal").strip()

        p.days = [_txt(d, "Name").strip() for d in root.findall("Days_List/Day")]
        p.hours = [_txt(h, "Name").strip() for h in root.findall("Hours_List/Hour")]
        p.real_days = [_txt(d, "Name").strip() for d in root.findall("Real_Days_List/Real_Day")]
        p.real_hours = [_txt(h, "Name").strip() for h in root.findall("Real_Hours_List/Real_Hour")]
        if p.mode != "Mornings_Afternoons" or not p.real_days:
            p.mode = "Normal" if p.mode != "Mornings_Afternoons" else p.mode
            p.real_days = p.real_days or p.days[:]
            p.real_hours = p.real_hours or p.hours[:]

        p.teachers = [_txt(t, "Name").strip() for t in root.findall("Teachers_List/Teacher")]
        p.subjects = [_txt(s, "Name").strip() for s in root.findall("Subjects_List/Subject")]
        p.classes = [_txt(y, "Name").strip() for y in root.findall("Students_List/Year")]
        p.rooms = [_txt(r, "Name").strip() for r in root.findall("Rooms_List/Room")]

        for a in root.findall("Activities_List/Activity"):
            act = Activity(
                id=int(_txt(a, "Id", "0")),
                teachers=[(t.text or "").strip() for t in a.findall("Teacher")],
                subject=_txt(a, "Subject").strip(),
                students=_txt(a, "Students").strip(),
                duration=int(_txt(a, "Duration", "1")),
                total_duration=int(_txt(a, "Total_Duration", "1")),
                group_id=int(_txt(a, "Activity_Group_Id", "0")),
                active=_txt(a, "Active", "true").strip() == "true",
                parallel=_parse_parallel(_txt(a, "Comments")),
            )
            p.activities[act.id] = act

        # الأوقات الثابتة (نتيجة التوليد المحفوظة في الملف)
        day_idx = {n: i for i, n in enumerate(p.days)}
        hour_idx = {n: i for i, n in enumerate(p.hours)}
        for c in root.findall("Time_Constraints_List/ConstraintActivityPreferredStartingTime"):
            if _txt(c, "Active", "true").strip() != "true":
                continue
            aid = int(_txt(c, "Activity_Id", "0"))
            d = day_idx.get((_txt(c, "Preferred_Day") or _txt(c, "Day")).strip())
            h = hour_idx.get((_txt(c, "Preferred_Hour") or _txt(c, "Hour")).strip())
            if d is not None and h is not None:
                p.placements[aid] = (d, h)

        # الغرف
        for c in root.findall("Space_Constraints_List/ConstraintActivityPreferredRoom"):
            if _txt(c, "Active", "true").strip() == "true":
                p.activity_rooms[int(_txt(c, "Activity_Id", "0"))] = [_txt(c, "Room").strip()]
        for c in root.findall("Space_Constraints_List/ConstraintActivityPreferredRooms"):
            if _txt(c, "Active", "true").strip() == "true":
                p.activity_rooms[int(_txt(c, "Activity_Id", "0"))] = [
                    (r.text or "").strip() for r in c.findall("Preferred_Room")
                ]

        p._build_lessons()
        return p

    # ------------------------------------------------------------ بناء الحصص
    @property
    def hours_per_half_day(self) -> int:
        return len(self.hours)

    def _to_real(self, day: int, hour: int) -> tuple[int, int]:
        if self.mode == "Mornings_Afternoons":
            return day // 2, (day % 2) * self.hours_per_half_day + hour
        return day, hour

    def _build_lessons(self) -> None:
        self.lessons.clear()
        self.unplaced.clear()
        for aid, act in self.activities.items():
            if not act.active:
                continue
            pos = self.placements.get(aid)
            if pos is None:
                self.unplaced.append(aid)
                continue
            d, h = pos
            # الحصة لا تتجاوز نصف اليوم في FET؛ نقتصّها احتياطاً
            span = max(1, min(act.duration, self.hours_per_half_day - h))
            rd, rh = self._to_real(d, h)
            self.lessons.append(Lesson(act, rd, rh, span, self.activity_rooms.get(aid, [])))

    # ------------------------------------------------------------- استعلامات
    def entities(self, kind: str) -> list[str]:
        return {"teacher": self.teachers, "class": self.classes, "room": self.rooms}[kind]

    def lessons_of(self, kind: str, name: str) -> list[Lesson]:
        out = []
        for ls in self.lessons:
            a = ls.activity
            if kind == "teacher" and name in a.teachers:
                out.append(ls)
            elif kind == "class" and a.students == name:
                out.append(ls)
            elif kind == "room" and name in ls.rooms:
                out.append(ls)
        return out

    def weekly_hours(self, kind: str, name: str) -> int:
        if kind != "class":
            return sum(ls.span for ls in self.lessons_of(kind, name))
        total, seen = 0, set()
        for ls in self.lessons_of(kind, name):
            par = ls.activity.parallel
            if par:
                key = (par, ls.day, ls.hour)
                if key in seen:
                    continue    # الحصص المتزامنة تُحتسب مرة واحدة للقسم
                seen.add(key)
            total += ls.span
        return total

    def cell_text(self, kind: str, ls: Lesson) -> list[str]:
        """أسطر النص داخل الخانة حسب نوع العرض (الحصص المتزامنة تُجمع في خانة واحدة)."""
        if not ls.also:
            return self._cell_lines(kind, ls)
        out = []
        for i, m in enumerate([ls] + list(ls.also)):
            if i:
                out.append("──────")
            out += self._cell_lines(kind, m)
        return out

    def _cell_lines(self, kind: str, ls: Lesson) -> list[str]:
        a = ls.activity
        lines = [a.subject]
        if kind == "teacher":
            lines.append(a.students)
        elif kind == "class":
            lines.append(" + ".join(a.teachers))
        else:
            lines.append(a.students)
            lines.append(" + ".join(a.teachers))
        if kind != "room" and ls.rooms:
            lines.append(ls.room_text)
        return [x for x in lines if x]

    # ------------------------------------------------------------- التعارضات
    def conflicts(self) -> list[Conflict]:
        """تعارضات المعلمين والأقسام والغرف (الغرف المحددة بغرفة واحدة فقط)."""
        busy: dict[tuple[str, str, int, int], list[int]] = defaultdict(list)
        for ls in self.lessons:
            a = ls.activity
            for k in range(ls.span):
                h = ls.hour + k
                for t in a.teachers:
                    busy[("teacher", t, ls.day, h)].append(a.id)
                busy[("class", a.students, ls.day, h)].append(a.id)
                if len(ls.rooms) == 1:
                    busy[("room", ls.rooms[0], ls.day, h)].append(a.id)
        out = []
        for (kind, name, d, h), ids in busy.items():
            uids = set(ids)
            if len(uids) > 1:
                if kind == "class":
                    pars = {self.activities[i].parallel for i in uids}
                    if len(pars) == 1 and 0 not in pars:
                        continue    # حصص متزامنة مقصودة (تدريس مشترك/تقسيم القسم)
                out.append(Conflict(kind, name, d, h, sorted(uids)))
        out.sort(key=lambda c: (c.kind, c.name, c.day, c.hour))
        return out

    def stats(self) -> dict[str, int]:
        return {
            "teachers": len(self.teachers), "classes": len(self.classes),
            "subjects": len(self.subjects), "rooms": len(self.rooms),
            "activities": len(self.activities), "placed": len(self.lessons),
            "unplaced": len(self.unplaced),
        }
