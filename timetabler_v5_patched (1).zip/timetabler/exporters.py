"""تصدير الجداول إلى Excel وإلى HTML (يُستعمل للطباعة وPDF)."""
from __future__ import annotations

import html
import re

from dataclasses import replace

from fet_model import FetProject, subject_color

KIND_TITLES = {"teacher": "جدول الأستاذ", "class": "جدول القسم", "room": "جدول القاعة"}
KIND_PLURAL = {"teacher": "الأساتذة", "class": "الأقسام", "room": "القاعات"}
KIND_PREFIX = {"teacher": "أستاذ", "class": "قسم", "room": "قاعة"}


def build_grid(project: FetProject, kind: str, name: str):
    """يعيد (grid, covered, skipped).

    grid[(day, hour)] = Lesson للخانة الأولى من كل حصة، covered = الخانات المدمجة،
    skipped = حصص تتداخل مع حصة معروضة (تحدث في عرض القاعات عندما تكون الغرفة
    مفضّلة من بين عدة غرف ولم تُحدَّد بعد).
    """
    lessons = project.lessons_of(kind, name)
    lessons.sort(key=lambda ls: (len(ls.rooms) != 1, ls.day, ls.hour))   # المحددة الغرفة أولاً
    grid, covered, skipped, used = {}, set(), [], set()
    for ls in lessons:
        slots = {(ls.day, ls.hour + k) for k in range(ls.span)}
        if slots & used:
            host = grid.get((ls.day, ls.hour))
            par = ls.activity.parallel
            if par and host is not None and host.activity.parallel == par and host.span == ls.span:
                host.also.append(ls)       # حصة متزامنة: تُعرض في نفس الخانة
                continue
            skipped.append(ls)
            continue
        used |= slots
        grid[(ls.day, ls.hour)] = replace(ls, also=[])   # نسخة كي لا نُعدّل الحصة المشتركة بين العروض
        covered |= slots - {(ls.day, ls.hour)}
    return grid, covered, skipped


# ----------------------------------------------------------------- Excel
def _sheet_title(name: str, used: set[str]) -> str:
    base = re.sub(r"[\\/*?:\[\]]", "-", name).strip()[:28] or "ورقة"
    title, i = base, 2
    while title in used:
        title = f"{base}{i}"
        i += 1
    used.add(title)
    return title


def export_excel(project: FetProject, path: str, kinds=("teacher", "class", "room")) -> int:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

    thin = Side(style="thin", color="999999")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)

    wb = Workbook()
    wb.remove(wb.active)
    used: set[str] = set()
    count = 0
    n_days, n_hours = len(project.real_days), len(project.real_hours)

    for kind in kinds:
        for name in project.entities(kind):
            ws = wb.create_sheet(_sheet_title(f"{KIND_PREFIX[kind]} {name}", used))
            ws.sheet_view.rightToLeft = True
            ws["A1"] = f"{KIND_TITLES[kind]}: {name}"
            ws["A1"].font = Font(name="Arial", bold=True, size=14)
            ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=n_days + 1)
            ws["A1"].alignment = center
            ws["A2"] = project.institution
            ws["A2"].font = Font(name="Arial", size=10, color="555555")
            ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=n_days + 1)
            ws["A2"].alignment = center

            hdr = Font(name="Arial", bold=True, color="FFFFFF")
            hfill = PatternFill("solid", fgColor="305496")
            top = 4
            c = ws.cell(row=top, column=1, value="الحصة")
            c.font, c.fill, c.alignment, c.border = hdr, hfill, center, border
            for d, dn in enumerate(project.real_days):
                c = ws.cell(row=top, column=2 + d, value=dn)
                c.font, c.fill, c.alignment, c.border = hdr, hfill, center, border

            grid, covered, skipped = build_grid(project, kind, name)
            for h, hn in enumerate(project.real_hours):
                r = top + 1 + h
                c = ws.cell(row=r, column=1, value=hn)
                c.font = Font(name="Arial", bold=True)
                c.fill = PatternFill("solid", fgColor="D9E1F2")
                c.alignment, c.border = center, border
                ws.row_dimensions[r].height = 48
                for d in range(n_days):
                    cell = ws.cell(row=r, column=2 + d)
                    cell.border, cell.alignment = border, center
                    cell.font = Font(name="Arial", size=10)
                    ls = grid.get((d, h))
                    if ls:
                        cell.value = "\n".join(project.cell_text(kind, ls))
                        cell.fill = PatternFill("solid", fgColor=subject_color(ls.activity.subject).lstrip("#"))
                        if ls.span > 1:
                            ws.merge_cells(start_row=r, start_column=2 + d,
                                           end_row=r + ls.span - 1, end_column=2 + d)
            ws.column_dimensions["A"].width = 12
            for d in range(n_days):
                ws.column_dimensions[ws.cell(row=top, column=2 + d).column_letter].width = 22
            note = f"الحجم الأسبوعي: {project.weekly_hours(kind, name)} ساعة"
            if skipped:
                note += f" — حصص متداخلة غير معروضة: {len(skipped)} (غرفة غير محددة)"
            ws.cell(row=top + n_hours + 2, column=1, value=note).font = Font(name="Arial", size=10)
            ws.page_setup.orientation = "landscape"
            ws.page_setup.fitToWidth = 1
            ws.sheet_properties.pageSetUpPr.fitToPage = True
            count += 1
    if not wb.sheetnames:
        wb.create_sheet("فارغ")
    wb.save(path)
    return count


# ------------------------------------------------------------------ HTML
def entity_html(project: FetProject, kind: str, name: str, page_break: bool = False) -> str:
    """جدول واحد بصيغة HTML بسيطة تفهمها Qt (خصائص الجدول لا CSS معقّد)."""
    grid, covered, skipped = build_grid(project, kind, name)
    n_days, n_hours = len(project.real_days), len(project.real_hours)
    e = html.escape
    brk = ' style="page-break-before:always"' if page_break else ""
    out = [f'<div dir="rtl"{brk}>',
           f'<h2 align="center">{e(KIND_TITLES[kind])}: {e(name)}</h2>',
           f'<p align="center">{e(project.institution)} — الحجم الأسبوعي: '
           f'{project.weekly_hours(kind, name)} ساعة</p>',
           '<table dir="rtl" border="1" cellspacing="0" cellpadding="5" width="100%">',
           '<tr><th bgcolor="#305496"><font color="#FFFFFF">الحصة</font></th>']
    for dn in project.real_days:
        out.append(f'<th bgcolor="#305496"><font color="#FFFFFF">{e(dn)}</font></th>')
    out.append("</tr>")
    for h in range(n_hours):
        out.append(f'<tr><td bgcolor="#D9E1F2" align="center"><b>{e(project.real_hours[h])}</b></td>')
        for d in range(n_days):
            ls = grid.get((d, h))
            if ls:
                rs = f' rowspan="{ls.span}"' if ls.span > 1 else ""
                lines = project.cell_text(kind, ls)
                body = f"<b>{e(lines[0])}</b>" + "".join(f"<br/>{e(x)}" for x in lines[1:])
                out.append(f'<td{rs} align="center" bgcolor="{subject_color(ls.activity.subject)}">{body}</td>')
            elif (d, h) in covered:
                continue
            else:
                out.append("<td>&nbsp;</td>")
        out.append("</tr>")
    out.append("</table></div>")
    return "".join(out)


def document_html(project: FetProject, items: list[tuple[str, str]]) -> str:
    parts = [entity_html(project, k, n, page_break=i > 0) for i, (k, n) in enumerate(items)]
    return f'<html><body dir="rtl">{"".join(parts)}</body></html>'


def standalone_html(project: FetProject, items: list[tuple[str, str]]) -> str:
    """صفحة HTML كاملة تُفتح في المتصفح؛ للتحويل إلى PDF: Ctrl+P ثم «حفظ بتنسيق PDF»."""
    css = ("@page{size:A4 landscape;margin:10mm}"
           "body{font-family:Arial,Tahoma,sans-serif;font-size:12px}"
           "table{border-collapse:collapse}")
    body = "".join(entity_html(project, k, n, page_break=i > 0) for i, (k, n) in enumerate(items))
    return ('<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8">'
            f'<title>{html.escape(project.institution or "الجداول")}</title>'
            f'<style>{css}</style></head><body>{body}</body></html>')


def all_items(project: FetProject, kinds=("teacher", "class", "room")) -> list[tuple[str, str]]:
    return [(k, n) for k in kinds for n in project.entities(k) if project.lessons_of(k, n)]
